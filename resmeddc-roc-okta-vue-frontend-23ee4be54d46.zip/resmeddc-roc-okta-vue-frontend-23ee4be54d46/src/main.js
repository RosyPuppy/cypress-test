import { createApp } from "vue";
import VueFinalModal from "vue-final-modal";
import VueCookies from "vue3-cookies";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import DragDrop from "@/views/DragDrop";
import pageloader from "@/components/pageloader";
import ElementPlus from "element-plus";
import "element-plus/lib/theme-chalk/index.css";
import Navbar from "@/views/Navbar";
import SuccessMessage from "@/views/SuccessMessage";
import vueTheStorages from "vue-the-storages";

// default, you can modify
const vueTheStoragesOptions = {
  localMirrorKey: "$localData",
  localStorageKey: "$local",

  sessionMirrorKey: "$sessionData",
  sessionStorageKey: "$session",

  options: {
    vueModule: null,
    strict: true,
    mirrorOperation: false,
    updateMirror: true,
  },
};

const app = createApp(App);

app.use(VueFinalModal(), {
  componentName: "VueFinalModal",
  key: "$vfm",
  dynamicContainerName: "ModalsContainer",
});
app.use(vueTheStorages, vueTheStoragesOptions);

app.use(VueCookies);
app.use(store);
app.use(router);
app.use(ElementPlus);
// Components
app.component("Navbar", Navbar);
app.component("DragDrop", DragDrop);
app.component("pageloader", pageloader);
app.component("SuccessMessage", SuccessMessage);
app.mount("#app");
