import axios from "axios";
import { OKTA_DOMAIN, OKTA_SESSION } from "@/Config";
import store from "@/store";
import _ from "lodash";

const apiBase = axios.create({
  baseURL: `${OKTA_DOMAIN}v1`,
  headers: {
    "Content-Type": "application/json",
  },
});
class Api {
  static async getMe() {
    // eslint-disable-next-line no-async-promise-executor
    return new Promise(async (resolve, reject) => {
      try {
        const { region } = store.state;
        const res = await axios.get(OKTA_SESSION + "/api/v1/sessions/me", {
          headers: {
            "Content-Type": "application/json",
          },
          withCredentials: true,
        });
        const session = await apiBase.get(
          `/account/view/${res.data.login}/partner/50/pending`,
          {
            headers: {
              "Content-Type": "application/json",
              region: `${region}`,
              OKTA_SID: `${res.data.id}`,
            },
            withCredentials: true,
          }
        );
        store.dispatch("setOktaSid", res.data.id);
        store.dispatch("setLoggedUser", session.data.user);
        store.dispatch("setOktaEmail", res.data.login);
        resolve();
      } catch (e) {
        reject(e.response.data.message);
      }
    });
  }

  static async resetPassword(email) {
    try {
      const { region } = store.state;
      await apiBase.post(
        `/user/request_verify`,
        {
          user: {
            email: email,

            verify_link: "reset_password",
          },

          role: "PARTNER",
        },
        { headers: { region: region } }
      );
      return true;
    } catch (e) {
      throw new Error(e.response.data.message);
    }
  }

  static async getMySubscriptions() {
    try {
      const { oktaEmail, loggeduser, region, oktaSid } = store.state;
      const email = oktaEmail ? oktaEmail : loggeduser.email;
      const res = await apiBase.get(`common/mysubscription/list/${email}`, {
        headers: { region: region, OKTA_SID: oktaSid },
      });

      const resCategory = await apiBase.get(`account/view/${email}/partner/50/pending`, {
          headers: { "Content-Type": "application/json", region: region, OKTA_SID: oktaSid },
      });
      // console.log("res", res.data.subscriptions, resCategory.data.userAccess);

      const getStatus = (type) => {
        const findEle = _.find(res.data.subscriptions, [
          "subscriptionCode",
          type,
        ]);
        return findEle ? findEle.subscribed : false;
      };

      const getCatStatus = (type) => {
        const findEle = _.find(resCategory.data.userAccess, [
          "categoryType",
          type,
        ]);
        return findEle ? findEle.userAccessStatus : "UNSUBSCRIBED";
      };

      const formatSubscriptions = {
        clinical: getStatus("CLINICAL"),
        commercial: getStatus("COMMERCIAL"),
        technical: getStatus("TECHNICAL"),
        sleep: getCatStatus("SLEEP") === "APPROVE" ? true : false,
        oxygen: getCatStatus("OXYGEN") === "APPROVE" ? true : false,
        ventilators: getCatStatus("VENTILATOR") === "APPROVE" ? true : false,
      };
      store.dispatch("setSubscriptions", formatSubscriptions);
    } catch (e) {
      throw new Error(e.response?.data?.message || "Something went wrong.");
    }
  }

  static async updateMySubscription(
    clinical,
    commercial,
    technical,
    sleep,
    oxygen,
    ventilator
  ) {
    try {
      const { oktaEmail, loggeduser, region, oktaSid } = store.state;
      const email = oktaEmail ? oktaEmail : loggeduser.email;
      await apiBase.put(
        `/common/mysubscription/update/${email}`,
        {
          subscriptions: [
            {
              subscriptionCode: "CLINICAL",
              subscribed: clinical,
            },
            {
              subscriptionCode: "COMMERCIAL",
              subscribed: commercial,
            },
            {
              subscriptionCode: "TECHNICAL",
              subscribed: technical,
            },
          ],
          categoryTypes: [
            {
              subscriptionCode: "SLEEP",
              subscribed: sleep,
            },
            {
              subscriptionCode: "OXYGEN",
              subscribed: oxygen,
            },
            {
              subscriptionCode: "VENTILATOR",
              subscribed: ventilator,
            },
          ],
        },
        {
          headers: { region: region, OKTA_SID: oktaSid },
        }
      );
    } catch (e) {
      throw new Error(e.response.data.message);
    }
  }

  static async changePassword(oldpassword, newpassword) {
    try {
      const { oktaEmail, loggeduser, region, oktaSid } = store.state;
      const email = oktaEmail ? oktaEmail : loggeduser.email;
      await apiBase.put(
        `/account/change_password`,
        {
          user: {
            email: email,
            oldpassword: oldpassword,
            newpassword: newpassword,
          },
        },
        { headers: { region: region, OKTA_SID: oktaSid } }
      );
    } catch (e) {
      throw new Error(e.response.data.message);
    }
  }

  static async getSearchList(query, type, limit) {
    try {
      const { oktaEmail, loggeduser, oktaSid, region } = store.state;
      const email = oktaEmail ? oktaEmail : loggeduser.email;
      const response = await apiBase.get(
        `/account/search/${email}/partner/${limit}/${type}?search=${query}`,
        {
          headers: { region: region, OKTA_SID: oktaSid },
          withCredentials: true,
        }
      );
      let records;
      let count = 0;
      if (type === "pending") {
        records = response.data.pendingApprovals;
        count = records.length
          ? response.data.pendingApprovals[0].pendingRecordsLength
          : 0;
      }
      if (type === "approved") {
        records = response.data.approvedUsers;
        count = records.length
          ? response.data.approvedUsers[0].approvedRecordsLength
          : 0;
      }
      if (type === "rejected") {
        records = response.data.rejectedUsers;
        count = records.length
          ? response.data.rejectedUsers[0].rejectedRecordsLength
          : 0;
      }
      store.dispatch("setUserRecords", { records, count });
    } catch (e) {
      throw new Error(e.response.data.message);
    }
  }

  static async getAdminList(type, limit) {
    try {
      const { oktaEmail, loggeduser, oktaSid, region } = store.state;
      const email = oktaEmail ? oktaEmail : loggeduser.email;
      const response = await apiBase.get(
        `/account/view/${email}/partner/${limit}/${type}`,
        {
          headers: { region: region, OKTA_SID: oktaSid },
          withCredentials: true,
        }
      );
      let records;
      let count = 0;
      if (type === "pending") {
        records = response.data.pendingApprovals;
        count = records.length
          ? response.data.pendingApprovals[0].pendingRecordsLength
          : 0;
      }
      if (type === "approved") {
        records = response.data.approvedUsers;
        count = records.length
          ? response.data.approvedUsers[0].approvedRecordsLength
          : 0;
      }
      if (type === "rejected") {
        records = response.data.rejectedUsers;
        count = records.length
          ? response.data.rejectedUsers[0].rejectedRecordsLength
          : 0;
      }
      store.dispatch("setUserRecords", { records, count });
    } catch (e) {
      throw new Error(e.response.data.message);
    }
  }
  static async bulkApproveRecord(accounts, techBody) {
    try {
      const { oktaSid, region } = store.state;
      await apiBase.put(
        `/common/subscription/bulk`,
        {
          accounts: accounts.map((item) => ({
            email: item.profile.email,
            action: "approve",
            type: item.type,
            ...techBody,
          })),
        },
        {
          headers: { region: region, OKTA_SID: oktaSid },
        }
      );
    } catch (e) {
      throw new Error(e.response.data.message);
    }
  }
  static async bulkRejectRecord(accounts, rejectNotes) {
    try {
      const { oktaSid, region } = store.state;
      await apiBase.put(
        `/common/subscription/bulk`,
        {
          accounts: accounts.map((item) => ({
            email: item.profile.email,
            action: "reject",
            note: rejectNotes.notes + " " + rejectNotes.comments,
            includeuser: rejectNotes.includeuser ? "Y" : "N",
            type: item.type,
          })),
        },
        {
          headers: { region: region, OKTA_SID: oktaSid },
        }
      );
    } catch (e) {
      throw new Error(e.response.data.message);
    }
  }
  static async approveRecord(email, type, techBody) {
    try {
      const { oktaSid, region } = store.state;
      console.log(email, type, techBody, oktaSid, region);
      await apiBase.put(
        `/common/subscription/update/approve/${email}?type=${type}`,
        techBody,
        {
          headers: { region: region, OKTA_SID: oktaSid },
        }
      );
    } catch (e) {
      throw new Error(e.response.data.message);
    }
  }
  static async deleteAccount() {
    try {
      const { oktaSid, region } = store.state;
      await apiBase.delete(
        `/account/delete`,

        {
          headers: { region: region, OKTA_SID: oktaSid },
        }
      );
    } catch (e) {
      throw new Error(e.response.data.message);
    }
  }
  static async rejectRecord(row, techBody) {
    try {
      const { oktaSid, region } = store.state;
      await apiBase.put(
        `/common/subscription/update/reject/${row.email}?type=${
          row.type
        }&note=${row.notes + " " + row.comments}&includeuser=${
          row.includeuser ? "Y" : "N"
        }`,
        techBody,
        {
          headers: { region: region, OKTA_SID: oktaSid },
        }
      );
    } catch (e) {
      throw new Error(e.response.data.message);
    }
  }
  static async verifyChangePassword(token, newpassword) {
    try {
      const { region } = store.state;
      await apiBase.post(
        `user/verify`,
        {
          user: {
            token: token,
            newpassword: newpassword,
            verify_link: "reset_password",
          },
        },
        { headers: { region: region } }
      );
    } catch (error) {
      throw new Error(
        error.response.data.message
          ? error.response.data.message
          : error.response.data
      );
    }
  }

  static async logout() {
    try {
      const { region, oktaSid } = store.state;
      await apiBase.delete(`/user/logout`, {
        headers: {
          region: region,
          OKTA_SID: oktaSid,
        },
      });
    } catch (e) {
      throw new Error(e.message);
    }
  }
}

export default Api;
