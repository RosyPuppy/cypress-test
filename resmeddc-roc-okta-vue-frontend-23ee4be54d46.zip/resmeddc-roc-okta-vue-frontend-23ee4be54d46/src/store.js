import { createStore } from "vuex";
import account from "./assets/account.json";
import ptbr from "./assets/content_files/pt.json"
import esxl from "./assets/content_files/es.json"
import nbno from "./assets/content_files/nb.json"
import svse from "./assets/content_files/sv.json"
import dadk from "./assets/content_files/da.json"
import fifi from "./assets/content_files/fi.json"
import eng from "./assets/content_files/en.json"
import dech from "./assets/content_files/de.json"
import frch from "./assets/content_files/fr.json"
import dede from "./assets/content_files/ger.json"
import essp from "./assets/content_files/spain.json"




const regionContent = {
  "en-us": eng,
  "en-au": eng,
  "en-in": eng,
  "en-ap": eng,
  "en-gb": eng,
  "pt-br": ptbr,
  "da-dk": dadk,
  "sv-se": svse,
  "es-xl": esxl,
  "fi-fi": fifi,
  "nb-no": nbno,
  "de-ch":dech,
  "fr-ch":frch,
  "de-de":dede,
  "es-sp":essp
 
  
}

const store = createStore({
  state() {
    return {
      loggeduser: {},
      region: `en-us`,
      language: eng,
      defaultLanguage: account.language.default.copy,
      isEuReg: false,
      oktaSid: "",
      oktaEmail: "",
      pdfPath: "",
      softwarePath: "",
      subscriptions: null,
      userRecords: [],
      userRecCount: 0,
    };
  },
  getters: {
    getRegion(state) {
      return state.region;
    },
    getIsEuReg(state) {
      return state.isEuReg;
    },
  },
  mutations: {
    addUser: (state, userPayload) => {
      state.loggeduser = userPayload;
    },
    setRegion: (state, regionValue) => {
      // Update only if there is a change
      if (regionValue != state.region) {
        const default_region = regionValue;
        state.language = regionContent[`${default_region}`];
        state.region = regionValue;
        // check if region is EU
        const euList = [
          "fi-fi",
          "sv-se",
          "en-gb",
          "de-de",
          "fr-fr",
          "de-ch",
          "fr-ch",
          "nb-no",
          "da-dk",
          "es-sp",
          
        ];
        if (euList.indexOf(regionValue) > -1) {
          state.isEuReg = true;
        }
      }
    },
    setOktaSid: (state, oktaSidValue) => {
      state.oktaSid = oktaSidValue;
    },
    setOktaEmail: (state, oktaEmailValue) => {
      state.oktaEmail = oktaEmailValue;
    },
    setPdfPath: (state, pdfPathValue) => {
      state.pdfPath = pdfPathValue;
    },
    setSoftwarePath: (state, softwarePathValue) => {
      state.softwarePath = softwarePathValue;
    },
    resetUser: (state) => {
      state.loggeduser = {};
      state.oktaSid = "";
    },
    setSubscriptions: (state, subscriptions) => {
      state.subscriptions = subscriptions;
    },
    setUserRecords: (state, records) => {
      state.userRecords = records;
    },
    setUserRecCount: (state, count) => {
      state.userRecCount = count;
    },
  },
  actions: {
    setOktaSid: ({ commit }, oktaSid) => {
      commit("setOktaSid", oktaSid);
    },
    setOktaEmail: ({ commit }, oktaEmail) => {
      commit("setOktaEmail", oktaEmail);
    },
    setLoggedUser: ({ commit }, user) => {
      commit("addUser", user);
    },
    setSubscriptions: ({ commit }, subscriptions) => {
      commit("setSubscriptions", subscriptions);
    },
    setUserRecords: ({ commit }, userRecords) => {
      commit("setUserRecords", userRecords.records);
      commit("setUserRecCount", userRecords.count);
    },
  },
});

export default store;
