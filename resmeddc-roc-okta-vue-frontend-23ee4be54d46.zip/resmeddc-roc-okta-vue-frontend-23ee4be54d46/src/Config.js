require("dotenv").config();
console.log(process.env.NODE_ENV);
export const OKTA_DOMAIN = process.env.VUE_APP_OKTA_DOMAIN;
export const OKTA_SESSION = process.env.VUE_APP_OKTA_SESSION;
export const OKTA_SSO_URL = process.env.VUE_APP_OKTA_SSO_URL;
export const OKTA_ASSETS_DOMAIN = process.env.VUE_APP_OKTA_ASSETS_DOMAIN;
export const OKTA_SUPPORT_DOMAIN = process.env.VUE_APP_OKTA_SUPPORT_DOMAIN;
