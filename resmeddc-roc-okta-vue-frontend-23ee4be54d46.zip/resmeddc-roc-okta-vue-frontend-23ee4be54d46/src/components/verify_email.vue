<template>
  <div class="mt-5">
    <div class="mt-5">
      <div class="container mt-5">
        <pageloader v-if="pageload" />
        <div v-else>
          <div class="row">
            <div class="col-lg-7 col-md-0 m-auto">
              <div v-if="isVerified" class="signin mt-5">
                <success-message
                  :header="language.verified_header"
                  :message="language.verify_thanks_email"
                  :signlabel="language.verify_continue_label"
                ></success-message>
              </div>
              <div v-if="!isVerified && !isLoading" class="signin mt-5">
                <success-message
                  error
                  :header="language.verify_error_header"
                  :message="verifyEmailErrMsg"
                  :signlabel="language.verify_continue_label"
                ></success-message>
              </div>

              <div></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapState, mapMutations } from "vuex";
import axios from "axios";
import pageloader from "../components/pageloader";
import "vue-loading-overlay/dist/vue-loading.css";
import { OKTA_DOMAIN } from "@/Config";
import SuccessMessage from "../views/SuccessMessage.vue";

export default {
  components: {
    pageloader,
    SuccessMessage,
  },
  name: "app",
  data() {
    return {
      isLoadingLoader: false,
      isLoading: false,
      pageload: false,
      params: String,
      verifyEmailErrMsg: String,
      showError: false,
      isVerified: true,
    };
  },
  computed: {
    ...mapState(["loggeduser", "language", "region", "oktaSid"]),
  },
  async mounted() {
    this.setRegion(this.$route.params.region);
    this.verifyChangeEmail();
  },
  methods: {
    ...mapMutations(["addUser", "setRegion", "setOktaSid"]),
    removeError() {
      this.showError = false;
    },
    signin: function () {
      this.$router.push("signin.html");
    },
    async verifyChangeEmail() {
      this.params = this.$route.query.token;
      console.log(this.$route.query.token);
      //const token = this.$route.query['token='];
      this.pageload = true;

      let headers = {};
      let userLogin = {};
      headers = {
        region: `${this.region}`,
        "Content-Type": "application/json",
      };
      userLogin = {
        user: {
          token: `${this.params}`,
          verify_link: "change_email",
        },
      };

      await axios
        .post(OKTA_DOMAIN + "v1/user/verify", userLogin, { headers })
        .then((response) => {
          console.log(response);
          this.pageload = false;
          this.isVerified = true;
        })
        .catch((error) => {
          console.log("error", error);
          this.isLoading = false;
          this.pageload = false;
          this.showError = true;
          this.isVerified = false;
          this.verifyEmailErrMsg = error.response.data.message
            ? error.response.data.message
            : error.response.data;
        });
    },
  },
};
</script>
<style scoped>
.signinbtn {
  padding: 12px 40px;
  border-radius: 10px;
  font-size: 19px;
}
.info {
  font-size: 20px;
  color: #555;
}
.danger {
  background: red;
  color: #fff;
  font-size: 18px;
  padding: 0px 6px;
}
</style>