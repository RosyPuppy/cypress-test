<template>
  <div class="footer py-2 mt-5">
    <p>©2000-2022 ResMed. {{ language.footer_allrights_label}}.</p>
  </div>
</template>
<script>
import { mapState} from "vuex";
export default {
  computed: {
    ...mapState(["language", "region"]),
  },
};
</script>
<style scoped>
</style>