<template>
      <div class="container mt-5 mt-md-4 mt-lg-0">
        <pageloader v-if="pageload" />
        <div v-else>
        <div class="row">
          <div class="col-lg-7 m-auto">
            <div class="signin mt-0">
              <h2 class="text-center m-5 title">{{language.changeemail_header}}</h2>
              <div v-if="showError">
                <p class="bg-danger p-2 text-light already-text">
                  {{ changeEmailErrMsg }}
                </p>
              </div>
              <form v-if="!showSuccessMessage" @submit.prevent="editChangeEmail">
                <div class="form-group">
                  <input
                    type="email"
                    @input="removeError()"
                    v-model="user.email"
                    :placeholder="language.email_label"
                    id="email"
                    name="email"
                    class="form-control"
                    :class="{ 'is-invalid': submitted && v$.user.email.$error }"
                  />
                  <div
                    v-if="submitted && v$.user.email.$error"
                    class="invalid-feedback"
                  >
                    <span v-if="v$.user.email.required.$invalid"
                      >{{language.enter_email}}</span
                    >
                    <span v-if="v$.user.email.email.$invalid">{{language.enter_valid_email}}</span>
                  </div>
                </div>
                <div class="pb-4 info">
                  {{language.changeemail_instructions}}
                </div>
                <div class="form-group">
                  <vue-button-spinner
                  class="btn btn-primary res-btn-primary res-spin-btn mt-3"
                  :is-loading="isLoading"
                  :disabled="v$.$invalid"
                  :class="{
                      'disabled-button-color': v$.$invalid,
                    }"
                  >
                    {{language.changeemail_label}}
                  </vue-button-spinner>
                </div>
                <div>
                  <div class="row">
                    <div class="col-md-6 text-left">
                      <router-link
                        class="nav-link links backlink"
                        to="myaccount.html"
                        >{{language.backtoaccount_label}}</router-link
                      >
                    </div>
                  </div>
                </div>
              </form>
              <div v-if="showSuccessMessage">
                  <img src="@/assets/images/envelope.png" />
                  <p class="mt-3 mb-0">{{ language.check_your_email }}</p>
                  <p class="mb-0">{{ language.verification_instructions }}</p>
                  <p class="mt-3 mb-0">{{ user.email }}</p>
                <div>
                  <div class="row">
                    <div class="col-md-10 text-left d-flex align-items-center">
                      <div>
                        <span class="res-link-primary">
                        <a href="javascript:void(0)" @click="editChangeEmail()">
                          {{ language.resend_label }}
                        </a>
                        <img
                          v-if="isLoading"
                          src="@/assets/images/spinner.gif"
                        />
                        </span
                        ><span class="mx-2">|</span>
                      </div>
                      <router-link class="nav-link links backlink" to="myaccount.html">
                        {{language.backtoaccount_label}}
                      </router-link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
  </div>
</template>

<script>
import { required, email } from "vuelidate/lib/validators";
import useVuelidate from "@vuelidate/core";
import { mapState, mapMutations } from "vuex";
import axios from "axios";
import VueButtonSpinner from "../components/spinner";
import pageloader from "../components/pageloader";
import "vue-loading-overlay/dist/vue-loading.css";
import { OKTA_DOMAIN, OKTA_SESSION } from "@/Config";

export default {
   setup() {
    const v$ = useVuelidate();
    return { v$ };
  },
  components: {
    VueButtonSpinner,
    pageloader,
  },
  name: "app",
  data() {
    return {
      user: {
        email: "",
      },
      submitted: false,
      isLoadingLoader: false,
      isLoading: false,
      showSuccessMessage: false,
      pageload: false,
      changeEmailErrMsg: String,
      showError: false,
    };
  },
  validations: {
    user: {
      email: { required, email },
    },
  },
  computed: {
    ...mapState(["loggeduser", "language", "region", "oktaSid"]),
  },
  async mounted() {
    this.setRegion(this.$route.params.region);
    await this.getUserSession();
  },
  methods: {
    ...mapMutations(["addUser", "setRegion", "setOktaSid"]),
    removeError() {
      this.showError = false;
    },
    async getUserSession() {
      this.pageload = true;
      axios
        .get(OKTA_SESSION + "/api/v1/sessions/me", {
          headers: {
            "Content-Type": "application/json",
          },
          withCredentials: true,
        })
        .then((response) => {
          console.log(response.data.id);
          this.setOktaSid(response.data.id);
          this.oktaEmail = response.data.login;
          this.pageload = false;
        })
        .catch((error) => {
          this.pageload=false
          console.log("error", error);
          this.$router.push("signin.html");
          // If API returns error, clear cookies
        });
    },
    async editChangeEmail() {
      this.isLoading = true;
      axios
        .get(OKTA_SESSION + "/api/v1/sessions/me", {
          headers: {
            "Content-Type": "application/json",
          },
          withCredentials: true,
        })
        .then((response) => {
          console.log(response.data.id);
          this.setOktaSid(response.data.id);
          this.oktaEmail = response.data.login;
          this.changeEmail();
        })
        .catch((error) => {
          //this.pageload=false
          console.log("error", error);
          this.isLoading = false;
          this.$router.push("signin.html");
          // If API returns error, clear cookies
        });
    },
    async changeEmail() {
      this.submitted = true;

      // stop here if form is invalid
      this.v$.$touch();
      if (this.v$.$invalid) {
        return;
      }

      let headers = {};
      let userLogin = {};
      headers = {
          region: `${this.region}`,
          "Content-Type": "application/json",
          OKTA_SID: `${this.oktaSid}`,
        };
        userLogin = {
          user: {
							"oldemail": this.oktaEmail,
							"newemail": this.user.email,
							"verify_link": "change_email",
							"channel": window.location.origin,
						},
          role: "PARTNER",
        };

      await axios
        .post(OKTA_DOMAIN + "v1/user/request_verify", userLogin, { headers })
        .then((response) => {
            console.log(response);
            this.showSuccessMessage = true;
            this.isLoading = false;
        }).catch((error) => {
          console.log("error", error);
          this.showSuccessMessage = false;
          this.isLoading = false; 
          this.showError = true;
          this.changeEmailErrMsg = error.response.data.message;
        });
    },
  },
};
</script>
<style scoped>
.signin {
  border-radius: 10px;
  margin-top: auto;
  margin-bottom: auto;
}
.signin input {
  height: 48px;
  border-radius: 7px;
  background-color: #f4f4f4;
  color: #555;
  border: 1px solid #000;
}
.signinbtn {
  padding: 12px 40px;
  border-radius: 10px;
  font-size: 19px;
}
.links {
  font-size: 18px;
}
.info {
  font-size: 20px;
  color: #555;
}
.disabled-button-color {
    background: #c5c0c0 !important;
    border-color: #c5c0c0 !important;
}
.backlink {
 color:blue !important;
}
</style>
