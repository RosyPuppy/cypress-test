<template>
  <Navbar
    :logout="logout"
    :loggeduser="loggeduser"
    :region="getRegion"
    :isEuReg="getIsEuReg"
    :language="language"
  ></Navbar>
  <div class="d-none d-lg-block py-3 border-bottom border-dark">
    <div class="container">
      <a :href="`https://resmed.com`" target="_blank" class="navbar-brand"
        ><img :src="logo"
      /></a>
    </div>
  </div>
</template>
<script>
import resmedColor from "@/assets/images/logo-resmed-color.svg";
import { mapState, mapMutations, mapGetters } from "vuex";
import Api from "@/api";
export default {
  data() {
    return { logo: resmedColor };
  },
  computed: {
    ...mapState(["loggeduser", "region", "oktaSid", "language"]),
    ...mapGetters(["getRegion", "getIsEuReg"]),
  },
  methods: {
    ...mapMutations(["resetUser"]),
    logout: async function() {
      try {
        await Api.logout();
        // remove all cookie
        const allCookies = this.$cookies.keys();
        const _self = this;
        allCookies.map((cookie) => {
          _self.$cookies.remove(
            cookie,
            null,
            window.location.hostname === "localhost"
              ? "localhost"
              : "resmed.com"
          );
        });
        this.$local.remove("pdfPath");
        this.$local.remove("softwarePath");
        this.resetUser();
        this.$router.push(`/${this.region}/signin.html`);
      } catch (error) {
        console.error(error.message);
      }
    },
  },
};
</script>
<style scoped></style>
