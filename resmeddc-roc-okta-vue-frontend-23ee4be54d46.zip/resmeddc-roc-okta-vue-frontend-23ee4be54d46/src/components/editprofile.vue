<template>
  <div class="container mt-5 mt-md-4 mt-lg-0">
    <pageloader v-if="pageload" />
    <div v-else>
      <div class="row">
        <div class="col-lg-7 m-auto">
          <div class="editprofile mt-5">
            <h2 class="text-center py-3">{{ language.editprofile_header }}</h2>
            <div>
              <transition name="fade">
                <p class="" v-if="showSuccessMessage">
                  <span
                    ><img
                      src="@/assets/images/img-check-square-20x20.png"
                      alt="img-check-square"/></span
                  ><span>{{ language.Profile_Updated }}</span>
                </p>
              </transition>
            </div>
            <div
              v-if="loggeduser.country == 'lat'"
              class="latin-user-notification"
            >
              <p>Elija su país en la lista desplegable destacado abajo</p>
            </div>
            <div
              v-if="`${$local.pdfPath.message}` != {}"
              class="latin-user-notification"
            >
              <a
                v-bind:href="
                  `${oktaAssestsDomain}` + `${$local.pdfPath.message}`
                "
                target="_blank"
                >Ver documento PDF</a
              >
            </div>
            <div
              v-if="`${$local.softwarePath.message}` != {}"
              class="latin-user-notification"
            >
              <a
                v-bind:href="
                  `${oktaSupportDomain}` + `${$local.softwarePath.message}`
                "
                target="_blank"
                >Ir a la página de descarga de software</a
              >
            </div>
            <form @submit.prevent="editprofile">
              <div class="form-group" v-bind:class="getClass()">
                <input
                  type="text"
                  @input="editProfileChange()"
                  v-model="user.firstName"
                  id="firstName"
                  :placeholder="language.myaccount_firstname_label"
                  name="firstName"
                  class="form-control"
                  :class="{
                    'is-invalid': submitted && v$.user.firstName.$error,
                  }"
                />
                <div
                  v-if="submitted && v$.user.firstName.$error"
                  class="invalid-feedback"
                >
                  <span v-if="v$.user.firstName.required.$invalid">{{
                    language.Enter_FirstName
                  }}</span>
                </div>
              </div>
              <div class="form-group">
                <input
                  type="text"
                  @input="editProfileChange()"
                  v-model="user.lastName"
                  id="lastName"
                  name="lastName"
                  :placeholder="language.myaccount_lastname_label"
                  class="form-control"
                  :class="{
                    'is-invalid': submitted && v$.user.lastName.$error,
                  }"
                />
                <div
                  v-if="submitted && v$.user.lastName.$error"
                  class="invalid-feedback"
                >
                  <span v-if="v$.user.lastName.required.$invalid">{{
                    language.Enter_LastName
                  }}</span>
                </div>
              </div>
              <div v-if="region == 'en-us'" class="form-group">
                <select
                  v-model="user.jobFunction"
                  @input="editProfileChange()"
                  id="jobFunction"
                  name="jobFunction"
                  class="form-control"
                  :class="{
                    'is-invalid': submitted && v$.user.jobFunction.$error,
                  }"
                >
                  <option value="">
                    {{ language.job_function_text }}
                  </option>
                  <option
                    v-bind:value="item.code"
                    v-for="item in jobFunctionList"
                    :key="item.code"
                  >
                    {{ item.name }}
                  </option>
                </select>
                <div
                  v-if="submitted && v$.user.jobFunction.$error"
                  class="invalid-feedback error_show"
                >
                  <span v-if="v$.user.jobFunction.required.$invalid">{{
                    language.Enter_JobFunction
                  }}</span>
                </div>
              </div>
              <div v-if="region == 'en-us'" class="form-group">
                <select
                  v-model="user.businessType"
                  @input="editProfileChange()"
                  id="businessType"
                  name="businessType"
                  class="form-control"
                  :class="{
                    'is-invalid': submitted && v$.user.businessType.$error,
                  }"
                >
                  <option value="">
                    {{ language.business_type_text }}
                  </option>
                  <option
                    v-bind:value="item.code"
                    v-for="item in businessTypeList"
                    :key="item.code"
                  >
                    {{ item.name }}
                  </option>
                </select>
                <div
                  v-if="submitted && v$.user.businessType.$error"
                  class="invalid-feedback error_show"
                >
                  <span v-if="v$.user.businessType.required.$invalid">{{
                    language.Enter_BusinessType
                  }}</span>
                </div>
              </div>
              <div class="form-group">
                <select
                  v-model="user.country"
                  @input="editProfileChange()"
                  id="country"
                  name="country"
                  class="form-control"
                  :class="{
                    'is-invalid': submitted && v$.user.country.$error,
                  }"
                >
                  <option value="">
                    {{ language.country_region_text }}
                  </option>
                  <option
                    v-bind:value="item.code"
                    v-for="item in countryList"
                    :disabled="item.code == 'lat'"
                    :class="{
                      'disabled-user': item.code == 'lat',
                    }"
                    :key="item.code"
                  >
                    {{ item.name }}
                  </option>
                </select>
                <div
                  v-if="submitted && v$.user.country.$error"
                  class="invalid-feedback error_show"
                >
                  <span v-if="v$.user.country.required.$invalid">{{
                    language.Enter_CountryName
                  }}</span>
                </div>
              </div>
              <div class="form-group">
                <input
                  type="text"
                  @input="editProfileChange()"
                  v-model="user.organisation"
                  id="organisation"
                  name="organisation"
                  :placeholder="language.myaccount_organisation_label"
                  class="form-control"
                  :class="{
                    'is-invalid': submitted && v$.user.organisation.$error,
                  }"
                />
                <div
                  v-if="submitted && v$.user.organisation.$error"
                  class="invalid-feedback error_show"
                >
                  <span v-if="v$.user.organisation.required.$invalid">{{
                    language.Org_Name
                  }}</span>
                </div>
              </div>
              <div v-if="region == 'en-us'" class="form-group">
                <input
                  type="text"
                  @input="editProfileChange()"
                  v-model="user.zipCode"
                  id="zipCode"
                  name="zipCode"
                 :placeholder="language.myaccount_zipcode_label"
                  class="form-control"
                  :class="{
                    'is-invalid': submitted && v$.user.zipCode.$error,
                  }"
                />
                <div
                  v-if="submitted && v$.user.zipCode.$error"
                  class="invalid-feedback error_show"
                >
                  <span v-if="v$.user.zipCode.required.$invalid">{{
                    language.Enter_ZipCode
                  }}</span>
                </div>
              </div>
              <div class="form-group">
                <select
                  v-model="user.language"
                  @input="editProfileChange()"
                  id="language"
                  name="language"
                  class="form-control"
                  :class="{
                    'is-invalid': submitted && v$.user.language.$error,
                  }"
                >
                  <option value="">
                    {{ language.choose_language }}
                  </option>
                  <option
                    v-bind:value="item.code"
                    v-for="item in languageList"
                    :key="item.code"
                  >
                    {{ item.name }}
                  </option>
                </select>
                <div
                  v-if="submitted && v$.user.language.$error"
                  class="invalid-feedback error_show"
                >
                  <span v-if="v$.user.language.required.$invalid">{{
                    language.error_language
                  }}</span>
                </div>
              </div>
              <div class="form-group">
                <vue-button-spinner
                  class="btn btn-primary res-btn-primary res-spin-btn mt-3"
                  :is-loading="isLoading"
                  :disabled="!showupdateProfileBtn"
                  :class="{
                    'disabled-button-color': !showupdateProfileBtn,
                  }"
                >
                  {{ language.updateprofile_label }}
                </vue-button-spinner>
              </div>
              <div>
                <router-link class="nav-link links backlink" to="myaccount.html">{{
                  language.backtoaccount_label
                }}</router-link>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { required } from "vuelidate/lib/validators";
import useVuelidate from "@vuelidate/core";
import { mapState, mapMutations } from "vuex";
import axios from "axios";
import pageloader from "../components/pageloader";
import VueButtonSpinner from "../components/spinner";
import "vue-loading-overlay/dist/vue-loading.css";
import {
  OKTA_DOMAIN,
  OKTA_SESSION,
  OKTA_ASSETS_DOMAIN,
  OKTA_SUPPORT_DOMAIN,
} from "@/Config";
export default {
  setup() {
    const v$ = useVuelidate();
    return { v$ };
  },
  components: {
    pageloader,
    VueButtonSpinner,
  },
  name: "app",
  data() {
    return {
      user: {
        firstName: "",
        lastName: "",
        organisation: "",
        country: "",
        language: "",
        jobFunction: "",
        businessType: "",
        zipCode: "",
      },
      isLoadingLoader: false,
      adminUser: false,
      pageload: false,
      countryList: [],
      languageList: [],
      jobFunctionList: [],
      businessTypeList: [],
      isLoading: false,
      showupdateProfileBtn: false,
      submitted: false,
      showSuccessMessage: false,
      oktaAssestsDomain: OKTA_ASSETS_DOMAIN,
      oktaSupportDomain: OKTA_SUPPORT_DOMAIN,
    };
  },

  validations() {
    const user = {
      user: {
        firstName: { required },
        lastName: { required },
        organisation: { required },
        country: { required },
        language: { required },
      },
    };
    if (this.region == "en-us") {
      user.user.jobFunction = { required };
      user.user.businessType = { required };
      user.user.zipCode = { required };
    }
    return user;
  },

  computed: {
    ...mapState([
      "loggeduser",
      "language",
      "region",
      "oktaSid",
      "pdfPath",
      "softwarePath",
    ]),
  },
  async mounted() {
    this.setRegion(this.$route.params.region);
    await this.getUserSession();
    await this.getUserCountries();
    await this.getUserLanguages();
    if (this.$route.params.region == "en-us") {
      await this.getUserJobFunctions();
      await this.getUserbusinessType();
    }
  },
  methods: {
    ...mapMutations(["addUser", "setRegion", "setOktaSid"]),
    editProfileChange() {
      this.showupdateProfileBtn = true;
    },
    getClass() {
      return {
        "latin-user-field": this.loggeduser.country == "lat",
      };
    },
    async getUserSession() {
      this.pageload = true;
      axios
        .get(OKTA_SESSION + "/api/v1/sessions/me", {
          headers: {
            "Content-Type": "application/json",
          },
          withCredentials: true,
        })
        .then((response) => {
          console.log(response.data.id);
          this.setOktaSid(response.data.id);
          this.oktaEmail = response.data.login;
          this.getUserViewProfile();
        })
        .catch((error) => {
          //this.pageload=false
          console.log("error", error);
          this.$router.push("signin.html");
          // If API returns error, clear cookies
        });
    },

    async getUserCountries() {
      this.pageload = true;
      axios
        .get(OKTA_DOMAIN + "v1/common/country/list", {
          headers: {
            "Content-Type": "application/json",
            region: `${this.$route.params.region}`,
          },
          withCredentials: true,
        })
        .then((response) => {
          this.countryList = response.data.countries;
        })
        .catch((error) => {
          //this.pageload=false
          console.log("error", error);
          this.$router.push("signin.html");
          // If API returns error, clear cookies
        });
    },

    async getUserLanguages() {
      this.pageload = true;
      axios
        .get(OKTA_DOMAIN + "v1/common/language/list", {
          headers: {
            "Content-Type": "application/json",
            region: `${this.$route.params.region}`,
          },
          withCredentials: true,
        })
        .then((response) => {
          this.languageList = response.data.languages;
        })
        .catch((error) => {
          //this.pageload=false
          console.log("error", error);
          this.$router.push("signin.html");
          // If API returns error, clear cookies
        });
    },

    async getUserJobFunctions() {
      this.pageload = true;
      axios
        .get(OKTA_DOMAIN + "v1/common/job_function/list", {
          headers: {
            "Content-Type": "application/json",
            region: `${this.$route.params.region}`,
          },
          withCredentials: true,
        })
        .then((response) => {
          this.jobFunctionList = response.data.jobFunctions;
        })
        .catch((error) => {
          //this.pageload=false
          console.log("error", error);
          this.$router.push("signin.html");
          // If API returns error, clear cookies
        });
    },

    async getUserbusinessType() {
      this.pageload = true;
      axios
        .get(OKTA_DOMAIN + "v1/common/business_type/list", {
          headers: {
            "Content-Type": "application/json",
            region: `${this.$route.params.region}`,
          },
          withCredentials: true,
        })
        .then((response) => {
          this.businessTypeList = response.data.businessTypes;
        })
        .catch((error) => {
          //this.pageload=false
          console.log("error", error);
          this.$router.push("signin.html");
          // If API returns error, clear cookies
        });
    },

    async getUserViewProfile() {
      axios
        .get(
          OKTA_DOMAIN +
            "v1/account/view/" +
            `${this.oktaEmail}` +
            "/partner/50/pending",
          {
            headers: {
              "Content-Type": "application/json",
              region: `${this.$route.params.region}`,
              OKTA_SID: `${this.oktaSid}`,
            },
            withCredentials: true,
          }
        )
        .then((response) => {
          console.log(response.data);
          this.addUser(response.data.user);
          this.user = response.data.user;
          this.pageload = false;
        })
        .catch((error) => {
          console.log("error", error);
          this.$router.push("signin.html");
          this.pageload = false;
          // If API returns error, clear cookies
        });
    },
    async enter() {
      var that = this;

      setTimeout(function() {
        that.showSuccessMessage = false;
      }, 3000); // hide the message after 3 seconds
    },
    async editprofile() {
      this.submitted = true;
      // stop here if form is invalid
      this.v$.$touch();
      if (this.v$.$invalid) {
        return;
      }
      this.isLoading = true;
      this.showupdateProfileBtn = false;
      let headers = {};
      let userLogin = {};
      headers = {
        region: `${this.region}`,
        "Content-Type": "application/json",
        OKTA_SID: `${this.oktaSid}`,
      };
      userLogin = {
        user: this.user,
        role: "PARTNER",
      };

      await axios
        .put(OKTA_DOMAIN + "v1/account/update", userLogin, { headers })
        .then((response) => {
          this.showSuccessMessage = true;
          console.log(response);
          this.loggeduser.firstName = this.user.firstName;
          this.$cookies.set(
            "b2bFirstName",
            this.user.firstName,
            null,
            null,
            "resmed.com"
          );
          this.$cookies.set(
            "b2bFirstName",
            this.user.firstName,
            null,
            null,
            "localhost"
          );
          this.isLoading = false;
          this.showupdateProfileBtn = false;
          this.enter();
        })
        .catch((error) => {
          console.log("error", error);
          this.isLoading = false;
          this.showSuccessMessage = false;
          this.showupdateProfileBtn = false;
        });
    },
  },
};
</script>
<style scoped>
.editprofile {
  border-radius: 10px;
  margin-top: auto;
  margin-bottom: auto;
}
.info {
  font-size: 20px;
  color: #555;
}
.editprofile input,
.editprofile select {
  height: 48px;
  border-radius: 7px;
  background-color: #f4f4f4;
  color: #555;
  border: 1px solid #000;
}
.editprofilebtn {
  padding: 12px 40px;
  border-radius: 10px;
  font-size: 19px;
}
.links {
  font-size: 18px;
}
.form-check-input {
  height: 16px !important;
}
.success_message {
  margin-bottom: 10px;
  background: #06aa66;
  color: #fff;
}
.success_message span {
  display: inline-block;
  padding-left: 10px;
  line-height: 35px;
  font-size: 16px;
  font-weight: 700;
}
.form-control {
  appearance: auto;
}
.latin-user-notification {
  background-color: #f4f4f4;
  padding: 10px 10px 1px 10px;
  text-align: center;
  border-radius: 3px 3px 0 0;
}
.latin-user-field {
  margin-top: 10px;
}
.disabled-user {
  color: #c5c0c0 !important;
}
.disabled-button-color {
  background: #c5c0c0 !important;
  border-color: #c5c0c0 !important;
}
.backlink{
  color:blue !important;
}
</style>
