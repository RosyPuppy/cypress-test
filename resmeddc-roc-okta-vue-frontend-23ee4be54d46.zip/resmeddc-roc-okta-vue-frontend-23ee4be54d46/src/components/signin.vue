<template>
  <div class="mt-5">
    <div class="container mt-5">
      <div class="row">
        <div class="col-xs-12 col-md-8 col-lg-6 col-xl-5 mt-0 m-auto">
          <div class="signin mt-5">
            <h2 class="text-center m-3">
              {{ language.signin_header }}
            </h2>
            <div>
              <div
                class="nav-link links mt-5 mb-4 text-center"
                @click="ssoLogin"
              >
                {{language.signup_sso_label}}
              </div>
            </div>
            <div v-if="already_exist">
              <p class="error-dialog p-2 text-light already-text">
                {{ language.alreadyRegstEmailTxt }}
                <span
                  @click.prevent="already_exist_model = !already_exist_model"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="22"
                    height="22"
                    fill="currentColor"
                    class="bi bi-info-circle m-1"
                    viewBox="0 0 16 16"
                  >
                    <path
                      d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"
                    />
                    <path
                      d="M8.93 6.588l-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"
                    />
                  </svg>
                </span>
              </p>
            </div>
            <div v-if="showError">
              <p class="bg-danger p-2 text-light already-text">
                {{ signinErrMsg }}
              </p>
            </div>
            <!-- model pop start -->
            <vue-final-modal
              class="modal"
              v-model="already_exist_model"
              name="example"
            >
              <div class="modal-wrapper">
                <div class="modal-container">
                  <content select=".modal-header">
                    <div class="modal-header">
                      <div class="row">
                        <div class="col-10">
                          <h2>
                            {{ language.alreadyRegisterUser_model_title }}
                          </h2>
                        </div>
                        <div class="col-2 m-auto">
                          <button
                            type="button"
                            @click.prevent="
                              already_exist_model = !already_exist_model
                            "
                            class="close"
                            aria-label="Close"
                          >
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </content>
                  <div class="modal-body">
                    <p>
                      {{ language.alreadyRegisterUser_model_content1 }}
                    </p>
                    <ul class="modal-desc-ul">
                      <li>
                        <a
                          href="javascript:void(0)"
                          @click="resendVerification()"
                          >{{ language.alreadyRegisterUser_model_clickhere }}</a
                        >
                        {{ language.alreadyRegisterUser_model_content2 }}
                        <img
                          v-if="inprogress"
                          src="@/assets/images/spinner.gif"
                        />
                        <img
                          v-if="emailResent"
                          src="@/assets/images/img-check-square-20x20.png"
                        />
                      </li>
                      <li>
                        {{ language.alreadyRegisterUser_model_content3 }}
                        {{ language.alreadyRegisterUser_model_content4 }}
                      </li>
                      <li>
                        {{ language.alreadyRegisterUser_model_content5 }}
                      </li>
                      <li>
                        {{ language.alreadyRegisterUser_model_content6 }}
                        {{ language.alreadyRegisterUser_model_clickhere }}
                        {{ language.alreadyRegisterUser_model_content7 }}
                      </li>
                      <li>
                        {{ language.alreadyRegisterUser_model_content8 }}
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </vue-final-modal>
            <!-- model pop end -->
            <form @submit.prevent="signin">
              <div class="form-group">
                <input
                  type="email"
                  v-model="user.email"
                  :placeholder="language.email_label"
                  id="email"
                  name="email"
                  class="form-control"
                  :class="{ 'is-invalid': submitted && v$.user.email.$error }"
                />
                <div
                  v-if="submitted && v$.user.email.$error"
                  class="invalid-feedback"
                >
                  <span v-if="v$.user.email.required.$invalid">{{
                    language.enter_email
                  }}</span>
                  <span v-if="v$.user.email.email.$invalid">{{
                    language.email_valid_error
                  }}</span>
                </div>
              </div>
              <div class="form-group">
                <div class="input-group">
                  <input
                    v-bind:type="[showPassword ? 'text' : 'password']"
                    @input="signinChange()"
                    v-model="user.password"
                    :placeholder="language.password_label"
                    id="password"
                    name="password"
                    class="form-control"
                    :class="{
                      'is-invalid': submitted && v$.user.password.$error,
                    }"
                  />
                  <div class="input-group-append">
                    <span
                      class="input-group-text show-icon"
                      @click="showPassword = !showPassword"
                      ><i
                        v-bind:class="[
                          showPassword ? 'fa fa-eye' : 'fa fa-eye-slash',
                        ]"
                        aria-hidden="true"
                      ></i
                    ></span>
                  </div>
                  <div
                    v-if="submitted && v$.user.password.$error"
                    class="invalid-feedback"
                  >
                    <span v-if="!v$.user.password.required.$invalid">{{
                      language.pass_enter_text
                    }}</span>
                    <span v-if="!v$.user.password.minLength.$invalid">{{
                      language.pass_valid
                    }}</span>
                  </div>
                </div>
              </div>
              <div
                class="
                  d-md-flex d-block
                  justify-content-between
                  align-items-center
                "
              >
                <vue-button-spinner
                  class="btn res-spin-btn my-2"
                  :is-loading="isLoading"
                  :disabled="isLoading"
                >
                  {{ language.signin_label }}
                </vue-button-spinner>
                <router-link class="nav-link links my-2" to="sign_help.html">{{
                  language.signin_Needhelp_signin
                }}</router-link>
              </div>
              <div
                class="
                  d-md-flex d-block
                  justify-content-between
                  align-items-center
                "
              >
                <router-link class="nav-link links my-2" to="signup.html">{{
                  language.signup_label
                }}</router-link>
                <router-link
                  class="nav-link links my-2"
                  to="resetpassword.html"
                  >{{ language.forgot_label }}</router-link
                >
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// import { reactive } from "vue";
import useVuelidate from "@vuelidate/core";
import { required, email, minLength } from "@vuelidate/validators";
import axios from "axios";
import { mapState, mapMutations } from "vuex";
import VueButtonSpinner from "../components/spinner";
import {
  OKTA_DOMAIN,
  OKTA_SESSION,
  OKTA_SSO_URL,
  OKTA_ASSETS_DOMAIN,
  OKTA_SUPPORT_DOMAIN,
} from "@/Config";
export default {
  setup() {
    const v$ = useVuelidate();
    return { v$ };
  },
  components: {
    VueButtonSpinner,
  },
  name: "app",
  data() {
    return {
      showPassword: false,
      already_exist: false,
      isLoading: false,
      showError: false,
      redirectUrl: String,
      signinErrMsg: String,
      already_exist_model: false,
      inprogress: false,
      emailResent: false,
      user: {
        email: "",
        password: "",
      },
      submitted: false,
      ssoUrl: OKTA_SSO_URL,
    };
  },
  validations: {
    user: {
      email: { required, email },
      password: { required, minLength: minLength(6) },
    },
  },
  computed: {
    ...mapState([
      "loggeduser",
      "language",
      "region",
      "pdfPath",
      "softwarePath",
    ]),
  },
  async created() {
    this.$cookies.remove(
      "redirectUrl",
      null,
      window.location.hostname === "localhost" ? "localhost" : "resmed.com"
    );
    let firstName = this.$cookies.get("b2bFirstName");
    if (firstName != null) {
      await this.getUserSession();
    }
  },
  async mounted() {
    this.setRegion(this.$route.params.region);
  },
  methods: {
    ...mapMutations(["setRegion", "setPdfPath", "setSoftwarePath"]),
    ssoLogin() {
      const curentUrl = location.href;
      if (curentUrl.includes("?redirect_to")) {
        const pdfUrl = this.$route.query["redirect_to"];
        this.setCookie("redirectUrl", pdfUrl);
      }
      window.location.href = this.ssoUrl;
    },
    setCookie(key, value) {
      this.$cookies.set(
        key,
        value,
        null,
        null,
        window.location.hostname === "localhost" ? "localhost" : "resmed.com"
      );
    },
    signinChange() {
      this.showError = false;
      this.already_exist = false;
    },
    showNotVeifiedUserModal() {
      this.alreadyExistModel = true;
    },
    // async resendVerification(){
    resendVerification: function() {
      this.user.channel = window.location.origin;
      this.user.verify_link = "account_verification";
      this.inprogress = true;
      this.emailResent = false;
      //this.user.email=this.user.email
      delete this.user.password;
      let headers = {
        region: `${this.region}`,
        "Content-Type": "application/json",
      };
      let userLogin = { user: this.user, role: "PARTNER" };
      axios
        .post(OKTA_DOMAIN + "v1/user/resend_verify", userLogin, { headers })
        .then(() => {
          this.inprogress = false;
          this.emailResent = true;
        })
        .catch(() => {
          this.inprogress = false;
          this.$router.push("signin.html");
        });
    },
    async getUserSession() {
      const curentUrl = location.href;
      const pdfUrl = curentUrl.split("?redirect_to=")[1];
      axios
        .get(OKTA_SESSION + "/api/v1/sessions/me", {
          headers: {
            "Content-Type": "application/json",
          },
          withCredentials: true,
        })
        .then((response) => {
          this.setOktaSid(response.data.id);
          let curentUrl = location.href;
          if (
            curentUrl.includes("?redirect_to") &&
            curentUrl.split(".")[2] == "pdf"
          ) {
            window.location.href = OKTA_ASSETS_DOMAIN + pdfUrl;
          } else if (curentUrl.includes("?redirect_to")) {
            window.location.href = OKTA_SUPPORT_DOMAIN + pdfUrl;
          } else {
            this.$router.push("myaccount.html");
          }
        })
        .catch(() => {
          this.$router.push("signin.html");
          const allCookies = this.$cookies.keys();
          const _self = this;
          allCookies.map((cookie) => {
            _self.$cookies.remove(
              cookie,
              null,
              window.location.hostname === "localhost"
                ? "localhost"
                : "resmed.com"
            );
          });
        });
    },
    async signin() {
      this.submitted = true;
      // stop here if form is invalid
      this.v$.$touch();
      if (this.v$.$invalid) {
        return;
      }
      this.isLoading = true;
      //const curentUrl = location.host+location.pathname;
      const curentUrl = location.href;
      let headers = {
        region: `${this.region}`,
        "Content-Type": "application/json",
      };
      let userLogin = {
        user: this.user,
        role: "PARTNER",
      };
      if (curentUrl.includes("?redirect_to")) {
        const pdfUrl = this.$route.query["redirect_to"];
        const docType = pdfUrl.split(".").splice(-1)[0];
        userLogin.material = {
          materialType: docType,
          materialPath: pdfUrl,
        };
      } else {
        userLogin.redirect_target = "Business Account";
      }

      axios
        .post(OKTA_DOMAIN + "v1/auth", userLogin, { headers })
        .then((response) => {
          if (response.data.success) {
            this.isLoading = false;
            const res = response.data.message.profile;
            if (res.user.origin == "en-uk" || res.user.origin == "en-epn") {
              res.user.origin = "en-gb";
            }
            this.setCookie("b2bFirstName", res.user.firstName);
            this.setCookie("RegionCode", res.user.origin);
            if (res.contentAccess.length) {
              let cookieStr = "";
              res.contentAccess.map((item) => {
                cookieStr +=
                  item.contentAccessTypeCode.toLowerCase() +
                  "_" +
                  item.contentAccessStatusCode.toLowerCase() +
                  ",";
              });
              this.setCookie("role", cookieStr);
            }

            this.setCookie(
              "redirectLoggedPath",
              `${window.location.origin}/${this.region}/myaccount.html`
            );

            // if does not belong to same region, then show alert
            if (this.region !== res.user.origin) {
              alert(this.language.alert_different_countries);
              window.location.href =
                response.data.message.redirectUrl +
                window.location.origin +
                "/" +
                res.user.origin +
                "/myaccount.html";
              return;
            }

            // If region is latam redirect to edit profile
            if (res.user.country == "lat") {
              window.location.href =
                response.data.message.redirectUrl +
                window.location.origin +
                "/" +
                res.user.origin +
                "/editprofile.html";
              return;
            }

            if (curentUrl.includes("?redirect_to")) {
              // set software url cookeis
              const pdfUrl = this.$route.query["redirect_to"];
              this.setCookie("SoftwareURL", pdfUrl);
              this.$local.set("pdfPath", { message: pdfUrl });
              const roleCookie = this.$cookies.get("role");
              let checkAccess = false;
              if (
                pdfUrl.includes("secure/clinical") &&
                roleCookie.includes("clinical_approved")
              ) {
                checkAccess = true;
              }

              if (
                pdfUrl.includes("secure/commercial") &&
                roleCookie.includes("commercial_approved")
              ) {
                checkAccess = true;
              }

              if (
                pdfUrl.includes("secure/tsp") &&
                roleCookie.includes("technical_approved")
              ) {
                checkAccess = true;
              }

              if (checkAccess) {
                this.setCookie("redirectUrl", pdfUrl);
              } else {
                alert(this.language.alert_access_deined);
              }
              window.location.href =
                response.data.message.redirectUrl +
                window.location.origin +
                "/" +
                this.region +
                "/myaccount.html";
              return;
            }

            // if nothig specific then take to myaccount
            window.location.href =
              response.data.message.redirectUrl +
              window.location.origin +
              "/" +
              res.user.origin +
              "/myaccount.html";
          }
        })
        .catch((error) => {
          if (error.response.data.message == "ACCOUNT_EXISTS") {
            this.already_exist = true;
            this.isLoading = false;
          } else {
            this.showError = true;
            this.signinErrMsg = error.response.data.message
              ? error.response.data.message
              : error.response.data;
            this.isLoading = false;
          }
        });
    },
  },
};
</script>
<style scoped lang="scss">
// @import "../assets/variables.scss";
.show-icon {
  border-top-right-radius: 7px !important;
  border-bottom-right-radius: 7px !important;
}
#password {
  border-top-right-radius: 0px !important;
  border-bottom-right-radius: 0px !important;
}
.signin {
  border-radius: 10px;
  margin-top: auto;
  margin-bottom: auto;
}
.signin input {
  height: 48px;
  border-radius: 7px;
  background-color: #f4f4f4;
  color: #555;
}
.res-spin-btn {
  display: inline-flex;
  background-color: $primary-color;
  padding: 1.2em 1.6em !important;
  border-radius: 6px !important;
  font-size: 18px !important;
  color: #fff !important;
  &:hover {
    background-color: #285e8e;
  }
}
.links {
  color: $primary-color;
  font-size: 18px;
  padding: 0 !important;
}
.links:hover {
  color: #d20d0d;
  text-decoration: underline;
  cursor: pointer;
}

.modal-header {
  display: block !important;
}
::v-deep .modal {
  display: flex;
  justify-content: center;
  align-items: center;
  overflow-y: auto;
}
::v-deep .modal-content {
  display: flex;
  flex-direction: column;
}
.modal-wrapper {
  display: table-cell;
  vertical-align: middle;
  transform: translate(-50%, -50%) !important;
  top: 50%;
  left: 50%;
  position: absolute;
}
.modal-container {
  background: #fff;
  width: 600px;
  border-radius: 5px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.33);
  transition: all 0.3s ease;
  margin: 0 auto;
  // padding: 20px 30px;
}
.modal-footer {
  margin-top: 15px;
}
.modal-enter,
.modal-leave {
  opacity: 0;
}
.modal-enter .modal-container,
.modal-leave .modal-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
.error-dialog {
  background-color: $secondary-color;
  border-radius: 5px;
}

/* Mobile view */
@include media-breakpoint-down(md) {
  .modal-desc-ul {
    font-size: 12px;
  }
  .modal-container {
    width: 350px;
    padding: 5px 0;
  }
}
</style>
