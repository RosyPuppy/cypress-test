<template>
  <div class="container">
    <pageloader v-if="pageload" />
    <div v-else>
      <div class="header text-center">
        <div class="mobile-backto-site mob-welcome-user text-center">
          <p>Welcome {{ loggeduser.firstName }}</p>
        </div>
        <p class="title">{{ language.account_header }}</p>
        <p class="sub-title">
          {{ language.tagline }}
        </p>
      </div>
      <div class="about col-12 col-lg-8 col-md-10 m-auto">
        <div class="content-title">{{ language.profile_header }}</div>
        <div class="row">
          <div class="col-md-8 m-auto content">
            <div class="field-space mobile-typo">
              <span
                ><strong>{{ language.profile_subheader }}</strong> <br />
                {{ loggeduser.firstName }} {{ loggeduser.lastName }}</span
              >
            </div>
            <div class="field-space mobile-typo">
              <strong>{{ language.country_text }}</strong> <br />
              <span>{{ loggeduser.countryFullName }}</span>
            </div>
            <div class="field-space mobile-typo">
              <strong>{{ language.myaccount_language_label }}</strong> <br />
              <span>{{ loggeduser.languageFullName }}</span>
            </div>
            <div class="field-space mobile-typo">
              <strong>{{ language.organization_text}}</strong> <br />
              <span>{{ loggeduser.organisation }}</span>
            </div>
            <div v-if="loggeduser.businessType" class="field-space mobile-typo">
              <strong>Business Type</strong> <br />
              <span>{{ loggeduser.businessType }}</span>
            </div>
            <div v-if="loggeduser.jobFunction" class="field-space mobile-typo">
              <strong>Job Function</strong> <br />
              <span>{{ loggeduser.jobFunction }}</span>
            </div>
            <div v-if="loggeduser.zipCode" class="field-space mobile-typo">
              <strong>Zip Code</strong> <br />
              <span>{{ loggeduser.zipCode }}</span>
            </div>
          </div>
          <div class="col-md-4">
            <button
              class="btn btn-primary btn-text-color about-edit"
              v-on:click="aboutEdit"
            >
              {{ language.edit_label }}
            </button>
          </div>
        </div>
      </div>
      <div class="myresmedid col-12 col-lg-8 col-md-10 m-auto">
        <div class="content-title">{{ language.id_header }}</div>
        <div class="row">
          <div class="col-md-8 m-auto content">
            <div class="field-space mobile-typo">
              <span
                ><strong>{{ language.id_subheader }}</strong></span
              >
              <br />
              <span>{{ loggeduser.email }}</span>
            </div>
          </div>
          <div class="col-md-4">
            <button
              v-if="!isResmedUser"
              class="btn btn-primary btn-text-color myresmedid-edit mb-2"
              v-on:click="emailEdit"
            >
              {{ language.edit_label }}
            </button>
          </div>
          <div class="col-md-8 m-auto content">
            <div>
              <strong>{{ language.password_label }}</strong> <br />
              <span>*********</span>
            </div>
          </div>
          <div class="col-md-4">
            <button
              v-if="!isResmedUser"
              class="btn btn-primary btn-text-color myresmedpwd-edit"
              v-on:click="passwordEdit"
            >
              {{ language.edit_label }}
            </button>
          </div>
        </div>
      </div>
         <div>
    <vue-final-modal v-model="showModal">
       <div class="modal-wrapper popup-del">
            <div class="modal-container" id="popup-approve">
              <content select=".modal-header">
                <div class="modal-header col-md-12 spacing-popup">
                  <div class="row title-popup">
                    <div class="col-10">
                      <h4><strong>{{language.myaccount_delete_label}}</strong></h4>
                    </div>
          <div class="col-2 text-right">
                      <button
                        type="button"
                        @click="showModal = false"
                        class="close"
                        aria-label="Close"
                      >
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    
                  </div>
                </div>
              </content>

             <form>
                    <div class="form-group del-form">
                      <input
                      
                @input="search"
                        type="text"
                        v-model="inputText"
                        class="form-control"
                        :placeholder="language.myaccount_delete_placeholder_label"
                      />
                    </div>
                    </form>

              <div
                class="
                        d-flex
                        align-items-center
                        m-3
                      "
              >
                <button
                  type="button"
                  class="btn btn-primary px-4 popup-btns mr-2 btn-text disablecolor"
                  :disabled="inputText.toLowerCase() != 'delete'"
                  @click="deleteAccount"
                >
                  {{language.myaccount_delete_button_label}}
                </button>
              </div>
            </div>
          </div>
    </vue-final-modal>
  </div>
     <div class="subscriptions col-12 col-lg-8 col-md-10 m-auto">
        <div class="content-title">{{ language.My_subs }}</div>
        <div class="row">
          <div class="col-md-8 m-auto content">
            <div>
              {{ language.Secure_Access }}
              <span
                v-bind:data-tooltip="language.myaccount_tooltip_text"
                class="avatar"
                ><img
                  class="tooltip-alignment"
                  src="@/assets/images/tool-tip.png"
              /></span>
            </div>
            <div v-if="contentAccessLength > 0">
              <div v-for="item in contentAccess" :key="item.id">
                <div>
                  <span>
                    <strong>{{ language.myAccountCategory[item.contentAccessType.split(' ')[0].toUpperCase()] }}</strong>
                    </span
                  >
                  (<span>{{ language.myAccountCategoryStatus[item.contentAccessStatusCode] }}</span
                  >)
                </div>
              </div>
              <div v-if="userAccessLength > 0">
                <div v-for="item in userAccess" :key="item.id">
                  <div>
                    <ul>
                      <li class="myaccountcta">
                    <span
                      ><strong>{{
                        language.categoryAccess[item.categoryType]
                      }}</strong></span
                    >
                    (<span>{{
                      language.categoryStatus[item.userAccessStatus]
                    }}</span
                    >)
                    </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div v-if="contentAccessLength == 0">
              <p>
                <span>
                  {{ language.NoSub_Moment }}
                </span>
              </p>
              <div v-for="item in contentAccess" :key="item.id">
                <div>
                  <span
                    ><strong>{{ item.contentAccessType }}</strong></span
                  >
                  (<span>{{ item.contentAccessStatus }}</span
                  >)
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <button
              v-if="!isResmedUser"
              class="btn btn-primary btn-text-color commercial-edit"
              v-on:click="subscriptionsEdit"
            >
              <span v-if="contentAccessLength > 0">
                {{ language.edit_label }}
              </span>
              <span v-if="contentAccessLength == 0"> Subscribe </span>
            </button>
          </div>
        </div>
      </div>
      <div v-if="adminUser" class="approvals col-12 col-lg-8 col-md-10 m-auto">
        <div class="content-title">{{ language.Pending_Approvals }}</div>
        <div class="row">
          <div class="col-10 col-lg-8 m-0 m-lg-auto content">
            <p>
              {{ pendingApprovalsLength }} {{ language.no_of_pending_text }}
            </p>
          </div>
          <div class="col-md-4">
            <button
              class="btn btn-primary approvals-edit mb-2"
              v-on:click="approvalsEdit"
            >
              {{ language.edit_label }}</button
            ><br />
          </div>
        </div>
      </div>
      <div v-if="!isResmedUser" class="about col-12 col-lg-8 col-md-10 m-auto">
        <div class="content-title">{{language.myaccount_removetitle_label}}</div>
        <div class="row">
          <div class="col-md-8 m-auto content">
            <div class="field-space mobile-typo">
              <p
                >{{language.myaccount_removedesc_label}}<br />
                {{language.myaccount_seconddesc_label}}</p
              >
            </div>
                      </div>
          <div class="col-md-4">
            <button
              class="btn px-4 removebtn"
              @click="showModal = true"
            >
              {{language.myaccount_removetitle_label}}
            </button>
          </div>
        </div>
      </div>
      </div>
    </div>
</template>
<script>
import { mapState, mapMutations } from "vuex";
import Api from "@/api";

import axios from "axios";
import pageloader from "../components/pageloader";
import "vue-loading-overlay/dist/vue-loading.css";
import { OKTA_DOMAIN, OKTA_SESSION, OKTA_ASSETS_DOMAIN } from "@/Config";
export default {
  components: {
    pageloader,
  },
  name: "app",
  data() {
    //  subscMsg="You will be access the secure documents"
    return {
      isLoadingLoader: false,
      adminUser: false,
      pageload: false,
      showModal: false,
inputText: ""

    };
  },
  computed: {
    ...mapState([
      "loggeduser",
      "language",
      "region",
      "oktaSid",
      "defaultLanguage",
    ]),
    isResmedUser() {
      return (
        this.loggeduser &&
        this.loggeduser.email &&
        this.loggeduser.email.toLowerCase().includes("@resmed.")
      );
    },
  },
  async mounted() {
    this.setRegion(this.$route.params.region);
    await this.getUserSession();
  },
  methods: {
    ...mapMutations(["addUser", "setRegion", "setOktaSid", "resetUser"]),
     
 
    aboutEdit: function() {
      this.$router.push("editprofile.html");
    },
    emailEdit: function() {
      this.$router.push("changeemail.html");
    },
    passwordEdit: function() {
      this.$router.push("changepassword.html");
    },
    subscriptionsEdit: function() {
      this.$router.push("subscribe.html");
    },
    approvalsEdit: function() {
      this.$router.push("editapprovals.html");
    },
    async deleteAccount() {
      try {
        await Api.deleteAccount();

        await Api.logout();
        // remove all cookie
        const allCookies = this.$cookies.keys();
        const _self = this;
        allCookies.map((cookie) => {
          _self.$cookies.remove(
            cookie,
            null,
            window.location.hostname === "localhost"
              ? "localhost"
              : "resmed.com"
          );
        });
        this.$local.remove("pdfPath");
        this.$local.remove("softwarePath");
        this.resetUser();
        this.$router.push(`/${this.region}/signin.html`);
      } catch (error) {
        console.log(error);
      }
    },
    async getUserSession() {
      this.pageload = true;
      axios
        .get(OKTA_SESSION + "/api/v1/sessions/me", {
          headers: {
            "Content-Type": "application/json",
          },
          withCredentials: true,
        })
        .then(async (response) => {
          console.log(response.data.id);
          this.setOktaSid(response.data.id);
          // MARS-461 - Add cookies for session access
          this.$cookies.set(
            "rocEmail",
            response.data.login,
            null,
            null,
            window.location.hostname === "localhost"
              ? "localhost"
              : "resmed.com"
          );
          this.$cookies.set(
            "rocSid",
            response.data.id,
            null,
            null,
            window.location.hostname === "localhost"
              ? "localhost"
              : "resmed.com"
          );
          this.$cookies.set(
            "rocServ",
            OKTA_DOMAIN,
            null,
            null,
            window.location.hostname === "localhost"
              ? "localhost"
              : "resmed.com"
          );
          //redirect if there is a redirectUrl
          const pdfUrl = this.$cookies.get("redirectUrl");
          this.oktaEmail = response.data.login;
          await this.getUserViewProfile();

          if (pdfUrl != null) {
            this.$cookies.remove(
              "redirectUrl",
              null,
              window.location.hostname === "localhost"
                ? "localhost"
                : "resmed.com"
            );
            window.location.href =
              OKTA_ASSETS_DOMAIN + decodeURIComponent(pdfUrl);
          }
        })
        .catch((error) => {
          //this.pageload=false
          console.log("error", error);
          this.$router.push("signin.html");
          // If API returns error, clear cookies
        });
    },
    setCookie(key, value) {
      this.$cookies.set(
        key,
        value,
        null,
        null,
        window.location.hostname === "localhost" ? "localhost" : "resmed.com"
      );
    },
    async getUserViewProfile() {
      axios
        .get(
          OKTA_DOMAIN +
            "v1/account/view/" +
            `${this.oktaEmail}` +
            "/partner/50/pending",
          {
            headers: {
              "Content-Type": "application/json",
              region: `${this.$route.params.region}`,
              OKTA_SID: `${this.oktaSid}`,
            },
            withCredentials: true,
          }
        )
        .then((response) => {
          console.log(response.data);
          this.addUser(response.data.user);

          // Cookie generation
          const res = response.data;
          this.setCookie("b2bFirstName", res.user.firstName);
          this.setCookie("RegionCode", res.user.origin);
          if (res.contentAccess.length) {
            let cookieStr = "";
            res.contentAccess.map((item) => {
              cookieStr +=
                item.contentAccessTypeCode.toLowerCase() +
                "_" +
                item.contentAccessStatusCode.toLowerCase() +
                ",";
            });
            this.setCookie("role", cookieStr);
          }
          if (res.userAccess.length) {
            let userCookieStr = "";
            res.userAccess.map((item) => {
              userCookieStr +=
                item.categoryType.toLowerCase() +
                "_" +
                item.userAccessStatus.toLowerCase() +
                ",";
            });
            this.setCookie("categories", userCookieStr);
          }

          this.setCookie(
            "redirectLoggedPath",
            `${window.location.origin}/${this.region}/myaccount.html`
          );

          if (
            response.data.contentAccess != "undefined" &&
            response.data.contentAccess != undefined
          ) {
            this.contentAccess = response.data.contentAccess;
            console.log("contentaccess", this.contentAccess)
            this.contentAccessLength = response.data.contentAccess.length;
          } else {
            this.contentAccessLength = 0;
          }
          if (
            response.data.userAccess.length > 0 &&
            response.data.userAccess != null
          ) {
            this.userAccess = response.data.userAccess;
            this.userAccessLength = response.data.userAccess.length;
          } else {
            this.userAccessLength = 0;
          }
          if (
            response.data.pendingApprovals != null &&
            response.data.pendingApprovals.length > 0
          ) {
            this.adminUser = true;
            this.pendingApprovals = response.data.pendingApprovals;
            this.pendingApprovalsLength =
              response.data.pendingApprovals[0].pendingRecordsLength;
          }

          this.pageload = false;
        })
        .catch((error) => {
          console.log("error", error);
          this.$router.push("signin.html");
          this.pageload = false;
          // If API returns error, clear cookies
        });
    },
  },
};
</script>
<style scoped lang="scss">
.spacing-popup {
  padding: 20px;
}
.title-popup {
  width:100%;
}
.popup-btns {
  width: 100%;
  background-color: #b02543;
  color: white;
  
}
.popup-btns:hover {
background-color: #b02543;
}
.removebtn {
  border-radius: 7px;
  border-color:#b02543;
  color:#b02543;
}
.popup-del {
  display: grid;
  place-items: center;
 height: 100vh;
}
.del-form {
  padding: 20px;
}
#popup-approve {
  width: 550px;
  height: 280px;
   background: white;
    border-radius: 6px;
}
.avatar {
  position: relative;
  font-size: 12px;
}

.avatar::before,
.avatar::after {
  --scale: 0;
  --arrow-size: 20px;
  --tooltip-color: #000;

  position: absolute;
  top: -0.25rem;
  left: 50%;
  transform: translateX(-50%) translateY(var(--translate-y, 0))
    scale(var(--scale));
  transition: 150ms transform;
  transform-origin: bottom center;
}

.avatar::before {
  --translate-y: calc(-100% - var(--arrow-size));

  content: attr(data-tooltip);
  color: white;
  padding: 0.5rem;
  border-radius: 0.3rem;
  text-align: center;
  width: max-content;
  max-width: 200px;
  background: var(--tooltip-color);
}

.avatar:hover::before,
.avatar:hover::after {
  --scale: 1;
}

.avatar::after {
  --translate-y: calc(-1 * var(--arrow-size));

  content: "";
  border: var(--arrow-size) solid transparent;
  border-top-color: var(--tooltip-color);
  transform-origin: top center;
}

/* Mobile view */
@include media-breakpoint-down(md) {
  .mobile-typo {
    font-size: 14px;
  }
  .sub-title {
    font-size: 16px;
  }
  .content-title {
    font-size: 24px !important;
  }
  .content {
    font-size: 14px !important;
  }
}

.header .title {
  font-size: 36px;
  padding-bottom: 22px;
  padding-top: 30px;
}
.tooltip-alignment {
  margin-bottom: 6px;
}
.header .sub-title {
  font-size: 20px;
}
.content-title {
  font-size: 30px;
  margin-bottom: 20px;
  margin-top: 35px;
  font-family: $font-main;
  font-weight: 100;
}
.btn-text-color {
  color: white;
  &:hover {
    color: white;
  }
}
button.disablecolor:disabled {
  background-color: grey
}


.field-space {
  margin-bottom: 10px;
}
.about-edit,
.myresmedid-edit,
.myresmedpwd-edit,
.clinical-edit,
.commercial-edit,
.approvals-edit {
  color: white;
  padding: 10px 32px;
  border-radius: 10px;
  margin-top: auto;
  margin-bottom: auto;
}

.content {
  font-size: 20px;
  font-family: $font-main;
}
.myaccountcta {
  padding: 1px;
  line-height: 7px;
  margin: 4px;
}
@media (min-width: 769px) {
  .mob-welcome-user {
    display: none;
  }
}
@media (max-width: 768.95px) {
  .mob-welcome-user {
    background-color: #e7f3f9;
    padding: 10px 0 2px 0;
    margin: 100px 0 15px -5px;
  }
}
</style>
