<template>
  <div class="container mt-5 mt-md-5 mt-lg-0">
    <pageloader v-if="pageload" />
    <div v-else class="row">
      <div class="col-sm-7 col-lg-5 col-md-9 m-auto">
        <div class="signin mt-5 text-center">
          <h2 class="text-center m-5 title">{{ language.My_subs }}</h2>
          <div v-if="success" class="my-3">
            <p class="already-text text-left">
              <img :src="successIcon" />
              {{ language.Sub_update }}
            </p>
          </div>
          <h2 class="text-left my-4 title sub-title">{{ language.My_subs }}</h2>
          <div v-if="error" class="my-3">
            <p class="bg-danger p-2 text-light already-text rounded">
              {{ error }}
            </p>
          </div>

          <form @submit.prevent="handleSubmit">
            <div class="d-flex align-items-center justify-content-between">
              <div class="lead">{{ language.content_clinical }}</div>
              <div class="form-check">
                <input
                  type="checkbox"
                  @change="showModal($event)"
                  class="form-check-input"
                  v-model="user.clinical"
                  id="clinical"
                  name="clinical"
                  value="clinical"
                  :class="{
                    'is-invalid': submitted && v$.user.clinical.$error,
                  }"
                  :checked="user.clinical"
                />
                <label class="form-check-label res-typo-para">
                  {{ language.subscribe_text }}
                </label>
              </div>
            </div>
            <div class="d-flex align-items-center justify-content-between">
              <div class="lead">{{ language.content_commercial }}</div>
              <div class="form-check">
                <input
                  type="checkbox"
                  @change="showModal($event)"
                  class="form-check-input"
                  v-model="user.commercial"
                  id="commercial"
                  name="commercial"
                  value="commercial"
                  :checked="user.commercial"
                />
                <label class="form-check-label res-typo-para">
                  {{ language.subscribe_text }}
                </label>
              </div>
            </div>
            <div class="d-flex align-items-center justify-content-between">
              <div class="lead">{{ language.technical_title }}</div>
              <div class="form-check">
                <input
                  type="checkbox"
                  @change="
                    showModal($event);
                    subscriptionsEvent($event);
                  "
                  class="form-check-input"
                  v-model="user.technical"
                  id="technical"
                  name="technical"
                  value="technical"
                  :checked="user.technical"
                />
                <label class="form-check-label res-typo-para">
                  {{ language.subscribe_text }}
                </label>
              </div>
            </div>
            <div>
              <ul>
                <li>
                  <div
                    class="d-flex align-items-center justify-content-between"
                  >
                    <div class="lead">
                      {{ language.tech_approve_sleep_label }}
                    </div>
                    <div class="form-check">
                      <input
                        type="checkbox"
                        @change="
                          showModal($event);
                          subscriptionsEvent($event);
                        "
                        class="form-check-input"
                        v-model="user.sleep"
                        id="sleep"
                        name="sleep"
                        value="sleep"
                        :checked="user.sleep"
                      />
                      <label class="form-check-label res-typo-para">
                        {{ language.subscribe_text }}
                      </label>
                    </div>
                  </div>
                </li>
                <li>
                  <div
                    class="d-flex align-items-center justify-content-between"
                  >
                    <div class="lead">
                      {{ language.tech_approve_ventilator_label }}
                    </div>
                    <div class="form-check">
                      <input
                        type="checkbox"
                        @change="
                          showModal($event);
                          subscriptionsEvent($event);
                        "
                        class="form-check-input"
                        v-model="user.ventilators"
                        id="ventilators"
                        name="ventilators"
                        value="ventilators"
                        :checked="user.ventilators"
                      />
                      <label class="form-check-label res-typo-para">
                        {{ language.subscribe_text }}
                      </label>
                    </div>
                  </div>
                </li>
                <li>
                  <div
                    class="d-flex align-items-center justify-content-between"
                  >
                    <div class="lead">
                      {{ language.tech_approve_oxygen_label }}
                    </div>
                    <div class="form-check">
                      <input
                        type="checkbox"
                        @change="
                          showModal($event);
                          subscriptionsEvent($event);
                        "
                        class="form-check-input"
                        v-model="user.oxygen"
                        id="oxygen"
                        name="oxygen"
                        value="oxygen"
                        :checked="user.oxygen"
                      />
                      <label class="form-check-label res-typo-para">
                        {{ language.subscribe_text }}
                      </label>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <div class="form-group text-left mt-3">
              <vue-button-spinner
                type="submit"
                class="res-spin-btn my-2"
                :is-loading="isLoading"
                :disabled="init"
              >
                {{ language.Save }}
              </vue-button-spinner>
            </div>
            <div>
              <div class="text-left">
                <router-link class="nav-link links p-0 backlink" to="myaccount.html">{{
                  language.backMyProfile_label
                }}</router-link>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <vue-final-modal v-model="clinical_modal" class="modal">
      <div class="modal-wrapper">
        <div class="modal-container">
          <content select=".modal-header">
            <div class="modal-header col-md-12">
              <div class="row">
                <div class="col-10">
                  <h4>{{ language.sub_confirmation }}</h4>
                </div>
                <div class="col-2 text-right">
                  <button
                    type="button"
                    @click.prevent="accept(true)"
                    class="close"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
              </div>
            </div>
          </content>
          <div class="modal-body">
            {{ language.Unsub_confirmation }}
          </div>
          <div class="d-flex align-items-center justify-content-between m-3">
            <button
              class="btn btn-primary res-btn-primary mb-3"
              @click.prevent="accept(false)"
            >
              {{ language.no_text }}
            </button>
            <button
              class="btn btn-primary res-btn-primary mb-3"
              @click.prevent="accept(true)"
            >
              {{ language.yes_text }}
            </button>
          </div>
        </div>
      </div>
    </vue-final-modal>
  </div>
</template>
<script>
import VueButtonSpinner from "@/components/spinner";
import useVuelidate from "@vuelidate/core";
import { required } from "@vuelidate/validators";
import { mapState, mapMutations } from "vuex";
import Api from "@/api";
import successIcon from "@/assets/images/success-new.png";

export default {
  name: "app",
  components: { VueButtonSpinner },
  setup() {
    const v$ = useVuelidate();
    return { v$ };
  },
  data() {
    return {
      pageload: true,
      clinical_modal: null,
      user: {
        clinical: false,
        commercial: false,
        technical: false,
        sleep: false,
        ventilators: false,
        oxygen: false,
      },
      submitted: false,
      isLoading: false,
      init: true,
      success: false,
      error: null,
      successIcon: successIcon,
    };
  },
  validations: {
    user: {
      clinical: { required },
      commercial: { required },
      technical: { required },
      sleep: { required },
      ventilators: { required },
      oxygen: { required },
    },
  },
  computed: {
    ...mapState(["loggeduser", "language", "subscriptions"]),
  },
  async mounted() {
    this.setRegion(this.$route.params.region);
    await Api.getMySubscriptions();
    this.user.clinical = this.subscriptions.clinical;
    this.user.commercial = this.subscriptions.commercial;
    this.user.technical = this.subscriptions.technical;
    this.user.sleep = this.subscriptions.sleep;
    this.user.ventilators = this.subscriptions.ventilators;
    this.user.oxygen = this.subscriptions.oxygen;
    this.pageload = false;
  },
  methods: {
    ...mapMutations(["setRegion"]),
    subscriptionsEvent(e) {
      this.subscriptions.sleep = this.user.sleep;
      this.subscriptions.oxygen = this.user.oxygen;
      this.subscriptions.ventilators = this.user.ventilators;
      if (e.target.id === "technical") {
        if (e.target.checked) {
          this.user.sleep = true;
          this.user.oxygen = true;
          this.user.ventilators = true;
        } else {
          this.user.sleep = false;
          this.user.oxygen = false;
          this.user.ventilators = false;
        }
      }
      if (this.user.sleep || this.user.oxygen || this.user.ventilators) {
        this.user.technical = true;
      } else {
        this.user.technical = false;
      }
    },
    async handleSubmit() {
      try {
        this.submitted = true;

        // stop here if form is invalid
        this.v$.$touch();
        if (this.v$.$invalid) {
          return;
        }
        this.isLoading = true;
        await Api.updateMySubscription(
          this.user.clinical,
          this.user.commercial,
          this.user.technical,
          this.user.sleep,
          this.user.oxygen,
          this.user.ventilators
        );

        this.success = true;
        this.isLoading = false;
        const _self = this;
        setTimeout(function () {
          _self.success = false;
        }, 3000);
      } catch (error) {
        this.error = error.message;
      }
    },
    showModal(e) {
      if (!e.target.checked) {
        this.clinical_modal = e.target.value;
      }
      this.init = false;
    },
    accept(type) {
      if (this.clinical_modal === "clinical") {
        this.user.clinical = !type;
      }
      if (this.clinical_modal === "commercial") {
        this.user.commercial = !type;
      }
      if (this.clinical_modal === "technical") {
        this.user.technical = !type;
      }
      if (this.clinical_modal === "sleep") {
        this.user.sleep = !type;
      }
      if (this.clinical_modal === "ventilators") {
        this.user.ventilators = !type;
      }
      if (this.clinical_modal === "oxygen") {
        this.user.oxygen = !type;
      }
      this.clinical_modal = null;
      this.init = false;
    },
  },
};
</script>
<style scoped lang="scss">
.sub-title {
  font-weight: 400;
}
.signin {
  border-radius: 10px;
  margin-top: auto;
  margin-bottom: auto;
}
.links {
  font-size: 18px;
}
.info {
  font-size: 20px;
  color: #555;
}
.form-check {
  font-size: 22px;
}
::v-deep .modal {
  display: flex;
  justify-content: center;
  align-items: center;
}
::v-deep .modal-content {
  display: flex;
  flex-direction: column;
}
.modal-wrapper {
  display: table-cell;
  vertical-align: middle;
  transform: translate(-50%, -50%) !important;
  top: 25%;
  left: 50%;
  position: absolute;
}
.modal-container {
  background: #fff;
  width: 600px;
  border-radius: 5px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.33);
  transition: all 0.3s ease;
  margin: 0 auto;
}
.modal-footer {
  margin-top: 15px;
}
.modal-enter,
.modal-leave {
  opacity: 0;
}
.modal-enter .modal-container,
.modal-leave .modal-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
.modal-header {
  display: block !important;
}

/* Mobile view */
@include media-breakpoint-down(md) {
  .modal-desc-ul {
    font-size: 12px;
  }
  .modal-container {
    width: 350px;
    padding: 5px 0;
  }
}
.backlink {
 color:blue !important;
}
</style>
