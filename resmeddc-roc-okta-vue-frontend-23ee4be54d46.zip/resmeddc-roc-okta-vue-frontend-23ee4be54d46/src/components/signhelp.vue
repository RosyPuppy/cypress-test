<template>
  <div class="container mt-0">
    <div class="row">
      <div class="col-md-12 m-auto">
        <div class="signin mt-5 mt-md-5 mt-lg-0 signin-title">
          <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-6">
              <h2 class=" mt-5 mb-3 title">
                {{ language.sign_help_backtoSign_page_title }}
              </h2>
            </div>
            <div
              class="col-md-6 col-sm-6 col-xs-6 text-right mt-0 mt-md-5 back-label"
            >
              <router-link class="nav-link links" to="signin.html"
                ><span class="arrow-angle"></span
                >{{ language.sign_help_backtoSign_page }}</router-link
              >
            </div>
          </div>
          <div class="top-content">
            <p>{{ language.sign_help_hightlight_content }}</p>
            <p>{{ language.sign_help_hightlight_content1 }}</p>
          </div>
          <h4 class="my-3">
            <strong>{{ language.sign_help_tableof_content_title }}</strong>
          </h4>
          <div class="table-content">
            <p>{{ language.sign_help_tableof_content_section }}</p>
            <ul>
              <li class="ml-0 ml-md-5 ml-lg-5">
                <a href="#report-security">
                  {{ language.sign_help_tableof_content_subsection }}</a
                >
              </li>
            </ul>
            <p>{{ language.sign_help_tableof_content_section1 }}</p>
            <ul>
              <li class="ml-0 ml-md-5 ml-lg-5">
                <a href="#sign-in">
                  {{ language.sign_help_tableof_content_subsection1 }}</a
                >
              </li>
              <li class="ml-0 ml-md-5 ml-lg-5">
                <a href="#report-issue">
                  {{ language.sign_help_tableof_content_subsection12 }}</a
                >
              </li>
            </ul>
          </div>
          <h4 class="my-3 sub-title">
            <strong>{{ language.sign_help_faq_title }}</strong>
          </h4>
          <div id="report-security">
            <div class="flex">
              <p>
                <strong>{{ language.sign_help_faq_Q }}</strong>
              </p>
              &nbsp; &nbsp;
              <p>{{ language.sign_help_faq_question }}</p>
            </div>
            <div class="flex">
              <p>
                <strong>{{ language.sign_help_faq_A }}</strong>
              </p>
              &nbsp; &nbsp;
              <p>
                {{ language.sign_help_faq_subanswer
                }}<strong>{{ language.sign_help_faq_subanswer12 }}</strong>
                {{ language.sign_help_faq_subanswer1 }}
                <strong>{{ language.sign_help_faq_subanswer2 }}</strong>
                {{ language.sign_help_faq_subanswer3 }}
              </p>
            </div>
          </div>
          <h4 class="my-3 sub-title">
            <strong>{{ language.sign_help_howto_title }}</strong>
          </h4>
          <h4 id="sign-in" class="border-align">
            {{ sign_help_howto_subtitle }}
          </h4>
          <div>
            <ol class="ml-4">
              <li>
                <p>
                  {{ language.sign_help_howto_content
                  }}<strong>{{ language.sign_help_howto_companyname }}</strong>
                </p>
              </li>
              <li>
                <p>
                  {{ language.sign_help_howto_content2 }}<strong>{{}}</strong
                  >{{ language.sign_help_howto_content22
                  }}{{ language.sign_help_howto_content23s }}.
                </p>
                <p>{{ language.sign_help_howto_content26 }}</p>
                <p>
                  <strong> {{ language.sign_help_howto_content27 }}</strong>
                  {{ language.sign_help_howto_content28 }}
                </p>
                <p>
                  {{ language.sign_help_howto_content29
                  }}<strong
                    >{{ language.sign_help_howto_content30
                    }}{{ language.sign_help_howto_content31 }}</strong
                  >
                </p>
                <p>
                  {{ language.sign_help_howto_content32
                  }}<strong>{{ language.sign_help_howto_content33 }}</strong>
                </p>
              </li>
            </ol>
            <h4 id="report-issue" class="sub-title border-align">
              {{ language.sign_help_report_security_issue_title }}
            </h4>
            <ol class="ml-4">
              <li>
                <p>
                  {{ language.sign_help_report_security_issue_content }}
                  <strong>{{
                    language.sign_help_report_security_issue_content1
                  }}</strong>
                </p>
              </li>
              <li>
                <p>
                  {{ language.sign_help_report_security_issue_content13
                  }}<strong>{{
                    language.sign_help_report_security_issue_content14
                  }}</strong
                  >{{ language.sign_help_report_security_issue_content15 }}
                  <strong>{{
                    language.sign_help_report_security_issue_content16
                  }}</strong>
                </p>
              </li>
              <li>
                <p>
                  {{ language.sign_help_report_security_issue_content17
                  }}<strong
                    >{{
                      language.sign_help_report_security_issue_content19
                    }}.</strong
                  >
                </p>
              </li>
            </ol>
            <div>
              <h4 id="contact-us" class="sub-title border-align">{{language.signhelp_contact_label}}</h4>
              <ol class="ml-4">
                <p v-if="region=='fr-ch'">
                  {{language.signup_contact_desc_label}}
                  <a :href="`https://digital@resmed.com/`" target="_blank"
                    >{{language.signhelp_contact_label}}</a
                  >
                </p>
                <p v-else>
                  {{language.signup_contact_desc_label}}
                  <a :href="`https://digital@resmed.com/`" target="_blank"
                    >{{language.signhelp_contact_label}}</a
                  >
                  {{language.signup_contact_here_label}}
                </p>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapState, mapMutations } from "vuex";
export default {
   data() {
    return {
      
      region: "",
      
   
    };
  },
  computed: {
    ...mapState(["language", "region"]),
  },
  async mounted() {
    this.region = this.$route.params.region;
    
    this.setRegion(this.$route.params.region);
  },
  methods: {
    ...mapMutations(["setRegion"]),

  }
};
</script>
<style scoped lang="scss">
.top-content,
.table-content {
  background: #f1f1f1;
  padding: 20px;
}

.sub-title {
  margin-top: 40px !important;
}
.container {
  font-family: $font-main !important;
}
li {
  color: #5e5e5e i !important;
}
a {
  color: #1788c3;
  text-decoration: none;
  &:hover {
    color: #2a6496;
    text-decoration: underline;
  }
}
.back-label {
  color: black;
}
.flex {
  display: flex;
}
.border-align {
  border-bottom: 1px solid lightgray;
  margin-bottom: 10px;
  line-height: 48px;
}

:target:before {
  content: "";
  display: block;
  height: 100px;
  margin: -100px 0 0;
}
</style>
