export function isNunber(value) {
  if (!/\d/.test(this.regUser.user.password)) return true;
}