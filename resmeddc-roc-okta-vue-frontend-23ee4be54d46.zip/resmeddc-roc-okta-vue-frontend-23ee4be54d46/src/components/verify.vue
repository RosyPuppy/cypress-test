<template>
  <div class="mt-5">
    <pageloader v-if="isLoading" />
    <div v-else class="mt-5">
      <div class="container mt-5">
        <div class="row">
          <div class="col-md-7 m-auto">
            <div class="signin mt-5">
              <div v-if="isVerified && !isLoading" class="signin mt-5">
                <success-message
                  :header="language.verified_header"
                  :message="language.verify_thanks"
                  :signlabel="language.verify_continue_label"
                ></success-message>
              </div>
              <div v-if="!isVerified && !isLoading" class="signin mt-5">
                <success-message
                  error
                  :header="language.verify_error_header"
                  :message="verifyEmailErrMsg"
                  :signlabel="language.verify_continue_label"
                ></success-message>
                <!-- <h2 class="text-center m-5 title">
                  {{ language.verify_error_header }}
                </h2>
                <div class="pb-4 info">{{ language.tagline }}</div>
                <div>
                  <p class="danger">{{ verifyEmailErrMsg }}.</p>
                </div>
                <div class="form-group">
                  <button class="btn btn-primary signinbtn mt-3">
                    {{ language.verify_resend_label }}
                  </button>
                </div> -->
              </div>
              <!-- <h2 class="text-center m-5 title">Can't Verify Email</h2>
              <div class="pb-4 info">
                Manage your subscrition to securencontent using myAccount.
              </div>
              <div>
                <p class="danger">
                  Sorry, the link you've clicked on is invalid. Please request a
                  ne link.
                </p>
                <div class="pb-4 info">subash.elangovan@Intinfotech.com</div>
                <div class="pb-4 info">
                  To resend the email link, please click the button below.
                </div>
              </div>
              <div class="form-group">
                <button class="btn btn-primary signinbtn mt-3">
                  Resend email link
                </button>
              </div>
              <div></div> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapState, mapMutations } from "vuex";
import axios from "axios";
import pageloader from "../components/pageloader";
import "vue-loading-overlay/dist/vue-loading.css";
import { OKTA_DOMAIN } from "@/Config";

export default {
  components: {
    pageloader,
  },
  data() {
    return {
      isLoadingLoader: false,
      isLoading: false,
      pageload: false,
      params: null,
      verifyEmailErrMsg: "",
      showError: false,
      isVerified: true,
      success: false,
    };
  },
  computed: {
    ...mapState(["loggeduser", "language", "region", "oktaSid"]),
  },
  async mounted() {
    this.setRegion(this.$route.params.region);
    this.verify();
  },
  methods: {
    ...mapMutations(["addUser", "setRegion", "setOktaSid"]),
    removeError() {
      this.showError = false;
    },
    signin: function () {
      this.$router.push("signin.html");
    },
    async verify() {
      this.isLoading = true;
      this.params = this.$route.query.token;
      console.log(this.$route.query.token);
      //const token = this.$route.query['token='];
      this.pageload = true;

      let headers = {};
      let userLogin = {};
      headers = {
        region: `${this.region}`,
        "Content-Type": "application/json",
      };
      userLogin = {
        user: {
          token: `${this.params}`,
          verify_link: "account_verification",
        },
      };

      await axios
        .post(OKTA_DOMAIN + "v1/user/verify", userLogin, { headers })
        .then((response) => {
          console.log(response);
          this.isLoading = false;
          this.isVerified = true;
        })
        .catch((error) => {
          console.log("error", error);
          this.isLoading = false;
          this.showError = true;
          this.isVerified = false;
          this.verifyEmailErrMsg = error.response.data.message ? error.response.data.message : error.response.data;
        });
    },
  },
};
</script>
<style scoped>
.signinbtn {
  padding: 12px 40px;
  border-radius: 10px;
  font-size: 19px;
}
.info {
  font-size: 20px;
  color: #555;
}
.danger {
  background: red;
  color: #fff;
  font-size: 18px;
  padding: 0px 6px;
}
</style>