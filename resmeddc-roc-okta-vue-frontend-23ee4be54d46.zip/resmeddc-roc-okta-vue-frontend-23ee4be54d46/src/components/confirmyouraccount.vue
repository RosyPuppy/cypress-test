<template>
     <div class="mt-5">
   <div class="mt-5">
      <div class="container mt-5">
         <div class="row">
            <div class="col-md-12 m-auto">
               <div class="signin mt-5">
                <h2 class="text-center m-5 title">Confirm your account</h2>
                <div class="text-center font_size">
                <img src="../assets/maillogo.png"/>
                <p>Check your email.</p>
                <p>A verification link has been sent to</p>
                <p>anji@resmed.com</p>
                </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</template>
<script>
export default {
  
}
</script>
<style scoped>
.font_size{
    font-size: 20px;
}
</style>