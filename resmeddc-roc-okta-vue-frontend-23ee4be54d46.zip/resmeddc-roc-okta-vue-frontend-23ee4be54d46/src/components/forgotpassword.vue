<template>
  <div class="container mt-4 mt-lg-0">
    <div class="row">
      <div class="col-sm-7 col-lg-5 m-auto">
        <div class="forgotpassword">
          <h2 class="text-center m-5 title">{{ language.reset_header }}</h2>
          <div class="pb-4 info">
            {{ language.tagline }}
          </div>
          <div v-if="!success">
            <!-- <div class="alert-style" v-if="error">
              {{ error }}
            </div> -->

            <form @submit.prevent="forgotpassword">
              <div class="form-group">
                <input
                  type="email"
                  v-model="user.email"
                   :placeholder="language.id_subheader"
                  id="email"
                  name="email"
                  class="form-control"
                  :class="{ 'is-invalid': v$.user.email.$error }"
                />
                <div v-if="isResmedUser" class="icon-error">
                   {{language.forgt_sso_label}}
                </div>
                <div v-if="v$.user.email.$error" class="invalid-feedback">
                  <span v-if="v$.user.email.required.$invalid">{{
                    error
                  }}</span>
                  <span v-if="v$.user.email.email.$invalid"
                    >Email is invalid</span
                  >
                </div>
              </div>
              <div class="pb-4 res-typo-para">
                {{ language.reset_instructions }}
              </div>
              <div>
                <div class="pb-4 res-typo-para" v-if="region=='fr-ch'">
                  {{language.reset_drag_drop_label}}
                  {{language.reset_icon_label }} <span class="captcha-name">{{ language.captcha[captcha.name] }}</span>
                </div>
                <div class="pb-4 res-typo-para" v-else>
                  {{language.reset_drag_drop_label}}
                  <span class="captcha-name">{{ language.captcha[captcha.name] }}</span> {{language.reset_icon_label }}
                </div>
                <DragDrop
                  ref="dragDrop"
                  :setCaptcha="setCaptcha"
                  :setValidCaptcha="setValidCaptcha"
                ></DragDrop>
                <div class="icon-error" v-if="captchaError">
                  {{language.reset_drag_drop_error_label}}
                </div>
              </div>
              <div class="form-group">
                <vue-button-spinner
                  class="btn btn-primary res-btn-primary res-spin-btn mt-3"
                  :is-loading="isLoading"
                  :disabled="!validCaptcha || v$.$invalid || isResmedUser"
                >
                  {{ language.resetpassword_label }}
                </vue-button-spinner>
              </div>
            </form>
          </div>
          <div v-if="success">
            <img :src="envelope" />
            <p class="mt-2 mb-0">{{ language.resetpassword_instruction }}</p>
            <p class="mb-3 font-weight-bold">{{ user.email }}</p>
          </div>
          <div>
            <div class="row">
              <div class="col-md-10 text-left d-flex align-items-center">
                <div v-if="success">
                  <span class="res-link-primary" :to="`/${region}/resetpassword.html`" @click = "resetclick" >{{
                    language.resend_label
                  }}</span>
                  
                  <span class="mx-2">|</span>
                </div>
                <router-link
                  class="nav-link links res-link-primary p-0 backlink"
                  :to="`/${region}/signin.html`"
                  >{{ language.backtosignin_label }}</router-link
                >
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { required, email } from "@vuelidate/validators";
import { mapState, mapMutations } from "vuex";
import useVuelidate from "@vuelidate/core";
import envelope from "@/assets/images/envelope.png";
import VueButtonSpinner from "../components/spinner";
import Api from "@/api";

export default {
  name: "app",
  setup() {
    const v$ = useVuelidate();
    return { v$ };
  },
  components: { VueButtonSpinner },
  data() {
    return {
      user: {
        email: "",
      },
      submitted: false,
      captcha: {},
      validCaptcha: false,
      captchaError: false,
      error: "",
      success: false,
      envelope: envelope,
      isLoading: false,
    };
  },
  validations: {
    user: {
      email: { required, email },
    },
  },
  computed: {
    ...mapState(["language", "region"]),
    isResmedUser() {
      return this.user.email.includes("@resmed.");
    },
  },

  async mounted() {
    this.setRegion(this.$route.params.region);
  },
  methods: {
    ...mapMutations(["setRegion"]),
    resetclick() {
this.success = false;
   },
    setCaptcha(captcha) {
      this.captcha = captcha;
    },
    setValidCaptcha(valid) {
      this.validCaptcha = valid;
      this.captchaError = !valid;
    },
    async forgotpassword() {
      this.submitted = true;

      // stop here if form is invalid
      this.v$.$touch();
      if (this.v$.$invalid) {
        return;
      }
      this.isLoading = true;
      // Call Api
      try {
        await Api.resetPassword(this.user.email, {
          region: this.region,
        });
        this.error = "";
        this.success = true;
      } catch (e) {
        console.log(e.message);
        this.success = true;
      }
      this.isLoading = false;
      this.$refs.dragDrop.reset();
    },
    async resendLink() {
      try {
        await Api.resetPassword(this.user.email);
        this.error = "";
        this.success = true;
        alert("Resent your password reset link to your e-mail.");
      } catch (e) {
        console.error(e);
        this.success = true;
      }
    },
  },
};
</script>
<style lang="scss">
.captcha-name {
  font-weight: bold;
  font-size: 20px;
}
.forgotpassword {
  padding: 10px 5px;
  border-radius: 10px;
  margin-top: auto;
  margin-bottom: auto;
}
.forgotpassword input {
  height: 48px;
  border-radius: 7px;
  background-color: #f4f4f4;
  color: #555;
}
.forgotpasswordbtn {
  padding: 12px 40px;
  border-radius: 10px;
  font-size: 19px;
  background-color: $primary-color;
  color: white;
}
.links {
  font-size: 18px;
}
.info {
  font-size: 15px;
  color: #555;
}
.alert-style {
  display: block;
  width: 100%;
  background-color: #d20d0d;
  color: #fff;
  font-weight: bold;
  padding: 5px;
  border-radius: 5px;
  cursor: pointer;
  margin-bottom: 15px;
  font-size: 15px;
}

.icon-error {
  color: #d20d0d;
}
.res-spin-btn {
  display: inline-flex;
  background-color: $primary-color !important;
  padding: 1.2em 1.6em !important;
  border-radius: 6px !important;
  font-size: 18px !important;
  color: #fff !important;
  &:hover {
    background-color: #285e8e !important;
  }
}
.backlink{
  color:blue!important;
}
</style>
