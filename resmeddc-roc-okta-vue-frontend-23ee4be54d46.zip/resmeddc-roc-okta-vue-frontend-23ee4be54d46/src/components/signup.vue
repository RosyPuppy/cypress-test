<template>
  <div class="">
    <div class="">
      <div class="container">
        <div class="row">
          <div class="col-lg-7 mt-5 mt-md-5 mt-lg-0 m-auto">
            <div class="mt-5 mt-md-5 mt-lg-0 signup">
              <h2 class="text-center py-3">
                {{ language.signup_header }}
              </h2>
              <div class="pb-4 info">
                {{ language.signup_instructions }}
              </div>
              <div v-if="showError">
                <p class="bg-danger p-2 text-light already-text">
                  {{ signinErrMsg }}
                </p>
              </div>
              <div v-if="already_exist">
                <p class="bg-danger p-2 text-light already-text">
                  {{ language.alreadyRegstEmailTxt }}
                  <span
                    @click.prevent="already_exist_model = !already_exist_model"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="22"
                      height="22"
                      fill="currentColor"
                      class="bi bi-info-circle m-1"
                      viewBox="0 0 16 16"
                    >
                      <path
                        d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"
                      />
                      <path
                        d="M8.93 6.588l-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"
                      />
                    </svg>
                  </span>
                </p>
              </div>
              <!-- model pop start -->
              <vue-final-modal v-model="already_exist_model" class="modal">
                <div class="popup-spacing modal-wrapper">
                  <div class="modal-container">
                    <content select=".modal-header">
                      <div class="modal-header">
                        <div class="row">
                          <div class="col-10">
                            <h2>
                              {{
                                language.alreadyRegisterUser_model_title
                              }}
                            </h2>
                          </div>
                          <div class="col-2 text-right">
                            <button
                              type="button"
                              @click.prevent="
                                already_exist_model = !already_exist_model
                              "
                              class="close"
                              aria-label="Close"
                            >
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </content>
                    <div class="modal-body">
                      <p>
                        {{
                          language.alreadyRegisterUser_model_content1
                        }}
                      </p>
                      <ul>
                        <li>
                          <a
                            href="javascript:void(0)"
                            @click="resendNewAccountVerification()"
                          >
                            {{
                              language.alreadyRegisterUser_model_clickhere
                            }}
                          </a>
                          {{
                            language.alreadyRegisterUser_model_content2
                          }}
                          <img
                            v-if="inprogress"
                            src="@/assets/images/spinner.gif"
                          />
                        </li>
                        <li>
                          {{
                            language.alreadyRegisterUser_model_content3
                          }}
                          {{
                            language.alreadyRegisterUser_model_content4
                          }}
                        </li>
                        <li>
                          {{
                            language.alreadyRegisterUser_model_content5
                          }}
                        </li>
                        <li>
                          {{
                            language.alreadyRegisterUser_model_content6
                          }}
                          {{
                            language.alreadyRegisterUser_model_clickhere
                          }}
                          {{
                            language.alreadyRegisterUser_model_content7
                          }}
                        </li>
                        <li>
                          {{
                            language.alreadyRegisterUser_model_content8
                          }}
                        </li>
                      </ul>
                      <p>
                        {{
                          language.clinical_modal_additional_content1
                        }}
                      </p>
                    </div>
                  </div>
                </div>
              </vue-final-modal>
              <!-- model pop end -->
              <form v-if="!accountCreated" @submit.prevent="signup">
                <div class="form-group">
                  <input
                    type="text"
                    v-model="regUser.user.firstName"
                    @input="signupChange()"
                    id="firstName"
                    :placeholder="language.firstname_label"
                    name="firstName"
                    class="form-control"
                    :class="{
                      'is-invalid':
                        submitted && v$.regUser.user.firstName.$error,
                    }"
                  />
                  <div
                    v-if="
                      submitted && v$.regUser.user.firstName.required.$invalid
                    "
                    class="invalid-feedback error_show"
                  >
                    {{ language.firstname_valid_error }}
                  </div>
                  <div
                    v-if="submitted && v$.regUser.user.firstName.valid.$invalid"
                    class="invalid-feedback error_show"
                  >
                    Invalid name
                  </div>
                </div>
                <div class="form-group">
                  <input
                    type="text"
                    v-model="regUser.user.lastName"
                    @input="signupChange()"
                    id="lastName"
                    name="lastName"
                    :placeholder="language.lastname_label"
                    class="form-control"
                    :class="{
                      'is-invalid':
                        submitted && v$.regUser.user.lastName.$error,
                    }"
                  />
                  <div
                    v-if="
                      submitted && v$.regUser.user.lastName.required.$invalid
                    "
                    class="invalid-feedback error_show"
                  >
                    {{ language.lastname_valid_error }}
                  </div>
                  <div
                    v-if="submitted && v$.regUser.user.lastName.valid.$invalid"
                    class="invalid-feedback error_show"
                  >
                    Invalid name
                  </div>
                </div>
                <div class="form-group">
                  <input
                    type="email"
                    v-model="regUser.user.email"
                    @input="signupChange()"
                    id="email"
                    name="email"
                    :placeholder="language.email_label"
                    class="form-control"
                    :class="{
                      'is-invalid': submitted && v$.regUser.user.email.$error,
                    }"
                  />
                  <div
                    v-if="submitted && v$.regUser.user.email.$error"
                    class="invalid-feedback error_show"
                  >
                    <span v-if="v$.regUser.user.email.required.$invalid">{{
                      language.enter_email
                    }}</span>
                    <span v-if="v$.regUser.user.email.email.$invalid">{{
                      language.email_valid_error
                    }}</span>
                  </div>
                </div>
                <div class="form-group">
                  <div class="input-group">
                    <input
                      v-bind:type="[showPassword ? 'text' : 'password']"
                      v-model="regUser.user.password"
                      autocomplete="off"
                      @input="checkPassword(), signupChange()"
                      id="password"
                      :placeholder="language.password_label"
                      name="password"
                      class="form-control"
                      :class="{
                        'is-invalid':
                          submitted && v$.regUser.user.password.$error,
                      }"
                    />
                    <div class="input-group-append">
                      <span
                        class="input-group-text show-icon"
                        @click="showPassword = !showPassword"
                        ><i class="fa fa-eye-slash" aria-hidden="true"></i
                      ></span>
                    </div>
                    <div
                      v-if="submitted && v$.regUser.user.password.$error"
                      class="invalid-feedback error_show"
                    >
                      <span v-if="v$.regUser.user.password.required.$invalid">{{
                        language.pass_enter_text
                      }}</span>
                      <span
                        v-if="v$.regUser.user.password.minLength.$invalid"
                        >{{ language.pass_valid }}</span
                      >
                    </div>
                    <div
                      v-if="
                        (regUser.user.password.includes(
                          regUser.user.firstName
                        ) &&
                          regUser.user.firstName != '') ||
                          (regUser.user.password.includes(regUser.user.email) &&
                            regUser.user.email != '')
                      "
                      class="error_show"
                    >
                      <p>
                        {{ language.password_not_contain_email }}
                      </p>
                    </div>
                    <div class="error_show" v-if="total_validation">
                      <p>{{ language.password_restrictions }}</p>
                      <p>{{ language.password_numeric }}</p>
                      <p>{{ language.password_lower }}</p>
                      <p>{{ language.password_upper }}</p>
                      <p>{{ language.password_special }}</p>
                      <p>{{ language.password_pattern }}</p>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <input
                    type="text"
                    v-model="regUser.user.organisation"
                    @input="signupChange()"
                    id="organisation"
                    name="organisation"
                    :placeholder="language.Org_Name"
                    class="form-control"
                    :class="{
                      'is-invalid':
                        submitted && v$.regUser.user.organisation.$error,
                    }"
                  />
                  <div
                    v-if="
                      submitted &&
                        v$.regUser.user.organisation.required.$invalid
                    "
                    class="invalid-feedback error_show"
                  >
                    {{language.signup_organisation_label}}
                  </div>
                </div>
                <div class="form-group">
                  <select
                    v-model="regUser.user.country"
                    id="country"
                    @input="signupChange()"
                    name="country"
                    class="form-control"
                    :class="{
                      'is-invalid': submitted && v$.regUser.user.country.$error,
                    }"
                  >
                    <option value="">
                      {{ language.country_region_text }}
                    </option>
                    <option
                      v-bind:value="item.code"
                      v-for="item in countryList"
                      :key="item.code"
                    >
                      {{ item.name }}
                    </option>
                  </select>
                  <div
                    v-if="
                      submitted && v$.regUser.user.country.required.$invalid
                    "
                    class="invalid-feedback error_show"
                  >
                    {{ language.Enter_CountryName }}
                  </div>
                </div>
                <div class="form-group" v-if="$route.params.region == 'en-us'">
                  <select
                    v-model="regUser.user.businessType"
                    id="businessType"
                    @input="signupChange()"
                    name="businessType"
                    class="form-control"
                    :class="{
                      'is-invalid':
                        submitted && v$.regUser.user.businessType.$error,
                    }"
                  >
                    <option value="" selected>
                      {{ language.business_type_text }}
                    </option>
                    <option
                      v-bind:value="item.code"
                      v-for="item in businessTypeList"
                      :key="item.code"
                    >
                      {{ item.name }}
                    </option>
                  </select>
                  <div
                    v-if="
                      submitted &&
                        v$.regUser.user.businessType.required.$invalid
                    "
                    class="invalid-feedback error_show"
                  >
                    {{ language.Enter_BusinessType }}
                  </div>
                </div>
                <div class="form-group" v-if="$route.params.region == 'en-us'">
                  <select
                    v-model="regUser.user.jobFunction"
                    @input="signupChange()"
                    id="jobFunction"
                    name="jobFunction"
                    class="form-control"
                    :class="{
                      'is-invalid':
                        submitted && v$.regUser.user.jobFunction.$error,
                    }"
                  >
                    <option value="">
                      {{ language.job_function_text }}
                    </option>
                    <option
                      v-bind:value="item.code"
                      v-for="item in jobFunctionList"
                      :key="item.code"
                    >
                      {{ item.name }}
                    </option>
                  </select>
                  <div
                    v-if="
                      submitted && v$.regUser.user.jobFunction.required.$invalid
                    "
                    class="invalid-feedback error_show"
                  >
                    {{ language.Enter_JobFunction }}
                  </div>
                </div>
                <div class="form-group" v-if="$route.params.region == 'en-us'">
                  <input
                    type="text"
                    v-model="regUser.user.zipCode"
                    @input="signupChange()"
                    id="zipCode"
                    :placeholder="language.zip_code_text"
                    name="zipCode"
                    class="form-control"
                    :class="{
                      'is-invalid': submitted && v$.regUser.user.zipCode.$error,
                    }"
                  />
                  <div
                    v-if="
                      submitted && v$.regUser.user.zipCode.required.$invalid
                    "
                    class="invalid-feedback error_show"
                  >
                    {{ language.Enter_ZipCode }}
                  </div>
                </div>
                <!-- checkboxes start -->
                <div class="checkbox-bg">
                  <div class="subs-title">{{language.signup_subscriptions_label}}</div>
                  <div class="form-check">
                    <input
                      type="checkbox"
                      class="form-check-input"
                      v-model="regUser.user.clinical"
                      id="clinical"
                      name="clinical"
                      value="clinical"
                      @change="clinicalEvent"
                      :class="{
                        'is-invalid': submitted && showContentError,
                      }"
                    />
                    <label class="form-check-label" for="flexCheckDefault">
                      <span class="checkboxs ml-3">
                        {{ language.content_clinical }}
                        <span @click.prevent="clinical_model = !clinical_model">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="22"
                            height="22"
                            fill="currentColor"
                            class="bi bi-info-circle m-1 info-icon"
                            viewBox="0 0 16 16"
                          >
                            <path
                              d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"
                            />
                            <path
                              d="M8.93 6.588l-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"
                            />
                          </svg>
                        </span>
                      </span>
                    </label>
                  </div>
                  <!-- model pop start -->
                  <vue-final-modal v-model="clinical_model" class="modal">
                    <div class="modal-wrapper">
                      <div class="modal-container">
                        <content select=".modal-header">
                          <div class="modal-header col-md-12">
                            <div class="row">
                              <div class="col-10">
                                <h2>{{ language.content_clinical }}</h2>
                              </div>
                              <div class="col-2 text-right">
                                <button
                                  type="button"
                                  @click.prevent="
                                    clinical_model = !clinical_model
                                  "
                                  class="close"
                                  aria-label="Close"
                                >
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                            </div>
                          </div>
                        </content>
                        <div class="modal-body">
                          <p>{{ language.clinical_modal_content }}</p>
                          <ul>
                            <li>
                              {{
                                language.clinical_modal_clinical_manuals
                              }}
                            </li>
                            <li>
                              {{
                                language.clinical_modal_medical_research
                              }}
                            </li>
                            <li>
                              {{
                                language.clinical_modal_additional_content
                              }}
                            </li>
                          </ul>
                          <p>
                            {{
                              language.clinical_modal_additional_content1
                            }}
                          </p>
                        </div>
                      </div>
                    </div>
                  </vue-final-modal>
                  <!-- model pop end -->
                  <div class="form-check">
                    <label class="form-check-label">
                      <input
                        type="checkbox"
                        class="form-check-input"
                        v-model="regUser.user.commercial"
                        id="commercial"
                        name="commercial"
                        value="commercial"
                        @change="commercialEvent"
                        :class="{
                          'is-invalid': submitted && showContentError,
                        }"
                      />
                      <span class="checkboxs ml-3">
                        {{ language.content_commercial }}
                        <span
                          @click.prevent="commercial_model = !commercial_model"
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="22"
                            height="22"
                            fill="currentColor"
                            class="bi bi-info-circle m-1 info-icon"
                            viewBox="0 0 16 16"
                          >
                            <path
                              d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"
                            />
                            <path
                              d="M8.93 6.588l-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"
                            />
                          </svg>
                        </span>
                      </span>
                    </label>
                  </div>

                  <!-- model pop start -->
                  <vue-final-modal v-model="commercial_model" class="modal">
                    <div class="modal-wrapper">
                      <div class="modal-container">
                        <content select="modal-header">
                          <div class="modal-header">
                            <div class="row">
                              <div class="col-10">
                                <h2>
                                  {{ language.content_commercial }}
                                </h2>
                              </div>
                              <div class="col-2 text-right">
                                <button
                                  type="button"
                                  @click.prevent="
                                    commercial_model = !commercial_model
                                  "
                                  class="close"
                                  aria-label="Close"
                                >
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                            </div>
                          </div>
                        </content>
                        <div class="modal-body">
                          <p>{{ language.commercial_modal_content }}</p>
                          <ul>
                            <li>
                              {{
                                language.commercial_modal_product_resources
                              }}
                            </li>
                            <li>
                              {{
                                language.commercial_modal_product_presentation
                              }}
                            </li>
                            <li>
                              {{
                                language.clinical_modal_additional_content
                              }}
                            </li>
                          </ul>
                          <p>
                            {{
                              language.commercial_modal_additional_content1
                            }}
                          </p>
                        </div>
                      </div>
                    </div>
                  </vue-final-modal>
                  <!-- model pop end -->
                  <!-- techincal checkbox -->
                  <div class="form-check">
                    <input
                      type="checkbox"
                      class="form-check-input"
                      v-model="regUser.user.technical"
                      id="technical"
                      name="technical"
                      value="technical"
                      @change="technicalEvent"
                      :class="{
                        'is-invalid': submitted && showContentError,
                      }"
                    />
                    <label class="form-check-label" for="flexCheckDefault">
                      <span class="checkboxs ml-3">
                        {{language.signup_technical_title_label}}
                         <span  @click.prevent="technical_model = !technical_model">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="22"
                            height="22"
                            fill="currentColor"
                            class="bi bi-info-circle m-1 info-icon"
                            viewBox="0 0 16 16"
                          >
                            <path
                              d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"
                            />
                            <path
                              d="M8.93 6.588l-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"
                            />
                          </svg>
                        </span>
                      </span>
                    </label>
                  </div>
                  <!-- Technical popup start -->
                   <vue-final-modal v-model="technical_model" class="modal">
                    <div class="modal-wrapper">
                      <div class="modal-container">
                        <content select="modal-header">
                          <div class="modal-header">
                            <div class="row">
                              <div class="col-10">
                                <h2>
                                  {{ language.technical_title }}
                                </h2>
                              </div>
                              <div class="col-2 text-right">
                                <button
                                  type="button"
                                  @click.prevent="
                                    technical_model = !technical_model
                                  "
                                  class="close"
                                  aria-label="Close"
                                >
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                            </div>
                          </div>
                        </content>
                        <div class="modal-body">
                          <p>{{ language.technical_content }}</p>
                          <ul>
                            <li>
                              {{
                                language.technical_software
                              }}
                            </li>
                            <li>
                              {{
                                language.technical_device_upgrade
                              }}
                            </li>
                            <li>
                              {{
                                language.technical_services
                              }}
                            </li>
                          </ul>
                          <p>
                            {{
                              language.technical_training_content
                            }}
                          </p>
                        </div>
                      </div>
                    </div>
                  </vue-final-modal>
                  <!--Technical popup end -->
                  <div v-if="submitted && showContentError" class="error_show">
                    {{ language.signup_material_text }}
                  </div>
                </div>
                <!-- 3 checkboxes end  -->
                <div class="form-check">
                  <label class="form-check-label">
                    <input
                      type="checkbox"
                      class="form-check-input"
                      v-model="regUser.user.accept"
                      id="accept"
                      name="accept"
                      value=""
                      @change="finalCheck"
                      :class="{
                        'is-invalid':
                          submitted && v$.regUser.user.accept.$error,
                      }"
                    />
                    <span class="checkboxs ml-3"
                      >
                    {{ language.accept_label }}
                      <span><a :href="termsConditonsLinks[0]" target="_blank">{{ language.terms_label }}</a></span>
                      {{ language.and_label }}
                      <span><a :href="termsConditonsLinks[1]" target="_blank">{{ language.Privacy }}</a></span>
                        </span
                    >
                    <div
                      v-if="
                        submitted && v$.regUser.user.accept.required.$invalid
                      "
                      class="invalid-feedback error_show"
                    >
                      {{ language.checkbox_accept_text }}
                    </div>
                  </label>
                </div>
                <div class="form-group mt-3">
                  <vue-button-spinner
                    type="submit"
                    class="btn signupbtn"
                    :is-loading="isLoading"
                    :disabled="isLoading"
                    >{{
                      language.signupbutton_label
                    }}</vue-button-spinner
                  >
                </div>
                <div>
                  {{ language.already_label }}
                  <!-- <span> -->
                  <router-link
                    class="samealign"
                    :to="`/${region}/signin.html`"
                    >{{ language.signin_label }}</router-link
                  >
                  <!-- </span> -->
                </div>
              </form>
              <div v-if="accountCreated">
                <img src="@/assets/images/envelope.png" />
                <p class="mt-2 mb-0">
                  {{ language.resetpassword_instruction }}
                </p>
                <p class="mb-3 font-weight-bold">{{ regUser.user.email }}</p>
              </div>
              <div v-if="accountCreated">
                <div class="row">
                  <div class="col-md-10 text-left d-flex align-items-center">
                    <div>
                      <span
                        class="res-link-primary"
                        @click="resendNewAccountVerification()"
                        >{{ language.resend_label }}</span
                      ><span class="mx-2">|</span>
                    </div>
                    <router-link
                      class="nav-link links res-link-primary p-0 backlink"
                      :to="`/${region}/signin.html`"
                      >{{ language.backtoaccount_label }}</router-link
                    >
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import useVuelidate from "@vuelidate/core";
import {
  required,
  email,
  minLength,
  maxLength,
  helpers,
} from "@vuelidate/validators";
import axios from "axios";
import VueButtonSpinner from "../components/spinner";
import "vue-loading-overlay/dist/vue-loading.css";
import { mapState, mapMutations } from "vuex";
import { OKTA_DOMAIN } from "@/Config";
export default {
  setup() {
    const v$ = useVuelidate();
    return { v$: v$ };
  },
  components: {
    VueButtonSpinner,
  },
  name: "app",
  data() {
    return {
      password: "",
      showPassword: false,
      commercial_model: false,
      already_exist: false,
      total_validation: false,
      clinical_model: false,
      technical_model: false,
      already_exist_model: false,
      region: "",
      isLoading: false,
      countryList: [],
      businessTypeList: [],
      jobFunctionList: [],
      default_region: null,
      showError: false,
      showContentError: false,
      accountCreated: false,
      inprogress: false,
      regUser: {
        user: {
          email: "",
          password: "",
          firstName: "",
          lastName: "",
          organisation: "",
          country: "",
          businessType: "",
          jobFunction: "",
          zipCode: "",
        },
        role: "PARTNER",
        accept: false,
        mySubscriptions: {
          subscriptions: [
            {
              subscriptionCode: "CLINICAL",
              subscribed: false,
            },
            {
              subscriptionCode: "COMMERCIAL",
              subscribed: false,
            },
            {
              subscriptionCode: "TECHNICAL",
              subscribed: false,
            },
          ],
        },
      },
      submitted: false,
    };
  },
  validations() {
    const regUser = {
      regUser: {
        user: {
          firstName: {
            required,
            maxLength: maxLength(15),
            valid: helpers.regex(/^[^@!.:/\\?&=_]*$/),
          },
          lastName: {
            required,
            maxLength: maxLength(15),
            valid: helpers.regex(/^[^@!.:/\\?&=_]*$/),
          },
          email: { required, email },
          password: { required, minLength: minLength(10) },
          organisation: { required },
          country: { required },
          accept: { required },
          clinical: {},
          commercial: {},
          technical: {},
        },
      },
    };
    if (this.region == "en-us") {
      regUser.regUser.user.jobFunction = { required };
      regUser.regUser.user.businessType = { required };
      regUser.regUser.user.zipCode = { required };
    }
    return regUser;
  },
  computed: {
    ...mapState([
      "language",
      "region",
    ]),
        termsConditonsLinks() {
    const region = this.$route.params.region;
if(region == "en-us") {
  return ["https://www.resmed.com/en-us/terms-of-use/", "https://www.resmed.com/en-us/privacy/"]
}
if(region == "en-au") {
  return ["https://www.resmed.com.au/terms-and-conditions", "https://www.resmed.com.au/privacy-policy"]
}
if(region == "en-ap") {
  return ["https://www.resmed.com/ap/en/index/terms-of-use.html ", "https://www.resmed.com/ap/en/index/privacy.html"]
}
if(region == "en-in") {
  return ["https://www.resmed.com/in/en/index/terms-of-use.html", "https://www.resmed.com/in/en/index/privacy.html"]
}
if(region == "pt-br") {
  return ["https://www.resmed.com.br/termos-de-uso-e-privacidade", "https://www.resmed.com.br/termos-de-uso-e-privacidade"]
}
if(region == "es-xl") {
  return ["https://www.resmed.lat/index/terms-of-use", "https://www.resmed.lat/aviso-de-privacidad-resmed"]
}

return [];
    },
    passwordValidation() {
      let errors = [];
      for (let condition of this.rules) {
        if (!condition.regex.test(this.password)) {
          errors.push(condition.message);
        }
      }
      if (errors.length === 0) {
        return { valid: true, errors };
      } else {
        return { valid: false, errors };
      }
    },
  },
  async mounted() {
    this.region = this.$route.params.region;
    await this.getCounty();
    if (this.$route.params.region == "en-us") {
      await this.getBusinessList();
      await this.getjobFunctionList();
    }
    this.setRegion(this.$route.params.region);
  },

  methods: {
    ...mapMutations(["setRegion"]),
    signupChange() {
      this.showError = false;
      this.already_exist = false;
    },
    dynamicFieldAdd(region) {
      if (region == "en-us") {
        alert(1);
        return { required };
      } else {
        alert(2);
        return {};
      }
    },
    checkPassword() {
      if (
        !(this.regUser.user.password.length >= 10) ||
        !/\d/.test(this.regUser.user.password) ||
        !/[a-z]/.test(this.regUser.user.password) ||
        !/[A-Z]/.test(this.regUser.user.password) ||
        !/[!@#$%^&*)(+=._-]/.test(this.regUser.user.password)
      ) {
        this.total_validation = true;
      } else {
        this.total_validation = false;
      }
      if (this.regUser.user.password.length == 0) {
        this.total_validation = false;
      }
    },

    clinicalEvent: function() {
      this.regUser.mySubscriptions.subscriptions[0].subscribed = this.regUser.user.clinical;
      if (
        this.regUser.user.commercial ||
        this.regUser.user.clinical ||
        this.regUser.user.technical
      ) {
        this.showContentError = false;
      }
    },
    commercialEvent: function() {
      this.regUser.mySubscriptions.subscriptions[1].subscribed = this.regUser.user.commercial;
      if (
        this.regUser.user.commercial ||
        this.regUser.user.clinical ||
        this.regUser.user.technical
      ) {
        this.showContentError = false;
      }
    },
    technicalEvent: function() {
      this.regUser.mySubscriptions.subscriptions[2].subscribed = this.regUser.user.technical;
      if( this.regUser.user.technical ){
        this.regUser.user.clinical = true;
        this.regUser.user.commercial = true;
      }
      else{
        this.regUser.user.clinical=false;
        this.regUser.user.commercial=false;
      }
      if (
        this.regUser.user.commercial ||
        this.regUser.user.clinical ||
        this.regUser.user.technical
      ) {
        this.showContentError = false;
      }
    },
    finalCheck: function() {
      this.regUser.accept = this.regUser.user.accept;
    },
    async getBusinessList() {
      const headers = {
        region: `${this.$route.params.region}`,
        "Content-Type": "application/json",
      };
      const response = await axios.get(
        OKTA_DOMAIN + "v1/common/business_type/list",
        { headers }
      );
      this.businessTypeList = response.data.businessTypes;
    },
    async getjobFunctionList() {
      const headers = {
        region: `${this.$route.params.region}`,
        "Content-Type": "application/json",
      };
      const response = await axios.get(
        OKTA_DOMAIN + "v1/common/job_function/list",
        { headers }
      );
      this.jobFunctionList = response.data.jobFunctions;
    },
    async getCounty() {
      const headers = {
        region: `${this.$route.params.region}`,
        "Content-Type": "application/json",
      };
      const response = await axios.get(OKTA_DOMAIN + "v1/common/country/list", {
        headers,
      });
      this.countryList = response.data.countries;
    },
    async signup() {
      if (this.$route.params.region != "en-us") {
        delete this.regUser.user.businessType;
        delete this.regUser.user.jobFunction;
        delete this.regUser.user.zipCode;
      }
      if (
        !this.regUser.user.clinical &&
        !this.regUser.user.commercial &&
        !this.regUser.user.technical
      ) {
        this.showContentError = true;
      }
      this.isLoading = true;
      this.submitted = true;
      this.v$.$touch();
      if (
        this.v$.$invalid ||
        this.showContentError ||
        !this.regUser.user.accept
      ) {
        this.isLoading = false;
        return;
      }
      if (this.regUser.user.password.includes(this.regUser.user.firstName)) {
        this.isLoading = false;
        return;
      }
      //delete this.regUser.user.clinical;
      //delete this.regUser.user.commercial;
      //delete this.regUser.user.accept;

      this.regUser.user.channel = window.location.origin;
      this.regUser.user.appId = "RMD";
      /*const requestOptions = {
        headers: {
          region: `${this.$route.params.region}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(this.regUser),
      };
      const createRes = await fetch(
        OKTA_DOMAIN + "v1/user/create",
        requestOptions
      );*/
      let signupDetails = {};
      let headers = {};
      //let userLogin = {};
      if (this.region == "en-us") {
        signupDetails = {
          user: {
            email: `${this.regUser.user.email}`,
            password: `${this.regUser.user.password}`,
            firstName: `${this.regUser.user.firstName}`,
            lastName: `${this.regUser.user.lastName}`,
            organisation: `${this.regUser.user.organisation}`,
            country: `${this.regUser.user.country}`,
            businessType: `${this.regUser.user.businessType}`,
            jobFunction: `${this.regUser.user.jobFunction}`,
            zipCode: `${this.regUser.user.zipCode}`,
            channel: window.location.origin,
            appId: "RMD",
          },
          role: "PARTNER",
          mySubscriptions: {
            subscriptions: [
              {
                subscriptionCode: "CLINICAL",
                subscribed: `${this.regUser.user.clinical ? true : false}`,
              },
              {
                subscriptionCode: "COMMERCIAL",
                subscribed: `${this.regUser.user.commercial ? true : false}`,
              },
              {
                subscriptionCode: "TECHNICAL",
                subscribed: `${this.regUser.user.technical ? true : false}`,
              },
            ],
          },
        };
      } else {
        signupDetails = {
          user: {
            email: `${this.regUser.user.email}`,
            password: `${this.regUser.user.password}`,
            firstName: `${this.regUser.user.firstName}`,
            lastName: `${this.regUser.user.lastName}`,
            organisation: `${this.regUser.user.organisation}`,
            country: `${this.regUser.user.country}`,
            channel: window.location.origin,
            appId: "RMD",
          },
          role: "PARTNER",
          mySubscriptions: {
            subscriptions: [
              {
                subscriptionCode: "CLINICAL",
                subscribed: `${this.regUser.user.clinical ? true : false}`,
              },
              {
                subscriptionCode: "COMMERCIAL",
                subscribed: `${this.regUser.user.commercial ? true : false}`,
              },
              {
                subscriptionCode: "TECHNICAL",
                subscribed: `${this.regUser.user.technical ? true : false}`,
              },
            ],
          },
        };
      }

      headers = {
        region: `${this.region}`,
        "Content-Type": "application/json",
      };
      await axios
        .post(OKTA_DOMAIN + "v1/user/create", signupDetails, { headers })
        .then((response) => {
          console.log("response", response);
          this.accountCreated = true;
        })
        .catch((error) => {
          console.log("error", error);
          this.accountCreated = false;
          if (error.response.data.message == "ACCOUNT_EXISTS") {
            this.already_exist = true;
            this.isLoading = false;
          } else {
            this.showError = true;
            this.signinErrMsg = error.response.data.message
              ? error.response.data.message
              : error.response.data;
            this.isLoading = false;
          }
        });
      /* console.log(createRes);
      if (createRes.status == 200) {
        this.$router.push(
          `/${this.$route.params.region}/confirmyouraccount.html`
        );
        console.log(createRes);
      }
      if (createRes.message == "ACCOUNT_EXISTS") {
        this.already_exist = true;
      }
      this.isLoading = false;*/
    },
    async resendNewAccountVerification() {
      this.already_exist = false;
      this.inprogress = true;
      this.isLoading = true;
      this.submitted = true;
      let headers = {};
      let resendUser = {
        user: {
          email: `${this.regUser.user.email}`,
          verify_link: "account_verification",
          channel: window.location.origin,
        },
        role: this.regUser.role,
      };

      //let userLogin = {};
      headers = {
        region: `${this.region}`,
        "Content-Type": "application/json",
      };
      await axios
        .post(OKTA_DOMAIN + "v1/user/resend_verify", resendUser, { headers })
        .then((response) => {
          console.log("response", response);
          this.accountCreated = true;
          this.inprogress = false;
        })
        .catch((error) => {
          console.log("error", error);
          this.accountCreated = false;
          if (error.response.data.message == "ACCOUNT_EXISTS") {
            this.already_exist = true;
            this.isLoading = false;
            this.inprogress = false;
          } else {
            this.showError = true;
            this.signinErrMsg = error.response.data.message;
            this.isLoading = false;
            this.inprogress = false;
          }
        });
      /* console.log(createRes);
      if (createRes.status == 200) {
        this.$router.push(
          `/${this.$route.params.region}/confirmyouraccount.html`
        );
        console.log(createRes);
      }
      if (createRes.message == "ACCOUNT_EXISTS") {
        this.already_exist = true;
      }
      this.isLoading = false;*/
    },
  },
};
</script>
<style scoped lang="scss">
.checkbox-bg {
  background-color: lightgrey;
  padding: 20px;
  border-radius: 4px;
  margin-bottom: 10px;
}

.subs-title {
  font-size: 25px;
  font-weight: 600;
}
.already-text {
  font-size: 16px;
}
.heading h1 {
  background: -webkit-linear-gradient(#fff, #999);
  -webkit-text-fill-color: transparent;
  -webkit-background-clip: text;
  text-align: center;
  margin: 0 0 5px 0;
  font-weight: 900;
  font-size: 4rem;
  color: #fff;
}
.heading h4 {
  color: #a990cc;
  text-align: center;
  margin: 0 0 35px 0;
  font-weight: 400;
  font-size: 24px;
}
.btn {
  outline: none !important;
}
.btn.btn-primary {
  background-color: #5c4084;
  border-color: #5c4084;
  outline: none;
}
.btn.btn-primary:hover {
  background-color: #442f62;
  border-color: #442f62;
}
.btn.btn-primary:active,
.btn.btn-primary:focus {
  background-color: #684895;
  border-color: #684895;
}
.btn.btn-primary .fa {
  padding-right: 4px;
}
.form-group {
  margin-bottom: 25px;
}
.info-icon {
  color: #1788c3;
  margin-bottom: 8px !important;
}
.signup {
  border-radius: 10px;
  margin-top: auto;
  margin-bottom: auto;
}
.info {
  font-size: 20px;
  color: #555;
}
.signup input:not(.form-check-input),
.signup select {
  height: 48px;
  border-radius: 7px;
  background-color: #f4f4f4;
  color: #555;
}
.error_show {
  padding: 0px;
  font-size: 16px;
  font-family: "Cern UltraLight", Helvetica, Arial, Serif !important;
  color: rgb(185, 74, 72);
}
.checkboxinput {
  width: 30px;
  height: 30px !important;
  background-color: #f4f4f4 !important;
}
.checkboxs {
  font-size: 20px;
}
#password {
  border-top-right-radius: 0px !important;
  border-bottom-right-radius: 0px !important;
}
.show-icon {
  border-top-right-radius: 7px !important;
  border-bottom-right-radius: 7px !important;
}
.signupbtn {
  background-color: #428bca !important;
  padding: 5px 40px !important;
  border-radius: 6px !important;
  font-size: 19px !important;
  color: #fff !important;
  display: flex !important;
}
.links {
  font-size: 18px;
}
.samealign {
  padding: 15px;
}
.has_required {
  text-decoration: line-through;
  color: #689868;
}
input.form-check-input {
  width: 20px !important;
  height: 20px !important;
}
[v-cloak] {
  opacity: 0;
}
#app {
  max-width: 600px;
  margin: 0 auto;
}
#passwordhide {
  position: absolute;
  right: 5px;
  top: 25px;
  bottom: 0px;
  height: 14px;
  margin-top: -10px;
  margin-right: 10px;
  font-size: 16px;
  cursor: pointer;
  color: rgb(204, 204, 204);
  text-align: right;
  text-transform: uppercase;
}
.modal-header {
  display: block !important;
  padding: 1rem 0px;
}
/* .modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.7);
  display: table;
  transition: opacity 0.3s ease;
} */
::v-deep .modal {
  display: flex;
  justify-content: center;
  align-items: center;
}
::v-deep .modal-content {
  display: flex;
  flex-direction: column;
}
.modal-wrapper {
  display: table-cell;
  vertical-align: middle;
  transform: translate(-50%, -50%) !important;
  top: 50%;
  left: 50%;
  position: absolute;
}
.modal-container {
  background: #fff;
  width: 600px;
  border-radius: 5px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.33);
  transition: all 0.3s ease;
  margin: 0 auto;
  padding: 20px 30px;
}
.modal-footer {
  margin-top: 15px;
}
.modal-enter,
.modal-leave {
  opacity: 0;
}
.modal-enter .modal-container,
.modal-leave .modal-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
.popup-spacing {
  margin-top: 130px;
}
@include media-breakpoint-down(md) {
  .modal-container {
    width: 350px;
  }
}
.backlink{
  color:blue !important;
}
</style>
