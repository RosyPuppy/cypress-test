<template>
  <div class="cssload-container">
    <div class="cssload-loading"><i></i><i></i></div>
  </div>
</template>
<script>
export default {};
</script>
<style scoped>
.cssload-container {
  display: block;
  margin: 49px auto;
  width: 97px;
}

.cssload-loading i {
  width: 49px;
  height: 49px;
  display: inline-block;
  background-color: #dd2726;
  border-radius: 50%;
}

.cssload-loading i:nth-child(1) {
  animation: cssload-loading-ani1 1.15s ease-in-out infinite;
  -o-animation: cssload-loading-ani1 1.15s ease-in-out infinite;
  -ms-animation: cssload-loading-ani1 1.15s ease-in-out infinite;
  -webkit-animation: cssload-loading-ani1 1.15s ease-in-out infinite;
  -moz-animation: cssload-loading-ani1 1.15s ease-in-out infinite;
}

.cssload-loading i:nth-child(2) {
  background-color: #1788c3;
  margin-left: -10px;
  animation: cssload-loading-ani1 1.15s ease-in-out 0.58s infinite;
  -o-animation: cssload-loading-ani1 1.15s ease-in-out 0.58s infinite;
  -ms-animation: cssload-loading-ani1 1.15s ease-in-out 0.58s infinite;
  -webkit-animation: cssload-loading-ani1 1.15s ease-in-out 0.58s infinite;
  -moz-animation: cssload-loading-ani1 1.15s ease-in-out 0.58s infinite;
}

/** new spinner icons8.com End **/
/** new spinner icons8.com end **/
@keyframes cssload-loading-ani1 {
  70% {
    transform: scale(0.5);
  }
}

@-o-keyframes cssload-loading-ani1 {
  70% {
    -o-transform: scale(0.5);
  }
}

@-ms-keyframes cssload-loading-ani1 {
  70% {
    -ms-transform: scale(0.5);
  }
}

@-webkit-keyframes cssload-loading-ani1 {
  70% {
    -webkit-transform: scale(0.5);
  }
}

@-moz-keyframes cssload-loading-ani1 {
  70% {
    -moz-transform: scale(0.5);
  }
}
</style>
