<template>
  <div class="container mt-5 mt-lg-0">
    <div class="row">
      <div class="col-xs-12 col-md-9 col-lg-6 col-xl-5 m-auto">
        <div v-if="success" class="signin mt-0">
          <success-message
            :header="language.password_verified_header"
            :message="language.verify_thanks_password"
            :signlabel="language.signin_header"
          ></success-message>
        </div>
        <div v-else class="signin mt-0">
          <h2 class="text-center m-5 title">{{ language.verify_header }}</h2>
          <div class="pb-4 info">
            {{ language.tagline }}
          </div>
          <div v-if="error" class="my-3">
            <p class="bg-danger p-2 text-light already-text rounded">
              {{ error }}
            </p>
          </div>
          <form @submit.prevent="handleSubmit">
            <div class="form-group">
              <div class="input-group">
                <input
                  v-bind:type="[showPassword ? 'text' : 'password']"
                  @input="checkPassword()"
                  v-model="user.newpassword"
                  :placeholder="language.newpassword_label"
                  id="password"
                  name="newpassword"
                  class="form-control"
                  :class="{
                    'is-invalid': submitted && v$.user.newpassword.$error,
                  }"
                />
                <div class="input-group-append">
                  <span
                    class="input-group-text show-icon"
                    @click="showPassword = !showPassword"
                    ><i
                      v-bind:class="[
                        showPassword ? 'fa fa-eye' : 'fa fa-eye-slash',
                      ]"
                      aria-hidden="true"
                    ></i
                  ></span>
                </div>
                <div
                  v-if="submitted && v$.user.newpassword.$error"
                  class="invalid-feedback"
                >
                  <span v-if="v$.user.newpassword.required.$invalid">{{
                    language.pass_req_text
                  }}</span>
                  <span v-if="v$.user.newpassword.minLength.$invalid">{{
                    language.pass_enter_text
                  }}</span>
                </div>
              </div>
              <div class="error_show" v-if="total_validation">
                <p class="mb-0">{{ language.password_restrictions }}</p>
                <p class="ml-4 mb-0">1. {{ language.password_numeric }}</p>
                <p class="ml-4 mb-0">2. {{ language.password_lower }}</p>
                <p class="ml-4 mb-0">3. {{ language.password_upper }}</p>
                <p class="ml-4 mb-0">4. {{ language.password_special }}</p>
                <p class="mb-0">{{ language.password_pattern }}</p>
              </div>
            </div>
            <div class="form-group">
              <vue-button-spinner
                class="btn res-spin-btn my-2"
                :is-loading="isLoading"
                :disabled="isLoading"
              >
                {{ language.changepassword_label }}
              </vue-button-spinner>
            </div>
            <div></div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import useVuelidate from "@vuelidate/core";
import { required, minLength } from "@vuelidate/validators";
import { mapState, mapMutations } from "vuex";
import VueButtonSpinner from "../components/spinner";
import Api from "@/api";
import checkImg from "@/assets/images/check-circle-regular.svg";

export default {
  name: "app",
  setup() {
    const v$ = useVuelidate();
    return { v$ };
  },
  components: {
    VueButtonSpinner,
  },
  data() {
    return {
      user: {
        newpassword: "",
      },
      submitted: false,
      isLoading: false,
      changePassToken: null,
      showPassword: false,
      total_validation: false,
      error: null,
      success: false,
      checkImg: checkImg,
    };
  },
  validations: {
    user: {
      newpassword: { required, minLength: minLength(10) },
    },
  },
  computed: {
    ...mapState(["language", "region"]),
  },
  async mounted() {
    this.setRegion(this.$route.params.region);
    this.changePassToken = this.$route.query.token;
  },
  methods: {
    ...mapMutations(["setRegion"]),
    goSignin() {
      this.$router.push("signin.html");
    },
    checkPassword() {
      if (
        !(this.user.newpassword.length >= 10) ||
        !/\d/.test(this.user.newpassword) ||
        !/[a-z]/.test(this.user.newpassword) ||
        !/[A-Z]/.test(this.user.newpassword) ||
        !/[!@#$%^&*)(+=._-]/.test(this.user.newpassword)
      ) {
        this.total_validation = true;
      } else {
        this.total_validation = false;
      }
      if (this.user.newpassword.length == 0) {
        this.total_validation = false;
      }
    },
    async handleSubmit() {
      try {
        this.submitted = true;

        // stop here if form is invalid
        this.v$.$touch();
        if (this.v$.$invalid) {
          return;
        }
        this.isLoading = true;
        await Api.verifyChangePassword(
          this.changePassToken,
          this.user.newpassword
        );
        this.isLoading = false;
        this.error = null;
        this.success = true;
      } catch (error) {
        this.error = error.message;
        this.isLoading = false;
      }
    },
  },
};
</script>
<style scoped>
.check-img {
  width: 120px;
  margin: auto;
}
.signin {
  border-radius: 10px;
  margin-top: auto;
  margin-bottom: auto;
}
.signin input {
  height: 48px;
  border-radius: 7px;
  background-color: #f4f4f4;
  color: #555;
  border: 1px solid #000;
}
.signinbtn {
  padding: 12px 40px;
  border-radius: 10px;
  font-size: 19px;
}
.links {
  font-size: 18px;
}
.info {
  font-size: 20px;
  color: #555;
  text-align: center;
}
.error_show {
  color: #b94a48;
}
</style>
