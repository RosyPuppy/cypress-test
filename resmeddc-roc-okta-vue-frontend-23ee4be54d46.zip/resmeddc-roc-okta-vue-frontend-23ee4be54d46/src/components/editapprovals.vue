<template>
  <div class="container mt-5 mt-lg-0">
    <pageloader class="mobile-page-load" v-if="pageload" />
    <div v-else>
      <div class="row">
        <div class="col-md-12 m-auto">
          <div class="signin">
            <h2 class="text-center m-5 title">{{ language.Manage_Account }}</h2>
            <div class="mb-4">
              <h4 v-if="`${userslist}` == 'pending'" class="text-center">
                {{ language.Pending_Approvals }}
              </h4>
              <h4 v-if="`${userslist}` == 'approved'" class="text-center">
                {{ language.Approved_Users }}
              </h4>
              <h4 v-if="`${userslist}` == 'rejected'" class="text-center">
                {{ language.Rejected_Users }}
              </h4>
            </div>
            <div>
              <div class="row align-items-baseline">
                <div class="col-md-3 info-grey">
                  <p>
                    {{ language.edit_approval_showing_label }}
                    {{ userRecCount ? currentPage * 50 - 49 : 0 }} -
                    {{
                      currentPage * 50 > userRecCount
                        ? userRecCount
                        : currentPage * 50
                    }}
                    of {{ userRecCount }}
                    {{
                      language.myAccountCategoryStatus[
                        userslist.toUpperCase()
                      ].toLowerCase()
                    }}
                    {{ language.edit_approval_record_label }}:
                  </p>
                </div>
                <div class="col-md-6">
                  <form>
                    <div class="form-group">
                      <input
                        v-model="searchValue"
                        @input="search"
                        type="text"
                        class="form-control"
                        :placeholder="language.editapr_search_label"
                      />
                      <div v-if="searchError" class="d-block invalid-feedback">
                        {{ language.editapr_search_lable_char }}
                      </div>
                    </div>
                  </form>
                </div>
                <div class="col-md-3">
                  <select
                    v-model="userslist"
                    @input="userTypeChange"
                    id="userslist"
                    name="userslist"
                    class="form-control dropdown-bg"
                  >
                    <!-- <option value="pending" selected>
                      Filter by pending users
                    </option> -->
                    <!-- <option value="approved">
                      Filter by approved users
                    </option>
                    <option value="rejected">
                      Filter by rejected users
                    </option> -->
                    -->
                    <option
                      v-bind:value="item.code"
                      v-for="item in language.userslists"
                      :key="item.code"
                    >
                      {{ item.name }}
                    </option>
                  </select>
                </div>
              </div>
              <!-- Bulk mode switch -->
              <div v-if="actionCol" class="my-3 text-center d-block d-md-flex">
                <div class="mb-3 mb-md-0">
                  <div>{{language.editapr_bulk_label}}</div>
                  <el-switch v-model="bulkmode" @change="bulkmodeSwitch"> </el-switch>
                </div>
                <!-- Bulk action buttons -->
                <div
                  v-if="bulkmode && multipleSelection.length > 0"
                  class="d-flex justify-content-center ml-0 ml-md-5"
                >
                  <button
                    type="button"
                    @click="approveRecord(`bulk`)"
                    class="btn btn-outline-primary mr-2 px-4 approve"
                  >
                    {{ language.approve_text }}
                  </button>
                  <button
                    @click="showmodal(`bulk`)"
                    type="button"
                    class="btn btn-outline-danger px-4 reject"
                  >
                    {{ language.reject_text }}
                  </button>
                </div>
              </div>
              <div id="success-status">
                <div
                  v-if="aprrovedStatus"
                  class="approve-dialog p-2 text-light"
                >
                  <i class="fa fa-check-circle"></i>
                  {{ language.editapr_approve_label }}
                </div>
                <div v-if="rejectStatus" class="error-dialog p-2 text-light">
                  <i class="fa fa-times-circle"></i>
                  {{ language.editapr_reject_label }}
                </div>
              </div>
              <div class="text-right mt-2">
                <el-pagination
                  @current-change="changePage"
                  :current-page="currentPage"
                  :page-size="50"
                  :pager-count="6"
                  layout="prev, pager, next"
                  :total="userRecCount"
                >
                </el-pagination>
              </div>
              <!-- Desktop View -->
              <el-table
                ref="multipleTable"
                class="d-none d-lg-block"
                :data="allData"
                :default-sort="{
                  prop: 'requestedDate',
                  order: 'descending',
                }"
                style="width: 100%"
                @selection-change="handleSelectionChange"
              >
                <el-table-column v-if="bulkmode" type="selection" width="55">
                </el-table-column>
                <el-table-column
                  prop="profile.firstName"
                  :label="language.user_text"
                  sortable
                  :sort-method="(obj1, obj2) => sorter(obj1, obj2, 'firstName')"
                  min-width="150"
                >
                  <template #default="scope">
                    <div class="table-name">
                      {{
                        scope.row.profile.firstName +
                          " " +
                          scope.row.profile.lastName
                      }}
                      <span
                        style="cursor: pointer; margin-left: 5px"
                        v-if="scope.row.rejectedNotes"
                        v-on:click="onPopup(scope.row)"
                      >
                        <i class="fa fa-ban" aria-hidden="true"></i>
                      </span>
                    </div>
                  </template>
                </el-table-column>
                <el-table-column
                  prop="profile.email"
                  :label="language.id_subheader"
                  sortable
                  :sort-method="(a, b) => sorter(a, b, 'email')"
                  min-width="240"
                >
                </el-table-column>
                <el-table-column
                  prop="countryFullName"
                  :label="language.country_text"
                  sortable
                  :sort-method="
                    (obj1, obj2) => sorter(obj1, obj2, 'countryFullName', false)
                  "
                  min-width="120"
                >
                </el-table-column>
                <el-table-column
                  prop="profile.organisation"
                  :label="language.organization_text"
                  sortable
                  :sort-method="
                    (obj1, obj2) => sorter(obj1, obj2, 'organisation')
                  "
                  min-width="140"
                >
                </el-table-column>
                <el-table-column
                  prop="type"
                  :label="language.content_text"
                  sortable
                  :sort-method="
                    (obj1, obj2) => sorter(obj1, obj2, 'type', false)
                  "
                  min-width="120"
                >
                  <template #default="scope">
                    <div class="subcat_tooltip">
                      <div class="table-name">
                        {{ language.subscriptionCode[scope.row.type] }}
                      </div>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18"
                        height="18"
                        fill="currentColor"
                        class="bi bi-info-circle m-1 info-icon"
                        viewBox="0 0 16 16"
                        v-if="techSubCategoryTooltip(scope)"
                        @click.prevent="techSubCategoryModal(scope.row)"
                      >
                        <path
                          d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"
                        />
                        <path
                          d="M8.93 6.588l-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"
                        />
                      </svg>
                    </div>
                  </template>
                </el-table-column>
                <el-table-column
                  :prop="getDateCol"
                  :label="language.request_received"
                  :formatter="dateTime"
                  sortable
                  :sort-method="
                    (obj1, obj2) => sorter(obj1, obj2, 'dateCol', false)
                  "
                  min-width="170"
                >
                </el-table-column>
                <el-table-column
                  v-if="actionCol && !bulkmode"
                  props="action"
                  :label="language.action_text"
                  width="240"
                >
                  <template #default="scope">
                    <div class="d-flex" v-if="region=='de-ch'">
                      <button
                        type="button"
                        @click="approveRecord(scope.row)"
                        class="btn btn-outline-primary mr-2 px-2 approve"
                      >
                        {{ language.approve_text }}
                      </button>
                      <button
                        @click="showmodal(scope.row)"
                        type="button"
                        class="btn btn-outline-danger px-2 reject"
                      >
                        {{ language.reject_text }}
                      </button>
                    </div>
                    <div class="d-flex" v-else>
                      <button
                        type="button"
                        @click="approveRecord(scope.row)"
                        class="btn btn-outline-primary mr-2 px-4 approve"
                      >
                        {{ language.approve_text }}
                      </button>
                      <button
                        @click="showmodal(scope.row)"
                        type="button"
                        class="btn btn-outline-danger px-4 reject"
                      >
                        {{ language.reject_text }}
                      </button>
                    </div>
                  </template>
                </el-table-column>
              </el-table>
              <!-- Mobile View -->
              <el-checkbox-group v-model="multipleSelection">
                <el-collapse
                  accordion
                  v-model="activeNames"
                  class="d-block d-lg-none"
                  v-for="(item, index) in allData"
                  :key="index"
                >
                  <div style="position: relative">
                    <span class="bulk-check-mobile" v-if="bulkmode">
                      <el-checkbox
                        class="mobile-check-box"
                        :label="item"
                      ></el-checkbox>
                    </span>
                    <el-collapse-item
                      :title="
                        item.profile.firstName + ' ' + item.profile.lastName
                      "
                      :name="index"
                      class="name-bgcolor"
                      :class="{
                        'mobile-bulk-view-title': bulkmode,
                      }"
                    >
                      <div class="mb-3">
                        <div class="py-1">
                          Email:
                          <span class="font-weight-bold">{{
                            item.profile.email
                          }}</span>
                        </div>
                        <div class="py-1">
                          Country:
                          <span class="font-weight-bold">{{
                            item.profile.country
                          }}</span>
                        </div>
                        <div class="py-1">
                          Organisation:
                          <span class="font-weight-bold">{{
                            item.profile.organisation
                          }}</span>
                        </div>
                        <div class="py-1">
                          Content:
                          <span class="font-weight-bold">{{ item.type }}</span>
                        </div>
                        <div class="py-1">
                          {{ requestedColNames }}:
                          <span class="font-weight-bold">{{
                            dateTime(item)
                          }}</span>
                        </div>
                      </div>
                      <div
                        class="d-flex align-items-baseline"
                        v-if="actionCol && !bulkmode"
                      >
                        <div class="mr-3">Actions:</div>
                        <button
                          @click="approveRecord(item)"
                          type="button"
                          class="btn btn-outline-danger px-4 reject"
                        >
                          {{ language.approve_text }}
                        </button>
                        <button
                          @click="showmodal(item)"
                          type="button"
                          class="btn btn-outline-danger px-4 reject"
                        >
                          {{ language.reject_text }}
                        </button>
                      </div>
                    </el-collapse-item>
                    <span
                      class="block-icon-mobile"
                      v-if="item.rejectedNotes"
                      v-on:click="onPopup(item)"
                    >
                      <i class="fa fa-ban" aria-hidden="true"></i>
                    </span>
                  </div>
                </el-collapse>
              </el-checkbox-group>
              <div class="text-right mt-2">
                <el-pagination
                  @current-change="changePage"
                  :current-page="currentPage"
                  :page-size="50"
                  :pager-count="6"
                  layout="prev, pager, next"
                  :total="userRecCount"
                >
                </el-pagination>
              </div>
            </div>
            <div>
              <vue-final-modal
                v-model="showModal"
                class="modal"
                @click-outside="closemodal"
              >
                <div class="modal-wrapper">
                  <div class="modal-container">
                    <content select=".modal-header">
                      <div class="modal-header col-md-12">
                        <div class="row">
                          <div class="col-10">
                            <h4>{{ language.reject_confirm_text }}</h4>
                          </div>

                          <div class="col-2 text-right">
                            <button
                              type="button"
                              @click="closemodal"
                              class="close"
                              aria-label="Close"
                            >
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </content>
                    <div class="modal-body">
                      <select
                        v-model="selectedUserProfile.notes"
                        class="form-select"
                        aria-label="Default select example"
                      >
                        <option value="0" selected>
                          {{ language.reject_content_popup_dropdowntitle }}
                        </option>
                        <option
                          v-bind:value="item.code"
                          v-for="item in language.reject_dropdown_options"
                          :key="item.code"
                        >
                          {{ item.name }}
                        </option>
                      </select>
                    </div>
                    <div class="modal-body">
                      {{ language.reject_request_text }}
                    </div>
                    <div class="modal-body">
                      <textarea
                        :disabled="selectedUserProfile.notes == 0"
                        :placeholder="
                          language.reject_content_popup_additionalComments
                        "
                        class="w-100"
                        v-model="selectedUserProfile.comments"
                      ></textarea>
                    </div>
                    <div class="checktext modal-body">
                      <div class="form-check">
                        <input
                          :disabled="selectedUserProfile.comments.length == 0"
                          class="form-check-input"
                          type="checkbox"
                          v-model="selectedUserProfile.includeuser"
                          id="flexCheckDefault"
                        />
                        <label class="form-check-label" for="flexCheckDefault">
                          {{ language.reject_content_popup_content1 }}
                        </label>
                      </div>
                    </div>
                    <div
                      class="
                        d-flex
                        align-items-center
                        justify-content-between
                        m-3
                      "
                    >
                      <button
                        class="btn btn-primary res-btn-primary mb-3"
                        @click.prevent="closemodal"
                      >
                        {{ language.no_text }}
                      </button>
                      <button
                        :disabled="selectedUserProfile.notes == 0"
                        class="btn btn-primary res-btn-primary mb-3"
                        @click.prevent="rejectRecord"
                      >
                        {{ language.submit_label }}
                      </button>
                    </div>
                  </div>
                </div>
              </vue-final-modal>
            </div>
            <div>
              <vue-final-modal
                v-if="rejectRow"
                v-model="showReject"
                class="modal"
                @click-outside="closereject"
              >
                <div class="modal-wrapper">
                  <div class="modal-container">
                    <content select="modal-header">
                      <div class="modal-header col-md-12">
                        <div class="row">
                          <div class="col-10">
                            <h4>{{ language.User_info }}</h4>
                          </div>

                          <div class="col-2 text-right">
                            <button
                              type="button"
                              @click="closereject"
                              class="close"
                              aria-label="Close"
                            >
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </content>
                    <div class="modal-body">
                      <div class="mt-1">
                        {{ language.firstname_label }}:
                        <span class="font-weight-bold">{{
                          rejectRow.profile.firstName
                        }}</span>
                      </div>
                      <div class="mt-1">
                        {{ language.lastname_label }}:
                        <span class="font-weight-bold">{{
                          rejectRow.profile.lastName
                        }}</span>
                      </div>
                      <div class="mt-1 overflow-auto">
                        {{ language.email_label }}:
                        <span class="font-weight-bold">{{
                          rejectRow.profile.email
                        }}</span>
                      </div>
                      <div class="mt-1">
                        {{ language.organization_text }}:
                        <span class="font-weight-bold">{{
                          rejectRow.profile.organisation
                        }}</span>
                      </div>
                      <div class="mt-4 mb-2">{{ language.notes_text }}:</div>
                      <div
                        style="line-height: 25px"
                        v-html="rejectRow.rejectedNotes"
                      ></div>
                    </div>
                  </div>
                </div>
              </vue-final-modal>
            </div>
            <!-- My text to check -->
            <div>
              <vue-final-modal
                v-model="showtechModal"
                class="modal"
                @click-outside="closemodal"
              >
                <div class="modal-wrapper">
                  <div class="modal-container" id="popup-approve">
                    <content select=".modal-header">
                      <div class="modal-header col-md-12">
                        <div class="row">
                          <div class="col-10">
                            <h4>
                              <strong>{{
                                language.tech_approve_title_label
                              }}</strong>
                            </h4>
                          </div>

                          <div class="col-2 text-right">
                            <button
                              type="button"
                              @click="closemodal"
                              class="close"
                              aria-label="Close"
                            >
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </content>
                    <div class="modal-body">
                      <h5>{{ language.tech_approve_subtitle_label }}</h5>
                    </div>
                    <div class="modal-body">
                      <div
                        class="form-check form-check-inline cat-checkbox"
                        v-if="selectedUserProfile.sleep == 'PENDING'"
                      >
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="inlineCheckbox1"
                          v-model="techCategories.sleep"
                        />
                        <label class="form-check-label" for="inlineCheckbox1">{{
                          language.tech_approve_sleep_label
                        }}</label>
                      </div>
                      <div
                        class="form-check form-check-inline cat-checkbox"
                        v-if="selectedUserProfile.oxygen == 'PENDING'"
                      >
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="inlineCheckbox2"
                          v-model="techCategories.oxygen"
                        />
                        <label class="form-check-label" for="inlineCheckbox2">{{
                          language.tech_approve_oxygen_label
                        }}</label>
                      </div>
                      <div
                        class="form-check form-check-inline cat-checkbox"
                        v-if="selectedUserProfile.ventilators == 'PENDING'"
                      >
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="inlineCheckbox2"
                          v-model="techCategories.ventilator"
                        />
                        <label class="form-check-label" for="inlineCheckbox2">{{
                          language.tech_approve_ventilator_label
                        }}</label>
                      </div>
                    </div>

                    <div class="d-flex align-items-center m-3">
                      <button
                        type="button"
                        class="btn btn-primary px-4 popup-btns mr-2 btn-text"
                        @click.prevent="approveRecord(null)"
                        :disabled="isTechApprovedDisabled"
                      >
                        {{ language.tech_approve_ok_label }}
                      </button>
                      <button
                        type="button"
                        class="btn btn-outline-danger px-4 popup-btns"
                        @click.prevent="closemodal"
                      >
                        {{ language.tech_approve_cancel_label }}
                      </button>
                    </div>
                  </div>
                </div>
              </vue-final-modal>
            </div>
            <!-- tech sub categories approved popup start -->
            <!-- <div>
              <vue-final-modal
                v-model="approvedTechSubCategoriesModal"
                class="modal"
                @click-outside="closemodal"
              >
                <div class="modal-wrapper">
                  <div class="modal-container" id="subcat-approve">
                    <div class="subcat-popup">
                      <content select=".modal-header">
                        <div class="modal-header col-md-12">
                          <div class="row">
                            <div class="col-10">
                              <h4>
                                <strong
                                  >Approved Technical Sub Categories</strong
                                >
                              </h4>
                            </div>
                            <div class="col-2 text-right">
                              <button
                                type="button"
                                @click="closemodal"
                                class="close"
                                aria-label="Close"
                              >
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </content>
                      <div class="modal-body"></div>
                      <ul
                        v-for="(item, index) of showApprovedData"
                        :key="index"
                      >
                        <li>{{ item.categoryType }}</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </vue-final-modal>
            </div> -->
            <!-- tech sub categories approved popup start -->
             <div>
              <vue-final-modal
                v-model="approvedTechSubCategoriesModal"
                class="modal"
                @click-outside="closemodal"
              >
                <div class="modal-wrapper">
                  <div class="modal-container" id="subcat-approve">
                    <div class="subcat-popup">
                    <content select=".modal-header">
                      <div class="modal-header col-md-12">
                        <div class="row">
                          <div class="col-10">
                            <h4><strong>Approved Technical Sub Categories</strong></h4>
                          </div>
                          <div class="col-2 text-right">
                            <button
                              type="button"
                              @click="closemodal"
                              class="close"
                              aria-label="Close"
                            >
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                        </div>
                        </div>  
                    </content>
                          <div class="modal-body"></div>
                          <ul v-for="(item, index) of showApprovedData" :key="index">
                            <li>{{ item.categoryType }}</li>
                          </ul>
                    </div>
                </div>
                  </div>
              </vue-final-modal>
            </div>
            <!-- tech sub categories approved popup end -->
<!-- tech sub categories rejected popup start -->
             <!-- <div>
              <vue-final-modal
                v-model="rejectedTechSubCategoriesModal"
                class="modal"
                @click-outside="closemodal"
              >
                <div class="modal-wrapper">
                  <div class="modal-container" id="subcat-approve">
                    <div class="subcat-popup">
                    <content select=".modal-header">
                      <div class="modal-header col-md-12">
                        <div class="row">
                          <div class="col-10">
                            <h4><strong>Rejected Technical Sub Categories</strong></h4>
                          </div>
                          <div class="col-2 text-right">
                            <button
                              type="button"
                              @click="closemodal"
                              class="close"
                              aria-label="Close"
                            >
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                        </div>
                        </div>  
                    </content>
                          <div class="modal-body"></div>
                          <ul v-for="(item, index) of showRejectedData" :key="index">
                            <li>{{ item.categoryType }}</li>
                          </ul>
                    </div>
                </div>
                  </div>
              </vue-final-modal>
            </div> -->
            <!-- tech sub categories rejected popup end -->

            <!-- tech sub categories approved popup end -->
            <!-- tech sub categories rejected popup start -->
            <div>
              <vue-final-modal
                v-model="rejectedTechSubCategoriesModal"
                class="modal"
                @click-outside="closemodal"
              >
                <div class="modal-wrapper">
                  <div class="modal-container" id="subcat-approve">
                    <div class="subcat-popup">
                      <content select=".modal-header">
                        <div class="modal-header col-md-12">
                          <div class="row">
                            <div class="col-10">
                              <h4>
                                <strong
                                  >Rejected Technical Sub Categories</strong
                                >
                              </h4>
                            </div>
                            <div class="col-2 text-right">
                              <button
                                type="button"
                                @click="closemodal"
                                class="close"
                                aria-label="Close"
                              >
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </content>
                      <div class="modal-body"></div>
                      <ul
                        v-for="(item, index) of showRejectedData"
                        :key="index"
                      >
                        <li>{{ item.categoryType }}</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </vue-final-modal>
            </div>
            <!-- tech sub categories rejected popup end -->
            <div>
              <vue-final-modal
                v-if="rejectRow"
                v-model="showReject"
                class="modal"
                @click-outside="closereject"
              >
                <div class="modal-wrapper">
                  <div class="modal-container">
                    <content select="modal-header">
                      <div class="modal-header col-md-12">
                        <div class="row">
                          <div class="col-10">
                            <h4>{{ language.User_info }}</h4>
                          </div>

                          <div class="col-2 text-right">
                            <button
                              type="button"
                              @click="closereject"
                              class="close"
                              aria-label="Close"
                            >
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </content>
                    <div class="modal-body">
                      <div class="mt-1">
                        {{ language.firstname_label }}:
                        <span class="font-weight-bold">{{
                          rejectRow.profile.firstName
                        }}</span>
                      </div>
                      <div class="mt-1">
                        {{ language.lastname_label }}:
                        <span class="font-weight-bold">{{
                          rejectRow.profile.lastName
                        }}</span>
                      </div>
                      <div class="mt-1 overflow-auto">
                        {{ language.email_label }}:
                        <span class="font-weight-bold">{{
                          rejectRow.profile.email
                        }}</span>
                      </div>
                      <div class="mt-1">
                        {{ language.organization_text }}:
                        <span class="font-weight-bold">{{
                          rejectRow.profile.organisation
                        }}</span>
                      </div>
                      <div class="mt-4 mb-2">{{ language.notes_text }}:</div>
                      <div
                        style="line-height: 25px"
                        v-html="rejectRow.rejectedNotes"
                      ></div>
                    </div>
                  </div>
                </div>
              </vue-final-modal>
            </div>
            <div>
              <div class="row">
                <div class="col-md-12 text-center">
                  <router-link class="nav-link links" to="myaccount.html">{{
                    language.editapr_backto_profile_label
                  }}</router-link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import moment from "moment";
import { mapState, mapMutations } from "vuex";
import pageloader from "../components/pageloader";
import "vue-loading-overlay/dist/vue-loading.css";
import Api from "@/api";
import _ from "lodash";

export default {
  components: {
    pageloader,
  },
  name: "app",
  data() {
    //  subscMsg="You will be access the secure documents"
    return {
      bulkmode: false,
      multipleSelection: [],
      activeNames: [0],
      isLoadingLoader: false,
      adminUser: false,
      showModal: false,
      pageload: false,
      currentSort: "name",
      currentSortDir: "asc",
      showReject: false,
      rejectStatus: false,
      rejectRow: null,
      aprrovedStatus: false,
      showtechModal: false,
      approvedTechSubCategoriesModal: false,
      rejectedTechSubCategoriesModal: false,
      showApprovedData: [],
      showRejectedData: [],
      selectedUserProfile: {
        includeuser: false,
        email: "",
        type: "",
        notes: "0",
        comments: "",
        sleep: "",
        oxygen: "",
        ventilators: "",
        profile: {},
      },
      searchError: false,
      searchValue: "",
      userslist: "pending",
      already_exist_model: false,
      currentPage: 1,
      techCategories: {
        sleep: false,
        oxygen: false,
        ventilator: false,
      },
      allData: [],
      pendingUserAccess: [],
    };
  },
  computed: {
    ...mapState([
      "loggeduser",
      "language",
      "region",
      "oktaSid",
      "userRecords",
      "userRecCount",
    ]),
    isTechApprovedDisabled() {
      if (
        this.techCategories.sleep ||
        this.techCategories.oxygen ||
        this.techCategories.ventilator
      ) {
        return false;
      }
      return true;
    },
    requestedColNames() {
      if (this.userslist === "approved") {
        return "Request Approved";
      }
      if (this.userslist === "rejected") {
        return "Request Rejected";
      }
      return "Request Received";
    },
    getDateCol() {
      if (this.userslist === "approved") {
        return "approvedDate";
      }
      if (this.userslist === "rejected") {
        return "rejectedDate";
      }
      return "requestedDate";
    },
    actionCol() {
      if (this.userslist === "pending") return true;
      return false;
    },
  },
  async mounted() {
    try {
      this.pageload = true;
      this.setRegion(this.$route.params.region);
      await Api.getMe();
      await this.getUserSession();
    } catch (error) {
      console.error(error);
      this.$router.push("signin.html");
      this.pageload = false;
    }
  },
  methods: {
    ...mapMutations(["addUser", "setRegion", "setOktaSid"]),
    formatter(row) {
      return row.profile.firstName + " " + row.profile.lastName;
    },
    techSubCategoryTooltip(scope) {
      if (this.userslist == "approved" || this.userslist == "rejected") {
        if (
          scope.row.profile.userAccess.length > 0 &&
          scope.row.type === "TECHNICAL"
        ) {
          return true;
        }
      }
      return false;
    },
    filteredData() {
      this.allData = this.userRecords?.filter((item) => {
        if (
          this.userslist === "pending" &&
          item.type === "TECHNICAL" &&
          item.status === "APPROVED" &&
          item.profile.userAccess.length == 0
        ) {
          return;
        }
        return item;
      });
    },
    bulkmodeSwitch(e) {
      if (e) {
        this.allData = this.userRecords?.filter((item) => {
          if (
            this.userslist === "pending" &&
            item.type === "TECHNICAL" &&
            item.status === "PENDING"
          ) {
            return item;
          } else if (
            this.userslist === "pending" &&
            item.type !== "TECHNICAL"
          ) {
            return item;
          }
        });
      } else {
        this.filteredData();
      }
    },
    emailFormat(row) {
      return (
        <span v-on:click="onPopup">
          <i class="fa fa-ban" aria-hidden="true"></i>
          {row.profile.email}
        </span>
      );
    },
    onPopup(row) {
      this.rejectRow = row;
      this.showReject = true;
    },
    closereject() {
      this.rejectRow = null;
      this.showReject = false;
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    clearBulk(bulk = false) {
      this.multipleSelection = [];
      this.bulkmode = bulk;
    },
    sorter(a, b, col, profile = true) {
      if (profile) {
        if (a.profile[col].toUpperCase() < b.profile[col].toUpperCase())
          return -1;
        if (a.profile[col].toUpperCase() > b.profile[col].toUpperCase())
          return 1;
        return 0;
      } else {
        if (col === "dateCol") col = this.getDateCol;
        if (a[col].toUpperCase() < b[col].toUpperCase()) return -1;
        if (a[col].toUpperCase() > b[col].toUpperCase()) return 1;
        return 0;
      }
    },
    async changePage(page) {
      this.pageload = true;
      await Api.getAdminList(this.userslist, page * 50);
      this.filteredData();
      this.currentPage = page;
      this.pageload = false;
      this.clearBulk();
    },
    async userTypeChange(e) {
      this.currentPage = 1; // Reset the pagination
      this.userslist = e.target.value;
      this.searchValue = "";
      await this.getUserSession();
      this.clearBulk();
    },
    dateTime(row) {
      const colName = this.getDateCol;
      return row[colName] != null
        ? moment(row[colName]).format("DD-MM-YYYY")
        : "N/A";
    },
    sort: function(s) {
      //if s == current sort, reverse
      if (s === this.currentSort) {
        this.currentSortDir = this.currentSortDir === "asc" ? "desc" : "asc";
      }
      this.currentSort = s;
    },
    async getUserSession() {
      try {
        this.pageload = true;
        this.searchValue = "";
        await Api.getAdminList(this.userslist, 50);
        this.filteredData();
        this.pageload = false;
      } catch (error) {
        console.error(error);
        this.$router.push("signin.html");
        this.pageload = false;
      }
    },
    scrollToSuccess(id, offset) {
      const element = document.getElementById(id);
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition - offset;

      window.scrollBy({
        top: offsetPosition,
        behavior: "smooth",
      });
    },
    async approveRecord(row) {
      console.log(row);
      try {
        let hasTechnicalSelection = false;
        if (row == "bulk") {
          const technicalSelection = this.multipleSelection.filter((item) => {
            console.log("techitem", item);
            if (item.type === "TECHNICAL") {
              return item;
            }
          });
          hasTechnicalSelection = technicalSelection.length > 0;
        }
        let pendingAccess = await row?.profile?.userAccess;

        if (pendingAccess) {
          for (let item of await pendingAccess) {
            this.pendingUserAccess.push(item.categoryType);
          }
        }
        let rejectAccess = [];

        if (row == null) {
          const newRow = {
            profile: {
              email: this.selectedUserProfile.email,
            },
            type: this.selectedUserProfile.type,
          };
          row = newRow;
        }

        if (
          (row.type == "TECHNICAL" && !this.showtechModal) ||
          (row == "bulk" && hasTechnicalSelection)
        ) {
          this.technicalmodal(row);
          return;
        }
        let techBody = {};
        if ((row.type == "TECHNICAL" && this.showtechModal) || this.bulkmode) {
          console.log("this is tech body", row);
          const categoryType = [];
          if (this.techCategories.sleep) {
            categoryType.push("SLEEP");
          }
          if (this.techCategories.oxygen) {
            categoryType.push("OXYGEN");
          }
          if (this.techCategories.ventilator) {
            categoryType.push("VENTILATOR");
          }
          techBody = { categoryType };
          rejectAccess = this.pendingUserAccess.filter(
            (item) => !categoryType.includes(item)
          );
          this.closemodal();
        }
        if (row.type !== "TECHNICAL") {
          techBody = { categoryType: row.type };
        }
        if (row !== "bulk") {
          if (row.type !== "TECHNICAL") {
          techBody = { categoryType: row.type };
        }
        if (row !== "bulk") {
          let rejectAccessPart = { categoryType: rejectAccess };
          await Api.approveRecord(row.profile.email, row.type, techBody);
          if (rejectAccess.length) {
            await Api.rejectRecord(
              {
                email: row.profile.email,
                type: row.type,
                notes: "NA",
                comments: "NA",
                includeuser: false,
              },
              rejectAccessPart
            );
          }
        }
        } else {
          await Api.bulkApproveRecord(this.multipleSelection, techBody);
        }
        await Api.getAdminList(this.userslist, this.currentPage * 50);
        this.filteredData();
        this.aprrovedStatus = true;
        this.scrollToSuccess("success-status", 120);
        this.searchValue = "";
        const _self = this;
        setTimeout(function() {
          _self.aprrovedStatus = false;
        }, 4000);
        this.clearBulk();
      } catch (error) {
        console.log(error.message);
        this.$router.push("signin.html");
        this.pageload = false;
        this.clearBulk();
      }
      this.techCategories.sleep = false;
      this.techCategories.oxygen = false;
      this.techCategories.ventilator = false;
    },
    async rejectRecord() {
      try {
        let techBody = {};
        if (this.selectedUserProfile.type == "TECHNICAL") {
          const categoryType = this.selectedUserProfile.profile.userAccess.map(
            (subCat) => subCat.categoryType
          );
          techBody = { categoryType };
        }
        if (this.selectedUserProfile.type !== "TECHNICAL") {
          techBody = { categoryType: this.selectedUserProfile.type };
        }
        if (this.bulkmode) {
          await Api.bulkRejectRecord(
            this.multipleSelection,
            this.selectedUserProfile
          );
        } else {
          await Api.rejectRecord(this.selectedUserProfile, techBody);
        }

        this.closemodal();
        await Api.getAdminList(this.userslist, this.currentPage * 50);
        this.filteredData();
        this.rejectStatus = true;
        this.pageload = false;
        this.searchValue = "";
        const _self = this;
        setTimeout(function() {
          _self.rejectStatus = false;
        }, 3000);
        this.clearBulk();
      } catch (error) {
        console.error(error);
        this.$router.push("signin.html");
        this.pageload = false;
        this.clearBulk();
      }
    },

    //for success message

    async appRecord() {
      try {
        this.pageload = true;
        if (this.bulkmode) {
          await Api.bulkAppRecord(
            this.multipleSelection,
            this.selectedUserProfile
          );
        } else {
          await Api.appRecord(this.selectedUserProfile);
        }
        this.closemodal();
        await Api.getAdminList(this.userslist, this.currentPage * 50);
        this.filteredData();
        this.approvedStatus = true;
        this.pageload = false;
        this.searchValue = "";
        const _self = this;
        setTimeout(function() {
          _self.approvedStatus = false;
        }, 3000);
        this.clearBulk();
      } catch (error) {
        console.error(error);
        this.$router.push("signin.html");
        this.pageload = false;
        this.clearBulk();
      }
    },
    search: _.debounce(async function(e) {
      this.pageload = true;
      const search = e.target.value.trim();
      this.searchValue = search;
      if (search.length < 3 && search.length > 0) {
        this.searchError = true;
        this.pageload = false;
        return;
      } else if (search.length == 0) {
        this.currentPage = 1; // Reset the pagination
        this.searchError = false;
        await Api.getAdminList(this.userslist, this.currentPage * 50);
        this.filteredData();
        this.pageload = false;
      }
      this.currentPage = 1; // Reset the pagination
      this.searchError = false;
      await Api.getSearchList(search, this.userslist, this.currentPage * 50);
      this.filteredData();

      this.clearBulk();
      this.pageload = false;
    }, 1000),
    orderBy(sortFn) {
      // sort your array data like this.userArray
      this.pendingApprovals.sort(sortFn);
    },

    showmodal(row) {
      if (row !== "bulk") {
        this.selectedUserProfile.email = row.profile.email;
        this.selectedUserProfile.type = row.type;
        this.selectedUserProfile.profile = row.profile;
      }
      this.showModal = true;
    },

    technicalmodal(row) {
      if (row !== "bulk") {
        this.selectedUserProfile.email = row.profile.email;
        this.selectedUserProfile.type = row.type;
        this.selectedUserProfile.sleep =
          row.profile.userAccess.find((item) => item.categoryType === "SLEEP")
            ?.status ||
          (row.status === "PENDING" && row.profile.userAccess.length == 0)
            ? "PENDING"
            : "";
        this.selectedUserProfile.oxygen =
          row.profile.userAccess.find((item) => item.categoryType === "OXYGEN")
            ?.status ||
          (row.status === "PENDING" && row.profile.userAccess.length == 0)
            ? "PENDING"
            : "";
        this.selectedUserProfile.ventilators =
          row.profile.userAccess.find(
            (item) => item.categoryType === "VENTILATOR"
          )?.status ||
          (row.status === "PENDING" && row.profile.userAccess.length == 0)
            ? "PENDING"
            : "";
      }
      this.showtechModal = true;
    },
    techSubCategoryModal(row) {
      if (this.userslist === "approved") {
        this.approvedTechSubCategoriesModal = true;
        this.showApprovedData = row.profile.userAccess;
      }
      if (this.userslist === "rejected") {
        this.rejectedTechSubCategoriesModal = true;
        this.showRejectedData = row.profile.userAccess;
      }
    },
    closemodal() {
      this.selectedUserProfile.notes = "0";
      this.selectedUserProfile.comments = "";
      this.selectedUserProfile.includeuser = false;
      this.selectedUserProfile.email = "";
      this.selectedUserProfile.type = "";
      this.showModal = false;
      this.showtechModal = false;
      this.approvedTechSubCategoriesModal = false;
      this.rejectedTechSubCategoriesModal = false;
      this.techCategories.sleep = false;
      this.techCategories.oxygen = false;
      this.techCategories.ventilator = false;
    },
  },
};
</script>
<style scoped lang="scss">
.subcat_tooltip {
  display: flex;
}
.cat-checkbox {
  margin-right: 5rem;
  color: grey;
  font-size: 20px;
  font-weight: 500;
}
.subcat-popup {
  margin: 20px;
}
#subcat-approve {
  width: 600px;
  height: 280px;
}
#popup-approve {
  width: 700px;
  height: 300px;
}
.subcat-popup {
  margin: 20px;
}
#subcat-approve {
  width: 600px;
  height: 280px;
}
.popup-btns {
  width: 120px;
}
.btn-text {
  color: white;
}
.name-bgcolor {
  background-color: lightgray;
}
.block-icon-mobile {
  cursor: pointer;
  position: absolute;
  z-index: 0;
  right: 45px;
  top: 12px;
}
.bulk-check-mobile {
  cursor: pointer;
  position: absolute;
  z-index: 0;
  left: -10px;
  top: 4px;
  padding: 10px;
}
.mobile-bulk-view-title::v-deep > * > .el-collapse-item__header {
  padding-left: 25px !important;
}

.mobile-check-box::v-deep > .el-checkbox__label {
  display: none !important;
}
.table-name {
  display: flex;
  justify-content: space-between;
  word-break: keep-all;
  align-items: center;
}
.checktext {
  display: flex;
}
.info-grey {
  font-size: 15px;
  color: darkgray;
}
.signin {
  border-radius: 10px;
  margin-top: auto;
  margin-bottom: auto;
}
td {
  text-align: left;
}
.signinbtn {
  padding: 12px 40px;
  border-radius: 10px;
  font-size: 19px;
}
.links {
  font-size: 18px;
}
.info {
  font-size: 20px;
  color: #555;
}
.approve,
.reject {
  border-radius: 7px;
}
.fa-ban {
  color: red;
  font-size: 16px;
  margin-right: 10px;
}
.email-truncate {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 206px;
}
.modal-header {
  display: block !important;
}
::v-deep .modal {
  display: flex;
  justify-content: center;
  align-items: center;
  overflow-y: auto;
}
::v-deep .modal-content {
  display: flex;
  flex-direction: column;
}
.modal-wrapper {
  display: table-cell;
  vertical-align: middle;
  transform: translate(-50%, -50%) !important;
  top: 50%;
  left: 50%;
  position: absolute;
}
.modal-container {
  background: #fff;
  width: 600px;
  border-radius: 5px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.33);
  transition: all 0.3s ease;
  margin: 0 auto;
  // padding: 20px 30px;
}
.modal-footer {
  margin-top: 15px;
}
.modal-enter,
.modal-leave {
  opacity: 0;
}
.modal-enter .modal-container,
.modal-leave .modal-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
.form-control {
  appearance: auto;
}
.dropdown-bg {
  background-color: #1788c3;
  color: white;
}
.approve-dialog {
  text-align: center;
  background-color: green;
  border-radius: 5px;
}
.error-dialog {
  text-align: center;
  background-color: $secondary-color;
  border-radius: 5px;
}
/* Mobile view */
@include media-breakpoint-down(md) {
  .modal-desc-ul {
    font-size: 12px;
  }
  .modal-container {
    width: 350px;
    padding: 5px 0;
  }
  .mobile-page-load {
    margin-top: 6rem;
  }
}
</style>