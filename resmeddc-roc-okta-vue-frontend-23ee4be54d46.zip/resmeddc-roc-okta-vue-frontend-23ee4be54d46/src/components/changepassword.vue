<template>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-md-8 col-lg-6 col-xl-5 mt-5 mt-lg-0 m-auto">
        <div class="signin mt-5 mt-lg-0">
          <h2 class="text-center m-3 title">
            {{ language.changepassword_header }}
          </h2>
          <div class="pb-4 info">
            {{ language.changepassword_instructions }}
          </div>
          <div v-if="error" class="my-3">
            <p class="bg-danger p-2 text-light already-text rounded">
              {{ error }}
            </p>
          </div>
          <div v-if="success" class="my-3">
            <p class="already-text">
              <img :src="successIcon" />
              {{ language.password_changed }}
            </p>
          </div>
          <form @submit.prevent="changepassword">
            <div class="form-group">
              <div class="input-group">
                <input
                  v-bind:type="[showPassword ? 'text' : 'password']"
                  v-model="user.oldpassword"
                  :placeholder="language.oldpassword_label"
                  id="oldpassword"
                  name="oldpassword"
                  class="form-control"
                  :class="{
                    'is-invalid': submitted && v$.user.oldpassword.$error,
                  }"
                />
                <div class="input-group-append">
                  <span
                    class="input-group-text show-icon"
                    @click="showPassword = !showPassword"
                    ><i
                      v-bind:class="[
                        showPassword ? 'fa fa-eye' : 'fa fa-eye-slash',
                      ]"
                      aria-hidden="true"
                    ></i
                  ></span>
                </div>
                <div
                  v-if="submitted && v$.user.oldpassword.$error"
                  class="invalid-feedback"
                >
                  <span v-if="!v$.user.oldpassword.required.$invalid">{{
                    language.pass_enter_text
                  }}</span>
                  <span v-if="!v$.user.oldpassword.minLength.$invalid">{{
                    language.pass_valid
                  }}</span>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="input-group">
                <input
                  v-bind:type="[showConfPassword ? 'text' : 'password']"
                  @input="checkPassword()"
                  v-model="user.password"
                  :placeholder="language.newpassword_label"
                  id="password"
                  name="password"
                  class="form-control"
                  :class="{
                    'is-invalid':
                      (submitted && v$.user.password.$error) || checkSame,
                  }"
                />
                <div class="input-group-append">
                  <span
                    class="input-group-text show-icon"
                    @click="showConfPassword = !showConfPassword"
                    ><i
                      v-bind:class="[
                        showConfPassword ? 'fa fa-eye' : 'fa fa-eye-slash',
                      ]"
                      aria-hidden="true"
                    ></i
                  ></span>
                </div>
                <div
                  v-if="submitted && v$.user.password.$error"
                  class="invalid-feedback"
                >
                  <span v-if="!v$.user.password.required.$invalid">{{
                    language.pass_enter_text
                  }}</span>
                  <span v-if="!v$.user.password.minLength.$invalid">{{
                    language.pass_valid
                  }}</span>
                </div>
                <div v-if="checkSame" class="invalid-feedback">
                  <span v-if="checkSame">{{ language.password_Notsame }}</span>
                </div>
                <div
                  v-if="
                    (user.password.includes(loggeduser.firstName) &&
                      loggeduser.firstName != '') ||
                    (user.password.includes(loggeduser.email) &&
                      loggeduser.email != '')
                  "
                  class="error_show"
                >
                  <p>
                    {{ language.password_not_contain_email }}
                  </p>
                </div>
                <div class="error_show" v-if="total_validation">
                  <p>{{ language.password_restrictions }}</p>
                  <p>{{ language.password_numeric }}</p>
                  <p>{{ language.password_lower }}</p>
                  <p>{{ language.password_upper }}</p>
                  <p>{{ language.password_special }}</p>
                  <p>{{ language.password_pattern }}</p>
                </div>
              </div>
            </div>
            <div class="form-group">
              <vue-button-spinner
                class="res-spin-btn my-2"
                :is-loading="isLoading"
                :disabled="isLoading"
              >
                {{ language.changepassword_label }}
              </vue-button-spinner>
            </div>
            <div>
              <div class="row">
                <div class="col-md-6 text-left">
                  <router-link
                    class="nav-link links res-link-primary p-0 backlink"
                    to="myaccount.html"
                    >{{ language.backtoaccount_label }}</router-link
                  >
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import _ from "lodash";
import useVuelidate from "@vuelidate/core";
import { required, minLength } from "@vuelidate/validators";
import VueButtonSpinner from "@/components/spinner";
import { mapState, mapMutations } from "vuex";
import Api from "@/api";
import successIcon from "@/assets/images/success-new.png";

export default {
  name: "app",
  components: { VueButtonSpinner },
  setup() {
    const v$ = useVuelidate();
    return { v$ };
  },
  data() {
    return {
      total_validation: false,
      showPassword: false,
      showConfPassword: false,
      user: {
        oldpassword: "",
        password: "",
      },
      submitted: false,
      isLoading: false,
      error: "",
      success: false,
      successIcon: successIcon,
    };
  },
  validations: {
    user: {
      oldpassword: { required, minLength: minLength(8) },
      password: {
        required,
        minLength: minLength(10),
      },
    },
  },
  computed: {
    ...mapState(["loggeduser", "language"]),
    checkSame: function () {
      if (this.user.oldpassword && this.user.password) {
        return this.user.oldpassword === this.user.password;
      }
      return false;
    },
  },
  async beforeMount() {
    if (_.isEmpty(this.loggeduser)) {
      this.$router.push("signin.html");
    }
  },
  async mounted() {
    this.setRegion(this.$route.params.region);
  },
  methods: {
    ...mapMutations(["setRegion"]),
    checkPassword() {
      if (
        !(this.user.password.length >= 10) ||
        !/\d/.test(this.user.password) ||
        !/[a-z]/.test(this.user.password) ||
        !/[A-Z]/.test(this.user.password) ||
        !/[!@#$%^&*)(+=._-]/.test(this.user.password)
      ) {
        this.total_validation = true;
      } else {
        this.total_validation = false;
      }
      if (this.user.password.length == 0) {
        this.total_validation = false;
      }
    },
    async changepassword() {
      try {
        this.submitted = true;
        // stop here if form is invalid
        this.v$.$touch();
        if (this.v$.$invalid || this.checkSame) {
          return;
        }

        this.isLoading = true;
        this.error = "";
        await Api.changePassword(this.user.oldpassword, this.user.password);
        this.success = true;
        this.isLoading = false;
        const _self = this;
        setTimeout(function () {
          _self.$router.push("signin.html");
        }, 2000);
        //  remove all cookie
        const allCookies = this.$cookies.keys();
        allCookies.map((cookie) => {
          this.$cookies.remove(cookie);
        });
      } catch (error) {
        this.error = error.message;
        this.isLoading = false;
      }
    },
  },
};
</script>
<style scoped lang="scss">
.signin {
  border-radius: 10px;
  margin-top: auto;
  margin-bottom: auto;
}
.signin input {
  height: 48px;
  border-radius: 7px;
  background-color: #f4f4f4;
  color: #555;
  border: 1px solid #000;
}

.links {
  font-size: 18px;
}
.info {
  font-size: 20px;
  color: #555;
}
.error_show {
  color: #b94a48;
}
/* Mobile view */
@include media-breakpoint-down(md) {
}
.backlink{
  color:blue !important;
}
</style>
