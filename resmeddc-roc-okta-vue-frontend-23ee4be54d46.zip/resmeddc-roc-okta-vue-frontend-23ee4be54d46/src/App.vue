<template>
  <!-- <transition name="moveInUp"> -->
  <div id="app" class="overflow-hidden">
    <!-- navbar -->
    <div class="overflow-auto single-page">
      <header-bar></header-bar>
      <div class="container">
        <router-view />
        <!-- <notifications/> -->
      </div>
    </div>
    <footer-bar></footer-bar>
  </div>
  <!-- </transition> -->
</template>

<script>
import footer from "@/components/footer";
import header from "@/components/header";
import { mapState, mapMutations } from "vuex";
import axios from "axios";
import Api from "@/api";

export default {
  components: {
    "footer-bar": footer,
    "header-bar": header,
  },
  name: "App",
  async mounted() {
    const oktaEndpoint = this.$cookies.get("rocServ");
    const userId = this.$cookies.get("rocSid");

    if (userId && oktaEndpoint) {
      try {
        await axios
          .get(`${oktaEndpoint}v1/account/session`, {
            headers: {
              OKTA_SID: `${userId}`,
              "Content-Type": "application/json",
              region: `${this.region}`,
            },
          })
          .then(() => {
            if(!this.$router.currentRoute.value.path.includes('verify_email.html')) {
              this.$router.push(`/${this.region}/myaccount.html`);
            }
          });
      } catch (error) {
        console.log(error);
        const allCookies = this.$cookies.keys();
        const _self = this;
        await Api.logout();
        await this.resetUser();
        allCookies.map((cookie) => {
          _self.$cookies.remove(
            cookie,
            null,
            window.location.hostname === "localhost"
              ? "localhost"
              : "resmed.com"
          );
        });

        this.$local.remove("pdfPath");
        this.$local.remove("softwarePath");
        if(!this.$router.currentRoute.value.path.includes('verify_email.html')) {
          this.$router.push(`/${this.region}/signin.html`);
        }
      }
    }
  },
  computed: {
    ...mapState(["loggeduser", "region", "oktaSid", "language"]),
    ...mapMutations(["resetUser"]),
  },
};
</script>
<style lang="scss">
@import "../node_modules/bootstrap/scss/bootstrap";

.top-bar {
  border-bottom: 1px solid gray;
}
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: #000;
  color: white;
  text-align: center;
}
.main-nav {
  background-color: #000;
  color: #fff !important;
  font-size: 16px;
}
.main-nav a {
  color: #fff;
  text-decoration: none;
}
.nav-link {
  display: inline;
}
.single-page {
  padding-bottom: 80px !important;
}
</style>
