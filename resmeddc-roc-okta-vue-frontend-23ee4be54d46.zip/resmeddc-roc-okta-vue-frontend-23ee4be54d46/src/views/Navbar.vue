<template>
  <nav class="navbar navbar-expand-lg bg-dark navbar-dark px-0 w-100">
    <div class="container flex-row-reverse py-2 py-md-0">
      <div class="navbar-header d-lg-none">
        <!-- <router-link to="/" class="navbar-brand"
          ><img :src="logo" width="50"
        /></router-link> -->
        <a :href="`https://resmed.com`" target="_blank" class="navbar-brand"
          ><img :src="logo" width="50"
        /></a>
      </div>
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
        @click="menuOpen = !menuOpen"
      >
        <span data v-if="!menuOpen" class="navbar-toggler-icon"></span>
        <span v-if="menuOpen" class="fa fa-times"></span>
      </button>
      <div
        class="collapse navbar-collapse"
        :class="{ show: menuOpen }"
        id="navbarSupportedContent"
      >
        <ul class="navbar-nav mr-auto">
          <div>
            <li class="nav-item res-bac-nav active">
              <a v-if="notEu" href="https://support.resmed.com"
                ><span class="arrow-angle">←</span>{{language.navbar_support_label}}</a
              >
            </li>
          </div>
          <div class="nav-user-items" v-if="isLogged">
            <li class="nav-item d-none d-lg-block">
              <a class="nav-link p-0"
                >{{ language.navbar_welcome_label }} {{ loggeduser.firstName
                }}<span class="d-none d-lg-inline-block mx-3">|</span></a
              >
            </li>
            <li class="nav-item">
              <a @click="closeMenu" class="nav-link p-0">
                <router-link
                  class="nav-link links py-xl-0 res-nav-text"
                  :to="myprofile"
                  >{{ language.navbar_myprofile_label
                  }}<span class="d-none d-lg-inline-block mx-3"
                    >|</span
                  ></router-link
                >
              </a>
            </li>
            <li class="nav-item">
              <a @click="closeMenu" class="nav-link p-0"
                ><p class="nav-link links p-0 m-0 res-nav-text" @click="logout">
                  {{ language.navbar_logout_label }}
                </p>
              </a>
            </li>
          </div>
        </ul>
      </div>
    </div>
  </nav>
</template>
<script>
import { ref } from "vue";
import _ from "lodash";
import resmedWhite from "@/assets/images/logo-resmed-white.svg";
import "../../node_modules/bootstrap/dist/js/bootstrap";

export default {
  props: {
    logout: Function,
    loggeduser: Object,
    region: String,
    isEuReg: Boolean,
    language: Object,
  },
  setup() {
    const menuOpen = ref(false);
    console.log(this);

    return { menuOpen };
  },
  data() {
    return {
      logo: resmedWhite,
      myprofile: `/${this.region}/myaccount.html`,
      notEu: !this.isEuReg,
    };
  },
  computed: {
    isLogged: function() {
      return !_.isEmpty(this.loggeduser);
    },
  },
  created() {
    console.log(this);
  },
  watch: {
    region: function(newVal) {
      this.myprofile = `/${newVal}/myaccount.html`;
    },
    isEuReg: function(newVal) {
      this.notEu = !newVal;
    },
  },
  methods: {
    toggleMenu: function() {
      this.menuOpen = !this.menuOpen;
    },
    closeMenu: function() {
      var _self = this;
      setTimeout(function() {
        _self.menuOpen = false;
      }, 2000);
    },
  },
};
</script>
<style scoped lang="scss">
.navbar.navbar-expand-lg {
  z-index: 100;
  position: relative;
}
.nav-item,
.nav-item > a {
  color: #fff;
  text-decoration: none;
  .res-nav-text {
    cursor: pointer;
  }
}
.navbar-header {
  float: left;
  text-align: center;
  width: 90%;
}
.navbar-brand {
  float: none;
}
button.navbar-toggler {
  border: none !important;
  padding: 0 !important;
}
button.navbar-toggler:hover,
button.navbar-toggler:active,
button.navbar-toggler:focus {
  border: none !important;
}
.collapse > .navbar-nav {
  align-items: baseline;
  justify-content: space-between;
  width: 100%;
  .nav-user-items {
    display: flex;
    flex-direction: row;
    align-items: baseline;
  }
}

@include media-breakpoint-down(lg) {
  .navbar.navbar-expand-lg {
    position: fixed;
  }
  .collapse {
    padding: 10px 15px;
    position: absolute;
    width: 100%;
    height: calc(100vh - 120px);
    top: 63px;
    background: $white;
    z-index: 90;
    left: 0;
    .navbar-nav {
      flex-direction: column-reverse;
      li.nav-item {
        width: 100%;
      }
      li > a {
        color: $gray-900;
      }
      .res-bac-nav {
        position: absolute;
        bottom: 0px;
        background: $gray-200;
        padding: 10px;
        left: 0;
        width: 100%;
      }
      .nav-user-items {
        width: 100%;
        flex-direction: column;
        li > a > .res-nav-text {
          font-weight: bold;
          padding: 12px 0px !important;
          border-bottom: solid 1px lightgray;
          width: 100%;
          color: $gray-900 !important;
        }
      }
    }
  }
}
</style>
