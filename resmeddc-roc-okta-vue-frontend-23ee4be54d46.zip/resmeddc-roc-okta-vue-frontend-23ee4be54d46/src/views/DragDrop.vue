<template>
  <div class="d-flex align-items-center">
    <draggable
      v-model="myArray"
      :sort="false"
      item-key="id"
      class="mr-1 mr-lg-4 d-flex"
      :group="{ name: 'people', pull: 'clone', put: false }"
    >
      <template #item="{ element }">
        <div class="mx-2 mx-lg-3" :id="element.id">
          <img :src="element.image" />
        </div>
      </template>
    </draggable>
    <div class="drop-zone">
      <span class="drop-text" :class="{ 'drop-item-exists': myDrop.length }"
        >{{language.forgot_drophere_label}}</span
      >
      <draggable
        v-model="myDrop"
        group="people"
        @add="add"
        item-key="id"
        class="ml-md-4 p-4 drop-here"
        :class="{ 'dropped-item': myDrop.length }"
      >
        <template #item="{ element }">
          <div class="drop-item" :id="element.id">
            <img :src="element.image" />
          </div>
        </template>
      </draggable>
    </div>
  </div>
</template>
<script>
import _ from "lodash";
import draggable from "vuedraggable";
import ballon from "@/assets/images/balloons.png";
import airplane from "@/assets/images/airplane.png";
import car from "@/assets/images/car.png";
import chair from "@/assets/images/chair.png";
import camera from "@/assets/images/camera.png";
import cloud from "@/assets/images/cloud.png";
import computer from "@/assets/images/computer.png";
import envelope from "@/assets/images/envelope_small.png";
import foot from "@/assets/images/foot.png";
import { mapState } from 'vuex';

export default {
  components: { draggable },
  props: { setCaptcha: Function, setValidCaptcha: Function },
  data() {
    return {
      myArray: [],
      picChoice: {},
      myDrop: [],
    };
  },
   computed: {
    ...mapState(["region", "language"]),
   },
  mounted: function mounted() {
    this.reset();
  },
  methods: {
    add: function (e) {
      const getItem = e.item.id;
      const getEle = this.myArray.filter((value) => value.id == getItem);
      this.myDrop = [getEle[0]];
      this.setValidCaptcha(_.isEqual(getEle[0], this.picChoice));
    },
    reset: function () {
      const myPics = [
        { id: 1, name: "ballon", image: ballon },
        { id: 2, name: "camera", image: camera },
        { id: 3, name: "cloud", image: cloud },
        { id: 4, name: "computer", image: computer },
        { id: 5, name: "envelope", image: envelope },
        { id: 6, name: "foot", image: foot },
        { id: 7, name: "car", image: car },
        { id: 8, name: "airplane", image: airplane },
        { id: 9, name: "chair", image: chair },
      ];

      const myArray = _.sampleSize(myPics, 5);
      let picChoice = _.sample(myArray);
      this.setCaptcha(picChoice);
      this.myArray = myArray;
      this.picChoice = picChoice;
      this.myDrop = [];
    },
  },
};
</script>
<style lang="scss">
.drop-zone {
  position: relative;
  .drop-item {
    position: absolute;
    top: 35px;
    left: 55px;
    z-index: 100;
  }
  .drop-here {
    background-color: $gray-600;
    width: 100px;
    height: 100px;
    border-radius: 100px;
    z-index: 1;
  }
  .dropped-item {
    background-color: $gray-300;
  }
  .drop-text {
    position: absolute;
    top: 36px;
    left: 38px;
    z-index: 2;
  }
  .drop-item-exists {
    color: white;
    z-index: 2;
  }
}

/* Mobile view */
@include media-breakpoint-down(md) {
  .drop-zone {
    .drop-item {
      top: 25px;
      left: 23px;
    }
    .drop-here {
      width: 80px;
      height: 80px;
    }
    .drop-text {
      top: 30px;
      left: 15px;
      font-size: 12px;
    }
  }
}
</style>