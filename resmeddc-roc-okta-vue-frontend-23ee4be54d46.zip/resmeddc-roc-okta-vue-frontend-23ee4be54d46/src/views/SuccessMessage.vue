<template>
  <div>
    <h2 class="text-center m-5 title">
      {{ header }}
    </h2>
    <!-- <div class="pb-4 info">
            {{ language.tagline }}
          </div> -->
    <div v-if="!error" class="check-img">
      <img :src="checkImg" />
    </div>
    <div v-else class="check-img">
      <img :src="crossImg" />
    </div>
    <div class="mb-3 mt-5 info" :class="{ 'error-msg': error }">
      {{ message }}
    </div>

    <div class="text-center pt-2">
      <button @click.prevent="goSignin" class="btn btn-primary res-btn-primary">
        {{ signlabel }}
      </button>
    </div>
  </div>
</template>

<script>
import checkImg from "@/assets/images/check-circle-regular.svg";
import crossImg from "@/assets/images/times-circle-regular.svg";

export default {
  props: {
    header: String,
    message: String,
    signlabel: String,
    error: {
      type: Boolean,
      default: false,
    },
  },

  data() {
    return {
      checkImg: checkImg,
      crossImg: crossImg,
      // verified: false,
    };
  },
  methods: {
    goSignin() {
      this.$router.push("signin.html");
    },
  },
  async mounted() {
    setTimeout(() => this.$router.push("signin.html"), 10000);
  },
};
</script>

<style scoped lang="scss">
.check-img {
  width: 120px;
  margin: auto;
}
.info {
  font-size: 20px;
  color: #555;
  text-align: center;
}
.error-msg {
  border-radius: 5px;
  color: $secondary-color !important;
  padding: 10px;
  font-size: 16px;
}
</style>