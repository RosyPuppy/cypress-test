import { createRouter, createWebHistory } from "vue-router";
import signup from "@/components/signup";
import signin from "@/components/signin";
import forgotpassword from "@/components/forgotpassword";
import changeemail from "@/components/changeemail";
import changepassword from "@/components/changepassword";
import myaccount from "@/components/myaccount";
import editprofile from "@/components/editprofile";
import editsubscriptions from "@/components/editsubscriptions";
import editapprovals from "@/components/editapprovals";
import signhelp from "@/components/signhelp";
import verify from "@/components/verify";
import verify_email from "@/components/verify_email";
import verifypassword from "@/components/verifypassword";
import confirmyouraccount from "@/components/confirmyouraccount";

const routes = [
  {
    path: "/:region",
    name: "signin",
    component: signin,
  },
  {
    path: "/:region/signin.html?redirect_to",
    name: "signin",
    component: signin,
  },
  {
    path: "/:region/signin.html",
    name: "signin",
    component: signin,
  },
  {
    path: "/:region/resetpassword.html",
    name: "forgotpassword",
    component: forgotpassword,
  },
  {
    path: "/:region/signup.html",
    name: "signup",
    component: signup,
  },
  {
    path: "/:region/myaccount.html",
    name: "myaccount",
    component: myaccount,
  },
  {
    path: "/:region/editprofile.html",
    name: "editprofile",
    component: editprofile,
  },
  {
    path: "/:region/changeemail.html",
    name: "changeemail",
    component: changeemail,
  },
  {
    path: "/:region/changepassword.html",
    name: "changepassword",
    component: changepassword,
  },
  {
    path: "/:region/subscribe.html",
    name: "editsubscriptions",
    component: editsubscriptions,
  },
  {
    path: "/:region/editapprovals.html",
    name: "editapprovals",
    component: editapprovals,
  },
  {
    path: "/:region/sign_help.html",
    name: "signhelp",
    component: signhelp,
  },
  {
    path: "/:region/verify.html",
    name: "verify",
    component: verify,
  },
  {
    path: "/:region/verify_email.html",
    name: "verify_email",
    component: verify_email,
  },
  {
    path: "/:region/verify_password.html",
    name: "verifypassword",
    component: verifypassword,
  },
  {
    path: "/:region/confirmyouraccount.html",
    name: "confirmyouraccount",
    component: confirmyouraccount,
  },
  
];

const router = createRouter({
  // 4. Provide the history implementation to use. We are using the hash history for simplicity here.
  history: createWebHistory(process.env.BASE_URL),
  routes, // short for `routes: routes`
});

export default router;
